<?php
declare(strict_types=1);
namespace Models;

use Core\Model;

final class Provider extends Model
{
    protected static string $table = 'providers';

    public static function active(): array
    {
        return self::pdo()->query("SELECT * FROM providers WHERE status='active' ORDER BY priority ASC")
            ->fetchAll();
    }

    public static function decryptedKey(array $provider): string
    {
        try {
            return \Crypto::decrypt($provider['api_key']);
        } catch (\Throwable $e) {
            \Logger::error('provider', 'decrypt failed for provider '.$provider['id']);
            throw new \RuntimeException('Cannot read provider API key');
        }
    }
}