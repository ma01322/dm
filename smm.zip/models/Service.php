<?php
declare(strict_types=1);
namespace Models;

use Core\Model;

final class Service extends Model
{
    protected static string $table = 'services';

    public static function websiteListFor(?string $role = 'customer'): array
    {
        $st = self::pdo()->query(
            "SELECT s.*, c.name AS category FROM services s
             LEFT JOIN categories c ON c.id=s.category_id
             WHERE s.status='active' AND s.visible_website=1
             ORDER BY c.sort_order, s.sort_order, s.id"
        );
        return $st->fetchAll();
    }

    public static function apiListAll(): array
    {
        return self::pdo()->query(
            "SELECT s.*, c.name AS category FROM services s
             LEFT JOIN categories c ON c.id=s.category_id
             WHERE s.status='active' AND s.visible_api=1
             ORDER BY s.id ASC"
        )->fetchAll();
    }
}