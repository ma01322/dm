<?php
declare(strict_types=1);
namespace Models;

use Core\Model;

final class User extends Model
{
    protected static string $table = 'users';

    public static function findByEmail(string $email): ?array {
        $st = self::pdo()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $st->execute([strtolower($email)]);
        return $st->fetch() ?: null;
    }

    public static function findByUsername(string $u): ?array {
        $st = self::pdo()->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
        $st->execute([$u]);
        return $st->fetch() ?: null;
    }

    public static function create(string $username, string $email, string $password, string $role = 'customer'): int
    {
        return self::insert([
            'username'      => $username,
            'email'         => strtolower($email),
            'password_hash' => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
            'role'          => $role,
            'status'        => 'active',
            'currency'      => \Models\Setting::get('currency', 'BDT'),
        ]);
    }

    public static function verifyPassword(array $user, string $plain): bool
    {
        return password_verify($plain, $user['password_hash']);
    }

    public static function paginate(int $page, int $perPage = 25, array $filters = []): array
    {
        $where = []; $args = [];
        if (!empty($filters['role']))   { $where[] = 'role = ?';   $args[] = $filters['role']; }
        if (!empty($filters['status'])) { $where[] = 'status = ?'; $args[] = $filters['status']; }
        if (!empty($filters['q'])) {
            $where[] = '(username LIKE ? OR email LIKE ?)';
            $args[] = '%' . $filters['q'] . '%';
            $args[] = '%' . $filters['q'] . '%';
        }
        $sql = 'FROM users ' . ($where ? 'WHERE ' . implode(' AND ', $where) : '');
        $pdo = self::pdo();
        $st = $pdo->prepare("SELECT COUNT(*) $sql"); $st->execute($args);
        $total = (int) $st->fetchColumn();

        $offset = max(0, ($page - 1) * $perPage);
        $st = $pdo->prepare("SELECT * $sql ORDER BY id DESC LIMIT $perPage OFFSET $offset");
        $st->execute($args);
        return ['rows' => $st->fetchAll(), 'total' => $total, 'page' => $page, 'per_page' => $perPage];
    }
}