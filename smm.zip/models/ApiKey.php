<?php
declare(strict_types=1);
namespace Models;

use Core\Model;
use DB;

final class ApiKey extends Model
{
    protected static string $table = 'api_keys';

    /** Generate a new API key: returns [fullKey, prefix, rowId]. */
    public static function generate(int $userId, string $label = 'default', int $rateLimit = 60): array
    {
        $full   = 'SMM_' . bin2hex(random_bytes(24)); // 52 chars total, prefix SMM_
        $prefix = substr($full, 0, 12);
        $hash   = hash('sha256', $full);

        $id = self::insert([
            'user_id'    => $userId,
            'key_hash'   => $hash,
            'key_prefix' => $prefix,
            'label'      => mb_substr($label, 0, 80),
            'status'     => 'active',
            'rate_limit' => $rateLimit,
        ]);
        return ['key' => $full, 'prefix' => $prefix, 'id' => $id];
    }

    public static function revoke(int $id, int $userId): bool
    {
        $st = DB::conn()->prepare(
            'UPDATE api_keys SET status="revoked", revoked_at=NOW() WHERE id=? AND user_id=? AND status="active"'
        );
        $st->execute([$id, $userId]);
        return $st->rowCount() > 0;
    }

    public static function activeForUser(int $userId): ?array
    {
        $st = DB::conn()->prepare(
            'SELECT * FROM api_keys WHERE user_id=? AND status="active" ORDER BY id DESC LIMIT 1'
        );
        $st->execute([$userId]);
        return $st->fetch() ?: null;
    }

    public static function findByFullKey(string $fullKey): ?array
    {
        $hash = hash('sha256', $fullKey);
        $st = DB::conn()->prepare(
            'SELECT k.*, u.username, u.email, u.role, u.status AS user_status, u.balance, u.currency
             FROM api_keys k JOIN users u ON u.id=k.user_id
             WHERE k.key_hash=? AND k.status="active" LIMIT 1'
        );
        $st->execute([$hash]);
        return $st->fetch() ?: null;
    }

    public static function touch(int $id, string $ip): void
    {
        DB::conn()->prepare(
            'UPDATE api_keys SET last_used_at=NOW(), last_used_ip=?, total_requests=total_requests+1 WHERE id=?'
        )->execute([$ip, $id]);
    }

    public static function stats(int $userId): array
    {
        $pdo = DB::conn();
        $st = $pdo->prepare(
            "SELECT k.id, k.key_prefix, k.label, k.status, k.rate_limit, k.total_requests, k.last_used_at, k.last_used_ip,
                    (SELECT COUNT(*) FROM api_logs l WHERE l.api_key_id=k.id AND l.created_at >= (NOW() - INTERVAL 24 HOUR)) AS req_24h
             FROM api_keys k WHERE k.user_id=? ORDER BY k.id DESC"
        );
        $st->execute([$userId]);
        return $st->fetchAll();
    }
}