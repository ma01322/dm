<?php
declare(strict_types=1);
namespace Models;

use Core\Model;

final class Order extends Model
{
    protected static string $table = 'orders';

    public static function forUser(int $userId, int $limit = 20): array
    {
        $st = self::pdo()->prepare(
            "SELECT o.*, s.name AS service_name
             FROM orders o LEFT JOIN services s ON s.id=o.service_id
             WHERE o.user_id=? ORDER BY o.id DESC LIMIT ?"
        );
        $st->bindValue(1, $userId, \PDO::PARAM_INT);
        $st->bindValue(2, $limit, \PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }

    public static function byProviderOrderId(int $providerId, string $providerOrderId): ?array
    {
        $st = self::pdo()->prepare('SELECT * FROM orders WHERE provider_id=? AND provider_order_id=? LIMIT 1');
        $st->execute([$providerId, $providerOrderId]);
        return $st->fetch() ?: null;
    }
}