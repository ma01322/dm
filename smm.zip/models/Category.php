<?php
declare(strict_types=1);
namespace Models;

use Core\Model;

final class Category extends Model
{
    protected static string $table = 'categories';

    public static function active(): array
    {
        return self::pdo()->query("SELECT * FROM categories WHERE status='active' ORDER BY sort_order, name")
            ->fetchAll();
    }
}