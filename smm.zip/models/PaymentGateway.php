<?php
declare(strict_types=1);
namespace Models;

use Core\Model;

final class PaymentGateway extends Model
{
    protected static string $table = 'payment_gateways';

    public static function active(): array
    {
        return self::pdo()->query("SELECT * FROM payment_gateways WHERE status='active' ORDER BY sort_order")->fetchAll();
    }
}