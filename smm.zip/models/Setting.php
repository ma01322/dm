<?php
declare(strict_types=1);
namespace Models;

use Core\Model;
use DB;

final class Setting extends Model
{
    protected static string $table = 'settings';
    private static array $cache = [];

    public static function get(string $key, mixed $default = null): mixed
    {
        if (array_key_exists($key, self::$cache)) return self::$cache[$key];
        $st = DB::conn()->prepare('SELECT svalue FROM settings WHERE skey = ? LIMIT 1');
        $st->execute([$key]);
        $v = $st->fetchColumn();
        return self::$cache[$key] = ($v === false ? $default : $v);
    }

    public static function set(string $key, string $value): void
    {
        $st = DB::conn()->prepare(
            'INSERT INTO settings (skey, svalue) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)'
        );
        $st->execute([$key, $value]);
        self::$cache[$key] = $value;
    }

    public static function allAutoload(): array
    {
        $rows = DB::conn()->query('SELECT skey, svalue FROM settings WHERE autoload = 1')->fetchAll();
        $out = [];
        foreach ($rows as $r) { $out[$r['skey']] = $r['svalue']; self::$cache[$r['skey']] = $r['svalue']; }
        return $out;
    }
}