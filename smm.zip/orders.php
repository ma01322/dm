<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$userTitle = 'Orders';
$me = \Auth::requireLogin();
$pdo = \DB::conn();

$status = $_GET['status'] ?? '';
$page = max(1,(int)($_GET['page'] ?? 1));
$per = 25; $off = ($page-1)*$per;

$where = ['o.user_id = ?']; $args = [(int)$me['id']];
if ($status) { $where[] = 'o.status = ?'; $args[] = $status; }
$sqlWhere = 'WHERE '.implode(' AND ', $where);

$stc = $pdo->prepare("SELECT COUNT(*) FROM orders o $sqlWhere"); $stc->execute($args); $total = (int)$stc->fetchColumn();
$st = $pdo->prepare("SELECT o.*, s.name AS service FROM orders o LEFT JOIN services s ON s.id=o.service_id $sqlWhere ORDER BY o.id DESC LIMIT $per OFFSET $off");
$st->execute($args);
$rows = $st->fetchAll();

$cur = \Models\Setting::get('currency_symbol','৳');
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="card smm-card mb-3"><div class="card-body">
  <form class="row g-2" method="get">
    <div class="col-md-3">
      <select name="status" class="form-select">
        <option value="">All statuses</option>
        <?php foreach (['pending','processing','in_progress','completed','partial','canceled','refunded','failed'] as $s): ?>
          <option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= str_replace('_',' ',$s) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2"><button class="btn btn-primary w-100">Filter</button></div>
  </form>
</div></div>

<div class="card smm-card">
  <div class="table-responsive">
    <table class="table smm-table align-middle mb-0">
      <thead><tr><th>#</th><th>Service</th><th>Link</th><th>Qty</th><th>Charge</th><th>Start</th><th>Remains</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $o): ?>
        <tr>
          <td><a href="/user/order-view.php?id=<?= (int)$o['id'] ?>">#<?= (int)$o['id'] ?></a></td>
          <td class="text-truncate" style="max-width:200px"><?= e($o['service'] ?? '—') ?></td>
          <td class="text-truncate small" style="max-width:180px"><a href="<?= e($o['link']) ?>" target="_blank" rel="noopener"><?= e($o['link']) ?></a></td>
          <td><?= number_format((int)$o['quantity']) ?></td>
          <td><?= $cur.number_format((float)$o['charge'],2) ?></td>
          <td><?= (int)($o['start_count'] ?? 0) ?></td>
          <td><?= (int)($o['remains'] ?? 0) ?></td>
          <td><span class="smm-badge st-<?= e($o['status']) ?>"><?= e(str_replace('_',' ',$o['status'])) ?></span></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted py-4">No orders.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php $tp = max(1,(int)ceil($total/$per)); if ($tp>1): ?>
  <div class="card-body d-flex justify-content-between align-items-center">
    <div class="small text-muted"><?= number_format($total) ?> orders</div>
    <nav><ul class="pagination pagination-sm mb-0">
      <?php for ($i=1;$i<=$tp;$i++): ?>
        <li class="page-item <?= $i===$page?'active':'' ?>"><a class="page-link" href="?page=<?= $i ?>&status=<?= e($status) ?>"><?= $i ?></a></li>
      <?php endfor; ?>
    </ul></nav>
  </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>