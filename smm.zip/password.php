<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$userTitle = 'Change Password';
$me = \Auth::requireLogin();

$msg=null; $err=null;
if (is_post()) {
    \Csrf::require();
    $current = (string)($_POST['current'] ?? '');
    $new     = (string)($_POST['new'] ?? '');
    $confirm = (string)($_POST['confirm'] ?? '');

    if (!\Models\User::verifyPassword($me, $current)) $err = 'Current password is incorrect.';
    elseif ($new !== $confirm) $err = 'New passwords do not match.';
    else {
        $v = (new \Validator(['new'=>$new]))->password('new');
        if ($v->fails()) $err = $v->firstError();
        else {
            \Models\User::update((int)$me['id'], ['password_hash' => password_hash($new, PASSWORD_BCRYPT, ['cost'=>12])]);
            \Logger::activity((int)$me['id'], $me['role'], 'user.password_change', 'user', (int)$me['id']);
            $msg = 'Password changed.';
        }
    }
}
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>
<?php if ($msg): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>

<div class="card smm-card" style="max-width:520px">
  <div class="card-body">
    <form method="post" autocomplete="off">
      <?= \Csrf::field() ?>
      <div class="mb-3"><label class="form-label small">Current password</label>
        <input type="password" name="current" class="form-control" required></div>
      <div class="mb-3"><label class="form-label small">New password</label>
        <input type="password" name="new" class="form-control" required></div>
      <div class="mb-3"><label class="form-label small">Confirm new password</label>
        <input type="password" name="confirm" class="form-control" required></div>
      <button class="btn btn-primary">Update password</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>