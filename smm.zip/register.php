<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

if (\Auth::check()) redirect('/user/index.php');

$error = null; $success = null;
if (is_post()) {
    \Csrf::require();
    $v = (new \Validator($_POST))
        ->username('username')
        ->email('email')
        ->password('password');
    if ($v->fails()) {
        $error = $v->firstError();
    } else {
        $c = $v->clean();
        $role = ($_POST['account_type'] ?? 'customer') === 'reseller' ? 'reseller' : 'customer';
        $res = \Services\AuthService::register($c['username'], $c['email'], $c['password'], $role);
        if ($res['ok']) $success = 'Account created. You can now log in.';
        else $error = $res['error'];
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Register — <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5" style="max-width:520px">
  <div class="card shadow-sm border-0">
    <div class="card-body p-4">
      <h4 class="mb-3 text-center">Create account</h4>
      <?php if ($error): ?><div class="alert alert-danger py-2 small"><?= e($error) ?></div><?php endif; ?>
      <?php if ($success): ?><div class="alert alert-success py-2 small"><?= e($success) ?></div><?php endif; ?>
      <form method="post" autocomplete="off" novalidate>
        <?= \Csrf::field() ?>
        <div class="row g-3">
          <div class="col-12">
            <label class="form-label small">Username</label>
            <input name="username" class="form-control" required value="<?= e((string)($_POST['username'] ?? '')) ?>">
          </div>
          <div class="col-12">
            <label class="form-label small">Email</label>
            <input type="email" name="email" class="form-control" required value="<?= e((string)($_POST['email'] ?? '')) ?>">
          </div>
          <div class="col-12">
            <label class="form-label small">Password</label>
            <input type="password" name="password" class="form-control" required>
            <div class="form-text">Min 8 chars, letters + numbers.</div>
          </div>
          <div class="col-12">
            <label class="form-label small">Account type</label>
            <select name="account_type" class="form-select">
              <option value="customer">Customer</option>
              <option value="reseller">Reseller (API access)</option>
            </select>
          </div>
          <div class="col-12">
            <button class="btn btn-primary w-100">Create account</button>
          </div>
        </div>
      </form>
      <div class="text-center mt-3 small"><a href="/login.php">Already have an account?</a></div>
    </div>
  </div>
</div>
</body>
</html>