# SMM Reseller Panel

A production-ready **Master SMM Panel** in PHP 8.2+ / MySQL 8+ with:

- Direct customer panel
- Reseller panel + full REST API v2
- Multi-provider upstream adapter system
- Wallet + deposit + transaction engine (decimal-safe, transaction-isolated)
- Order engine with auto-dispatch, auto-refund and cron sync
- Admin panel with reporting
- Modular payment gateway abstraction (bKash / Nagad / Manual ready)

## 1. Requirements

- PHP 8.2+ with `pdo_mysql`, `curl`, `openssl`, `mbstring`, `json`, `fileinfo`
- MySQL 8.0+ / MariaDB 10.5+
- Apache with `mod_rewrite` (or Nginx equivalent)
- Composer is optional (no external dependencies required)

## 2. Install

1. Upload the project and point your vhost root to the project folder.
2. Ensure `logs/` and `uploads/` are writable by PHP-FPM/Apache.
3. Copy `.env.example` to `.env` (or let the installer create it).
4. Open `https://yourdomain/install/` in a browser.
   The installer checks extensions, imports `database/schema.sql`, and creates the first admin.
5. Delete `/install/` or leave `install.lock` in place.

## 3. Configuration

Edit `.env`:
