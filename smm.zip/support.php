<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$userTitle = 'Support';
$me = \Auth::requireLogin();
$pdo = \DB::conn();

if (is_post()) {
    \Csrf::require();
    $v = (new \Validator($_POST))->required('subject','Subject')->required('message','Message');
    if ($v->fails()) { $err = $v->firstError(); }
    else {
        $c = $v->clean();
        $tid = \Core\Model::insert; // placeholder overwritten below
        $st = $pdo->prepare("INSERT INTO tickets (user_id, subject) VALUES (?,?)");
        $st->execute([(int)$me['id'], $c['subject']]);
        $tid = (int)$pdo->lastInsertId();
        $st = $pdo->prepare("INSERT INTO ticket_messages (ticket_id, sender_id, sender_role, message) VALUES (?,?,?,?)");
        $st->execute([$tid, (int)$me['id'], $me['role'], $c['message']]);
        \Logger::activity((int)$me['id'], $me['role'], 'ticket.create', 'ticket', $tid);
        $msg = 'Ticket created.';
    }
}

$st = $pdo->prepare("SELECT t.*, (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id=t.id) AS msgs FROM tickets t WHERE t.user_id=? ORDER BY t.id DESC");
$st->execute([(int)$me['id']]);
$tickets = $st->fetchAll();

include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>
<?php if (!empty($msg)): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
<?php if (!empty($err)): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="card smm-card"><div class="card-body">
      <h6>Open a new ticket</h6>
      <form method="post">
        <?= \Csrf::field() ?>
        <div class="mb-2"><input name="subject" class="form-control" placeholder="Subject" required maxlength="200"></div>
        <div class="mb-2"><textarea name="message" class="form-control" rows="5" placeholder="Describe your issue" required></textarea></div>
        <button class="btn btn-primary w-100">Submit ticket</button>
      </form>
    </div></div>
  </div>
  <div class="col-lg-7">
    <div class="card smm-card"><div class="card-body">
      <h6>Your tickets</h6>
      <div class="list-group list-group-flush">
        <?php foreach ($tickets as $t): ?>
          <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" href="/user/ticket-view.php?id=<?= (int)$t['id'] ?>">
            <div>
              <div class="fw-semibold"><?= e($t['subject']) ?></div>
              <div class="small text-muted">#<?= (int)$t['id'] ?> · <?= e($t['created_at']) ?></div>
            </div>
            <span class="badge bg-secondary"><?= e($t['status']) ?></span>
          </a>
        <?php endforeach; ?>
        <?php if (!$tickets): ?><div class="text-muted small py-3">No tickets yet.</div><?php endif; ?>
      </div>
    </div></div>
  </div>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>