-- Optional demo seed data. Run AFTER schema.sql.
-- Insert a demo manual payment gateway
INSERT INTO `payment_gateways` (`code`,`name`,`adapter`,`status`,`mode`,`min_deposit`,`max_deposit`,`fee_percent`,`fee_fixed`,`instructions`,`sort_order`)
VALUES
  ('manual_bkash','bKash (Manual)','manual','active','live',10.00,100000.00,0.000,0.000,'Send Money to 01XXXXXXXXX and submit TrxID to support.',10),
  ('manual_nagad','Nagad (Manual)','manual','active','live',10.00,100000.00,0.000,0.000,'Send Money to 01XXXXXXXXX and submit TrxID to support.',20)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);