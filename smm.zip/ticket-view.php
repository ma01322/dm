<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$userTitle = 'Ticket';
$me = \Auth::requireLogin();
$pdo = \DB::conn();
$id = (int)($_GET['id'] ?? 0);

$st = $pdo->prepare("SELECT * FROM tickets WHERE id=? AND user_id=? LIMIT 1");
$st->execute([$id, (int)$me['id']]);
$t = $st->fetch();
if (!$t) { http_response_code(404); exit('Ticket not found'); }

if (is_post()) {
    \Csrf::require();
    $msg = trim((string)($_POST['message'] ?? ''));
    if ($msg !== '') {
        $st = $pdo->prepare("INSERT INTO ticket_messages (ticket_id, sender_id, sender_role, message) VALUES (?,?,?,?)");
        $st->execute([$id, (int)$me['id'], $me['role'], $msg]);
        $pdo->prepare("UPDATE tickets SET status='pending', updated_at=NOW() WHERE id=?")->execute([$id]);
    }
}

$st = $pdo->prepare("SELECT * FROM ticket_messages WHERE ticket_id=? ORDER BY id ASC");
$st->execute([$id]);
$msgs = $st->fetchAll();

include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>
<div class="card smm-card">
  <div class="card-header bg-white d-flex justify-content-between">
    <strong>#<?= (int)$t['id'] ?> — <?= e($t['subject']) ?></strong>
    <span class="badge bg-secondary"><?= e($t['status']) ?></span>
  </div>
  <div class="card-body" style="max-height:55vh;overflow:auto">
    <?php foreach ($msgs as $m): $mine = (int)$m['sender_id'] === (int)$me['id']; ?>
      <div class="mb-3 <?= $mine ? 'text-end' : '' ?>">
        <div class="d-inline-block px-3 py-2 rounded <?= $mine ? 'bg-primary text-white' : 'bg-light' ?>" style="max-width:80%">
          <div class="small opacity-75"><?= e($m['sender_role']) ?> · <?= e($m['created_at']) ?></div>
          <div><?= nl2br(e($m['message'])) ?></div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="card-footer bg-white">
    <form method="post" class="d-flex gap-2">
      <?= \Csrf::field() ?>
      <input name="message" class="form-control" placeholder="Type a reply..." required>
      <button class="btn btn-primary">Send</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>