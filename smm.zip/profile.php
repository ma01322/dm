<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$userTitle = 'Profile';
$me = \Auth::requireLogin();

$msg = null; $err = null;
if (is_post()) {
    \Csrf::require();
    $v = (new \Validator($_POST))->required('full_name','Full name');
    if ($v->fails()) $err = $v->firstError();
    else {
        $c = $v->clean();
        \Models\User::update((int)$me['id'], [
            'full_name' => $c['full_name'],
            'phone'     => trim((string)($_POST['phone'] ?? '')),
        ]);
        $msg = 'Profile updated.';
        $me = \Models\User::find((int)$me['id']);
    }
}
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>
<?php if ($msg): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>

<div class="card smm-card" style="max-width:640px">
  <div class="card-body">
    <form method="post">
      <?= \Csrf::field() ?>
      <div class="mb-3"><label class="form-label small">Username</label>
        <input class="form-control" value="<?= e($me['username']) ?>" disabled></div>
      <div class="mb-3"><label class="form-label small">Email</label>
        <input class="form-control" value="<?= e($me['email']) ?>" disabled></div>
      <div class="mb-3"><label class="form-label small">Full name</label>
        <input name="full_name" class="form-control" value="<?= e((string)$me['full_name']) ?>"></div>
      <div class="mb-3"><label class="form-label small">Phone</label>
        <input name="phone" class="form-control" value="<?= e((string)$me['phone']) ?>"></div>
      <button class="btn btn-primary">Save changes</button>
    </form>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>