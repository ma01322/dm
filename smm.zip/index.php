<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

$installed = \Models\Setting::get('installed', '0');
if ($installed !== '1' && !str_starts_with($_SERVER['REQUEST_URI'], '/install')) {
    redirect('/install/index.php');
}

include __DIR__ . '/../views/home.php';