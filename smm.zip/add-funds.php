<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$userTitle = 'Add Funds';
$me = \Auth::requireLogin();
$pdo = \DB::conn();
$cur = \Models\Setting::get('currency_symbol','৳');

$gateways = $pdo->query("SELECT id, code, name, min_deposit, max_deposit, instructions FROM payment_gateways WHERE status='active' ORDER BY sort_order")->fetchAll();

$msg = null; $err = null;
if (is_post()) {
    \Csrf::require();
    $gid = (int)($_POST['gateway_id'] ?? 0);
    $amt = (float)($_POST['amount'] ?? 0);
    try {
        $result = \Services\DepositService::create((int)$me['id'], $gid, $amt);
        if (!empty($result['redirect'])) redirect($result['redirect']);
        $msg = $result['message'] ?? 'Deposit initiated.';
    } catch (\Throwable $e) {
        $err = $e->getMessage();
    }
}

include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>
<?php if ($msg): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="card smm-card">
      <div class="card-body">
        <h5 class="mb-3">Add funds</h5>
        <?php if (!$gateways): ?>
          <div class="alert alert-warning py-2 small mb-0">No payment gateways are currently active. Please contact support.</div>
        <?php else: ?>
        <form method="post">
          <?= \Csrf::field() ?>
          <div class="mb-3">
            <label class="form-label small">Payment method</label>
            <select name="gateway_id" id="gatewaySelect" class="form-select" required>
              <option value="">— Select —</option>
              <?php foreach ($gateways as $g): ?>
                <option value="<?= (int)$g['id'] ?>" data-min="<?= (float)$g['min_deposit'] ?>" data-max="<?= (float)$g['max_deposit'] ?>" data-note="<?= e((string)$g['instructions']) ?>">
                  <?= e($g['name']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label small">Amount (<?= e($cur) ?>)</label>
            <input type="number" step="0.01" name="amount" id="amountInput" class="form-control" required>
            <div class="form-text" id="limitHint"></div>
          </div>
          <div id="instructions" class="alert alert-light border small d-none"></div>
          <button class="btn btn-primary">Continue</button>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card smm-card">
      <div class="card-header bg-white"><strong>Current balance</strong></div>
      <div class="card-body">
        <div class="fs-3 fw-bold"><?= $cur.number_format((float)$me['balance'],2) ?></div>
        <div class="small text-muted">Total deposited: <?= $cur.number_format((float)$me['total_deposit'],2) ?></div>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  const sel = document.getElementById('gatewaySelect');
  const amt = document.getElementById('amountInput');
  const hint= document.getElementById('limitHint');
  const ins = document.getElementById('instructions');
  if(!sel) return;
  sel.addEventListener('change', () => {
    const o = sel.options[sel.selectedIndex];
    const min = o.dataset.min, max = o.dataset.max, note = o.dataset.note || '';
    if (sel.value) {
      amt.min = min; amt.max = max;
      hint.textContent = `Min ${min} — Max ${max}`;
      if (note) { ins.textContent = note; ins.classList.remove('d-none'); }
      else ins.classList.add('d-none');
    } else { hint.textContent=''; ins.classList.add('d-none'); }
  });
})();
</script>

<?php include __DIR__ . '/partials/footer.php'; ?>