<?php
declare(strict_types=1);
/**
 * Simple guided installer.
 * Steps: requirements → DB → admin → done.
 */
$root = dirname(__DIR__);
$lock = $root . '/install/install.lock';
if (is_file($lock)) {
    exit('<h1>Already installed.</h1><p>Delete <code>install/install.lock</code> to reinstall.</p>');
}

$step = (int)($_GET['step'] ?? 1);
$errors = [];

$requirements = [
    'PHP >= 8.2'          => version_compare(PHP_VERSION, '8.2.0', '>='),
    'PDO extension'       => extension_loaded('pdo'),
    'pdo_mysql'           => extension_loaded('pdo_mysql'),
    'openssl'             => extension_loaded('openssl'),
    'curl'                => extension_loaded('curl'),
    'mbstring'            => extension_loaded('mbstring'),
    'json'                => extension_loaded('json'),
    'fileinfo'            => extension_loaded('fileinfo'),
];
$allOk = !in_array(false, $requirements, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === 2) {
        $host = trim((string)($_POST['db_host'] ?? '127.0.0.1'));
        $port = (int)($_POST['db_port'] ?? 3306);
        $name = trim((string)($_POST['db_name'] ?? ''));
        $user = trim((string)($_POST['db_user'] ?? ''));
        $pass = (string)($_POST['db_password'] ?? '');
        try {
            $pdo = new PDO("mysql:host=$host;port=$port;charset=utf8mb4", $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$name`");
            $sql = file_get_contents($root . '/database/schema.sql');
            $pdo->exec($sql);
            // Write .env
            $env = file_get_contents($root . '/.env.example');
            $env = preg_replace('/DB_HOST=.*/','DB_HOST=' . $host, $env);
            $env = preg_replace('/DB_PORT=.*/','DB_PORT=' . $port, $env);
            $env = preg_replace('/DB_NAME=.*/','DB_NAME=' . $name, $env);
            $env = preg_replace('/DB_USER=.*/','DB_USER=' . $user, $env);
            $env = preg_replace('/DB_PASSWORD=.*/','DB_PASSWORD=' . $pass, $env);
            $appKey = base64_encode(random_bytes(32));
            $env = preg_replace('/APP_KEY=.*/','APP_KEY=' . $appKey, $env);
            file_put_contents($root . '/.env', $env);
            header('Location: index.php?step=3'); exit;
        } catch (\Throwable $e) {
            $errors[] = 'DB error: ' . $e->getMessage();
        }
    }
    if ($step === 3) {
        require_once $root . '/config/app.php';
        $username = trim((string)($_POST['username'] ?? 'admin'));
        $email    = trim((string)($_POST['email'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        if (strlen($password) < 8) $errors[] = 'Password must be ≥ 8 chars';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email';
        if (!$errors) {
            $id = \Models\User::create($username, $email, $password, 'admin');
            \Models\Setting::set('installed', '1');
            file_put_contents($lock, 'Installed at ' . gmdate('c'));
            header('Location: index.php?step=4'); exit;
        }
    }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Installer</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light"><div class="container py-5" style="max-width:720px">
<h2 class="mb-4">SMM Panel Installer</h2>
<?php foreach ($errors as $e): ?><div class="alert alert-danger"><?= htmlspecialchars($e) ?></div><?php endforeach; ?>

<?php if ($step===1): ?>
  <div class="card"><div class="card-body">
  <h5>Requirements</h5>
  <ul class="list-group list-group-flush">
    <?php foreach ($requirements as $k=>$v): ?>
      <li class="list-group-item d-flex justify-content-between"><span><?= htmlspecialchars($k) ?></span>
      <span class="badge <?= $v?'bg-success':'bg-danger' ?>"><?= $v?'OK':'FAIL' ?></span></li>
    <?php endforeach; ?>
  </ul>
  <?php if ($allOk): ?><a class="btn btn-primary mt-3" href="?step=2">Continue</a>
  <?php else: ?><div class="alert alert-warning mt-3">Fix missing extensions.</div><?php endif; ?>
  </div></div>

<?php elseif ($step===2): ?>
  <div class="card"><div class="card-body">
  <h5>Database</h5>
  <form method="post">
    <div class="row g-2">
      <div class="col-md-6"><label class="form-label small">Host</label><input name="db_host" class="form-control" value="127.0.0.1"></div>
      <div class="col-md-3"><label class="form-label small">Port</label><input name="db_port" class="form-control" value="3306"></div>
      <div class="col-md-6"><label class="form-label small">DB Name</label><input name="db_name" class="form-control" value="smm_panel"></div>
      <div class="col-md-6"><label class="form-label small">DB User</label><input name="db_user" class="form-control" value="root"></div>
      <div class="col-md-6"><label class="form-label small">DB Password</label><input name="db_password" type="password" class="form-control"></div>
    </div>
    <button class="btn btn-primary mt-3">Install schema</button>
  </form>
  </div></div>

<?php elseif ($step===3): ?>
  <div class="card"><div class="card-body">
  <h5>Admin account</h5>
  <form method="post">
    <div class="mb-2"><label class="form-label small">Username</label><input name="username" class="form-control" value="admin"></div>
    <div class="mb-2"><label class="form-label small">Email</label><input name="email" type="email" class="form-control" required></div>
    <div class="mb-2"><label class="form-label small">Password</label><input name="password" type="password" class="form-control" required></div>
    <button class="btn btn-primary">Create admin</button>
  </form>
  </div></div>

<?php elseif ($step===4): ?>
  <div class="alert alert-success">
    <h4>Installation complete 🎉</h4>
    <p>Now delete <code>/install</code> or keep the lock file. Login at <a href="/admin/login.php">/admin/login.php</a>.</p>
  </div>
<?php endif; ?>
</div></body></html>