<?php echo 'Admin setup';
