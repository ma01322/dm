<?php echo 'Database setup';
