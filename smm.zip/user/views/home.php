<?php
declare(strict_types=1);
if (!defined('APP_CONFIG_LOADED')) { require_once __DIR__ . '/../config/app.php'; }

$services = \DB::conn()->query(
    "SELECT s.id, s.name, s.customer_price, s.min_quantity, s.max_quantity, c.name AS category
     FROM services s LEFT JOIN categories c ON c.id = s.category_id
     WHERE s.status='active' AND s.visible_website=1
     ORDER BY s.sort_order ASC, s.id ASC LIMIT 12"
)->fetchAll();

$cats = \DB::conn()->query(
    "SELECT id, name, icon FROM categories WHERE status='active' ORDER BY sort_order ASC LIMIT 12"
)->fetchAll();

$siteName = \Models\Setting::get('site_name', APP_NAME);
$currency = \Models\Setting::get('currency_symbol', '৳');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?= e($siteName) ?> — fastest SMM panel with cheapest rates. Instagram, TikTok, YouTube, Facebook & more.">
<title><?= e($siteName) ?> — #1 SMM Panel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="/assets/css/app.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top smm-nav">
  <div class="container">
    <a class="navbar-brand fw-bold" href="/">
      <i class="fa-solid fa-bolt me-1 text-warning"></i><?= e($siteName) ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav ms-auto align-items-lg-center">
        <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="#features">Features</a></li>
        <li class="nav-item"><a class="nav-link" href="#how">How it works</a></li>
        <li class="nav-item"><a class="nav-link" href="#faq">FAQ</a></li>
        <li class="nav-item"><a class="nav-link" href="/api/v2/" target="_blank">API</a></li>
        <?php if (\Auth::check()): ?>
          <li class="nav-item"><a class="btn btn-warning btn-sm ms-lg-2" href="/user/index.php">Dashboard</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="/login.php">Login</a></li>
          <li class="nav-item"><a class="btn btn-warning btn-sm ms-lg-2" href="/register.php">Sign up</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<section class="smm-hero text-white">
  <div class="container py-5">
    <div class="row align-items-center g-5">
      <div class="col-lg-6">
        <span class="badge bg-warning text-dark mb-3">#1 SMM Panel</span>
        <h1 class="display-4 fw-bold mb-3">Grow your social media <span class="text-warning">instantly</span>.</h1>
        <p class="lead mb-4 opacity-75">
          Instagram, TikTok, YouTube, Facebook, Twitter/X and 100+ services.
          Cheapest rates, fastest delivery, 24/7 support — built for creators, agencies and resellers.
        </p>
        <div class="d-flex flex-wrap gap-2 mb-4">
          <a href="/register.php" class="btn btn-warning btn-lg px-4"><i class="fa-solid fa-rocket me-2"></i>Get started</a>
          <a href="#services" class="btn btn-outline-light btn-lg px-4">Browse services</a>
        </div>
        <div class="row g-4 pt-2">
          <div class="col-4"><div class="fw-bold fs-4">120K+</div><div class="small opacity-75">Orders delivered</div></div>
          <div class="col-4"><div class="fw-bold fs-4">8K+</div><div class="small opacity-75">Active resellers</div></div>
          <div class="col-4"><div class="fw-bold fs-4">99.2%</div><div class="small opacity-75">Uptime</div></div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="card smm-hero-card border-0 shadow-lg">
          <div class="card-body p-4">
            <div class="d-flex align-items-center mb-3">
              <div class="me-3 text-warning fs-3"><i class="fa-solid fa-chart-line"></i></div>
              <div>
                <div class="fw-bold">Instant Order Placement</div>
                <div class="small text-muted">Pay from wallet — auto-dispatch to provider</div>
              </div>
            </div>
            <div class="row g-3 small">
              <div class="col-6"><div class="p-3 rounded bg-light"><i class="fa-brands fa-instagram text-danger me-2"></i>Instagram</div></div>
              <div class="col-6"><div class="p-3 rounded bg-light"><i class="fa-brands fa-tiktok me-2"></i>TikTok</div></div>
              <div class="col-6"><div class="p-3 rounded bg-light"><i class="fa-brands fa-youtube text-danger me-2"></i>YouTube</div></div>
              <div class="col-6"><div class="p-3 rounded bg-light"><i class="fa-brands fa-facebook text-primary me-2"></i>Facebook</div></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="services" class="py-5">
  <div class="container">
    <div class="text-center mb-5">
      <h2 class="fw-bold mb-2">Popular Services</h2>
      <p class="text-muted mb-0">Live rates, instant delivery, real-time tracking.</p>
    </div>
    <div class="row g-3">
      <?php foreach ($services as $s): ?>
        <div class="col-md-6 col-lg-4">
          <div class="card h-100 border-0 shadow-sm smm-service-card">
            <div class="card-body">
              <div class="small text-muted mb-1"><i class="fa-solid fa-tag me-1"></i><?= e($s['category'] ?? 'General') ?></div>
              <div class="fw-semibold mb-2"><?= e($s['name']) ?></div>
              <div class="d-flex justify-content-between align-items-center mt-3">
                <div class="text-primary fw-bold"><?= e($currency) ?><?= number_format((float)$s['customer_price'], 4) ?><span class="text-muted small">/1k</span></div>
                <div class="small text-muted"><?= (int)$s['min_quantity'] ?>–<?= (int)$s['max_quantity'] ?></div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-4">
      <a href="/register.php" class="btn btn-primary px-4"><i class="fa-solid fa-arrow-right me-2"></i>See all services</a>
    </div>
  </div>
</section>

<section id="features" class="py-5 bg-light">
  <div class="container">
    <div class="text-center mb-5">
      <h2 class="fw-bold">Why choose us</h2>
      <p class="text-muted">Built for scale, speed and reliability.</p>
    </div>
    <div class="row g-4">
      <?php
      $features = [
        ['fa-bolt','Instant Delivery','Orders auto-dispatch to providers within seconds.'],
        ['fa-wallet','Secure Wallet','Add funds with bKash, Nagad, Rocket and more.'],
        ['fa-code','Reseller API','Full REST API with per-key rate limits and logs.'],
        ['fa-headset','24/7 Support','Ticketing system with admin replies.'],
        ['fa-shield-halved','Secure','Hashed passwords, CSRF, encrypted provider keys.'],
        ['fa-chart-pie','Analytics','Real-time order status and profit reports.'],
      ];
      foreach ($features as [$icon,$title,$desc]): ?>
        <div class="col-md-6 col-lg-4">
          <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
              <div class="smm-feature-icon mb-3"><i class="fa-solid <?= e($icon) ?>"></i></div>
              <h6 class="fw-bold"><?= e($title) ?></h6>
              <p class="text-muted small mb-0"><?= e($desc) ?></p>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="how" class="py-5">
  <div class="container">
    <div class="text-center mb-5">
      <h2 class="fw-bold">How it works</h2>
      <p class="text-muted">Start growing in 3 simple steps.</p>
    </div>
    <div class="row g-4">
      <?php
      $steps = [
        ['Create account','Sign up free in seconds — no hidden fees.'],
        ['Add funds','Top-up via bKash/Nagad/Rocket or manual deposit.'],
        ['Place order','Choose a service, paste link, order runs instantly.'],
      ];
      foreach ($steps as $i => [$t,$d]): ?>
        <div class="col-md-4 text-center">
          <div class="smm-step-circle mx-auto mb-3"><?= $i+1 ?></div>
          <h5 class="fw-bold"><?= e($t) ?></h5>
          <p class="text-muted small"><?= e($d) ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="faq" class="py-5 bg-light">
  <div class="container" style="max-width:820px">
    <h2 class="fw-bold text-center mb-5">FAQ</h2>
    <div class="accordion" id="faqAcc">
      <?php
      $faqs = [
        ['What is an SMM panel?','An SMM panel lets you buy social media growth services like likes, followers and views at wholesale prices.'],
        ['How do I add funds?','Log in, open Add Funds, choose a gateway (bKash/Nagad/Rocket/manual) and follow the instructions.'],
        ['Do you offer reseller API?','Yes. Resellers get a personal API key and full REST API — see /api/v2 docs.'],
        ['What if an order fails?','Failed orders are automatically refunded to your wallet.'],
        ['Is there a minimum deposit?','Yes — see Add Funds page for the active gateway limits.'],
      ];
      foreach ($faqs as $i => [$q,$a]): ?>
        <div class="accordion-item border-0 mb-2 shadow-sm">
          <h2 class="accordion-header">
            <button class="accordion-button collapsed fw-semibold" data-bs-toggle="collapse" data-bs-target="#f<?= $i ?>">
              <?= e($q) ?>
            </button>
          </h2>
          <div id="f<?= $i ?>" class="accordion-collapse collapse" data-bs-parent="#faqAcc">
            <div class="accordion-body text-muted small"><?= e($a) ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="py-5 smm-cta text-white">
  <div class="container text-center">
    <h2 class="fw-bold mb-3">Ready to grow?</h2>
    <p class="opacity-75 mb-4">Join thousands of creators and resellers using <?= e($siteName) ?>.</p>
    <a href="/register.php" class="btn btn-warning btn-lg px-5">Create free account</a>
  </div>
</section>

<footer class="bg-dark text-white-50 py-4">
  <div class="container d-flex flex-wrap justify-content-between align-items-center small">
    <div>&copy; <?= date('Y') ?> <?= e($siteName) ?>. All rights reserved.</div>
    <div class="d-flex gap-3">
      <a class="text-white-50" href="/page.php?p=terms">Terms</a>
      <a class="text-white-50" href="/page.php?p=privacy">Privacy</a>
      <a class="text-white-50" href="mailto:<?= e(\Models\Setting::get('support_email','support@example.com')) ?>">Contact</a>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>