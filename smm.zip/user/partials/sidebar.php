<?php
declare(strict_types=1);
if (!defined('APP_CONFIG_LOADED')) { require_once dirname(__DIR__, 2) . '/config/app.php'; }
$cur = basename($_SERVER['PHP_SELF']);
$a = fn(string $f) => $cur === $f ? 'active' : '';
?>
<aside class="smm-sidebar">
  <div class="brand"><i class="fa-solid fa-bolt me-1"></i><?= e(\Models\Setting::get('site_name', APP_NAME)) ?></div>
  <nav class="py-2 flex-grow-1">
    <a class="<?= $a('index.php') ?>" href="/user/index.php"><i class="fa-solid fa-gauge-high"></i>Dashboard</a>
    <a class="<?= $a('new-order.php') ?>" href="/user/new-order.php"><i class="fa-solid fa-cart-plus"></i>New Order</a>
    <a class="<?= $a('orders.php') ?>" href="/user/orders.php"><i class="fa-solid fa-receipt"></i>Orders</a>
    <a class="<?= $a('services.php') ?>" href="/user/services.php"><i class="fa-solid fa-cubes"></i>Services</a>

    <div class="section">Wallet</div>
    <a class="<?= $a('add-funds.php') ?>" href="/user/add-funds.php"><i class="fa-solid fa-circle-dollar-to-slot"></i>Add Funds</a>
    <a class="<?= $a('transactions.php') ?>" href="/user/transactions.php"><i class="fa-solid fa-arrow-right-arrow-left"></i>Transactions</a>

    <?php if ($isReseller): ?>
      <div class="section">Reseller</div>
      <a class="<?= $a('api.php') ?>" href="/reseller/api.php"><i class="fa-solid fa-key"></i>API</a>
      <a class="<?= $a('api-docs.php') ?>" href="/reseller/api-docs.php"><i class="fa-solid fa-book"></i>API Docs</a>
    <?php endif; ?>

    <div class="section">Account</div>
    <a class="<?= $a('profile.php') ?>" href="/user/profile.php"><i class="fa-solid fa-user"></i>Profile</a>
    <a class="<?= $a('password.php') ?>" href="/user/password.php"><i class="fa-solid fa-lock"></i>Password</a>
    <a class="<?= $a('support.php') ?>" href="/user/support.php"><i class="fa-solid fa-headset"></i>Support</a>
  </nav>
</aside>
<div class="smm-main">
  <header class="smm-topbar">
    <button class="btn btn-light smm-mobile-toggle" data-sidebar-toggle><i class="fa-solid fa-bars"></i></button>
    <h6 class="mb-0 flex-grow-1 d-none d-md-block"><?= e($userTitle) ?></h6>
    <div class="ms-auto d-flex align-items-center gap-2">
      <span class="badge bg-light text-dark border">
        <i class="fa-solid fa-wallet me-1"></i>
        <?= e(\Models\Setting::get('currency_symbol','৳')) . number_format((float)$me['balance'],2) ?>
      </span>
      <div class="dropdown">
        <button class="btn btn-sm btn-light dropdown-toggle" data-bs-toggle="dropdown">
          <i class="fa-solid fa-user-circle me-1"></i><?= e($me['username']) ?>
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="/user/profile.php"><i class="fa-solid fa-user me-2"></i>Profile</a></li>
          <li><a class="dropdown-item" href="/user/password.php"><i class="fa-solid fa-lock me-2"></i>Password</a></li>
          <li><hr class="dropdown-divider"></li>
          <li>
            <form method="post" action="/user/logout.php" class="px-3 py-1">
              <?= \Csrf::field() ?>
              <button class="btn btn-sm btn-outline-danger w-100">Logout</button>
            </form>
          </li>
        </ul>
      </div>
    </div>
  </header>
  <main class="smm-content">