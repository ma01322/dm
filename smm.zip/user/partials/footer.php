<?php
declare(strict_types=1);
?>
  </main>
  <?php include __DIR__ . '/bottomnav.php'; ?>
</div><!-- /smm-main -->
</div><!-- /smm-app -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/app.js"></script>
<script src="/assets/js/order.js"></script>
</body>
</html>