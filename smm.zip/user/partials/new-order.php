<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$userTitle = 'New Order';
$me = \Auth::requireLogin();
$pdo = \DB::conn();

$cats = $pdo->query("SELECT id, name FROM categories WHERE status='active' ORDER BY sort_order")->fetchAll();

$cur = \Models\Setting::get('currency_symbol','৳');
$isReseller = ($me['role'] === 'reseller');
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="card smm-card">
      <div class="card-body">
        <h5 class="mb-3"><i class="fa-solid fa-cart-plus me-2 text-primary"></i>Place a new order</h5>

        <div id="orderAlert"></div>

        <form id="orderForm" autocomplete="off" novalidate>
          <?= \Csrf::field() ?>
          <div class="mb-3">
            <label class="form-label small">Category</label>
            <select id="categorySelect" class="form-select">
              <option value="">— Select category —</option>
              <?php foreach ($cats as $c): ?>
                <option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label small">Service</label>
            <select id="serviceSelect" name="service_id" class="form-select" required disabled>
              <option value="">— Choose a category first —</option>
            </select>
          </div>

          <div id="serviceInfo" class="alert alert-light border d-none">
            <div id="svcDesc" class="small mb-2"></div>
            <div class="row g-2 small">
              <div class="col-6 col-md-3"><span class="text-muted">Rate/1k:</span> <b id="svcRate"></b></div>
              <div class="col-6 col-md-3"><span class="text-muted">Min:</span> <b id="svcMin"></b></div>
              <div class="col-6 col-md-3"><span class="text-muted">Max:</span> <b id="svcMax"></b></div>
              <div class="col-6 col-md-3"><span class="text-muted">Refill:</span> <b id="svcRefill"></b></div>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label small">Link</label>
            <input type="url" name="link" id="linkInput" class="form-control" placeholder="https://..." required>
            <div class="form-text">Paste the public URL of the target post / profile / video.</div>
          </div>

          <div class="mb-3">
            <label class="form-label small">Quantity</label>
            <input type="number" name="quantity" id="qtyInput" class="form-control" min="1" required>
          </div>

          <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
            <div>
              <div class="small text-muted">Charge</div>
              <div class="fs-4 fw-bold" id="chargeOut"><?= e($cur) ?>0.00</div>
            </div>
            <div class="small">
              Wallet: <b><?= e($cur) . number_format((float)$me['balance'],2) ?></b>
            </div>
            <button type="submit" class="btn btn-primary px-4" id="submitBtn">
              <i class="fa-solid fa-paper-plane me-1"></i>Place order
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card smm-card">
      <div class="card-header bg-white"><strong>Tips</strong></div>
      <div class="card-body small text-muted">
        <ul class="mb-0 ps-3">
          <li>Server-side price is <b>recalculated</b> — frontend display is a preview only.</li>
          <li>Orders are dispatched to the provider automatically.</li>
          <li>Failed orders are auto-refunded to your wallet.</li>
          <li>Set your link to <b>public</b> (not private) or the order may fail.</li>
        </ul>
      </div>
    </div>
  </div>
</div>

<script>
window.SMM_ORDER = {
  priceRole: <?= $isReseller ? '"reseller"' : '"customer"' ?>,
  currency: <?= json_encode($cur) ?>,
  endpoints: {
    services: '/user/services.php?ajax=list'
  }
};
</script>

<?php include __DIR__ . '/partials/footer.php'; ?>