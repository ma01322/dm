<?php
declare(strict_types=1);
$cur = basename($_SERVER['PHP_SELF']);
$a = fn(string $f) => $cur === $f ? 'active' : '';
?>
<nav class="smm-bottomnav">
  <a class="<?= $a('index.php') ?>" href="/user/index.php"><i class="fa-solid fa-house"></i>Home</a>
  <a class="<?= $a('new-order.php') ?>" href="/user/new-order.php"><i class="fa-solid fa-cart-plus"></i>Order</a>
  <a class="<?= $a('orders.php') ?>" href="/user/orders.php"><i class="fa-solid fa-receipt"></i>Orders</a>
  <a class="<?= $a('add-funds.php') ?>" href="/user/add-funds.php"><i class="fa-solid fa-wallet"></i>Funds</a>
  <a class="<?= $a('support.php') ?>" href="/user/support.php"><i class="fa-solid fa-headset"></i>Help</a>
</nav>