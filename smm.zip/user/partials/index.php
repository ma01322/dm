<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$userTitle = 'Dashboard';
$me = \Auth::requireLogin();
$pdo = \DB::conn();

$stats = [
  'orders'    => (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE user_id=".(int)$me['id'])->fetchColumn(),
  'active'    => (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE user_id=".(int)$me['id']." AND status IN ('pending','processing','in_progress')")->fetchColumn(),
  'completed' => (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE user_id=".(int)$me['id']." AND status='completed'")->fetchColumn(),
  'spent'     => (float) $pdo->query("SELECT COALESCE(SUM(charge),0) FROM orders WHERE user_id=".(int)$me['id']." AND status NOT IN ('canceled','failed','refunded')")->fetchColumn(),
];

$recent = $pdo->prepare("SELECT o.*, s.name AS service FROM orders o LEFT JOIN services s ON s.id=o.service_id WHERE o.user_id=? ORDER BY o.id DESC LIMIT 8");
$recent->execute([(int)$me['id']]);
$recent = $recent->fetchAll();

$cur = \Models\Setting::get('currency_symbol','৳');
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-3">
    <div class="card smm-card stat-card"><div class="card-body">
      <div class="stat-icon bg-primary"><i class="fa-solid fa-receipt"></i></div>
      <div class="mt-2"><div class="text-muted small">Total orders</div><div class="stat-value"><?= number_format($stats['orders']) ?></div></div>
    </div></div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card smm-card stat-card"><div class="card-body">
      <div class="stat-icon bg-warning"><i class="fa-solid fa-hourglass-half"></i></div>
      <div class="mt-2"><div class="text-muted small">Active</div><div class="stat-value"><?= number_format($stats['active']) ?></div></div>
    </div></div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card smm-card stat-card"><div class="card-body">
      <div class="stat-icon bg-success"><i class="fa-solid fa-circle-check"></i></div>
      <div class="mt-2"><div class="text-muted small">Completed</div><div class="stat-value"><?= number_format($stats['completed']) ?></div></div>
    </div></div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card smm-card stat-card"><div class="card-body">
      <div class="stat-icon bg-info"><i class="fa-solid fa-sack-dollar"></i></div>
      <div class="mt-2"><div class="text-muted small">Spent</div><div class="stat-value small"><?= $cur.number_format($stats['spent'],2) ?></div></div>
    </div></div>
  </div>
</div>

<div class="alert alert-primary d-flex flex-wrap align-items-center justify-content-between">
  <div>
    <div class="fw-semibold">Wallet balance</div>
    <div class="fs-3 fw-bold"><?= $cur.number_format((float)$me['balance'],2) ?></div>
  </div>
  <div class="d-flex gap-2">
    <a href="/user/add-funds.php" class="btn btn-primary"><i class="fa-solid fa-plus me-1"></i>Add funds</a>
    <a href="/user/new-order.php" class="btn btn-outline-primary"><i class="fa-solid fa-cart-plus me-1"></i>New order</a>
  </div>
</div>

<div class="card smm-card">
  <div class="card-header bg-white d-flex justify-content-between"><strong>Recent orders</strong><a class="small" href="/user/orders.php">View all →</a></div>
  <div class="table-responsive">
    <table class="table smm-table align-middle mb-0">
      <thead><tr><th>#</th><th>Service</th><th>Qty</th><th>Charge</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($recent as $o): ?>
        <tr>
          <td>#<?= (int)$o['id'] ?></td>
          <td class="text-truncate" style="max-width:240px"><?= e($o['service'] ?? '—') ?></td>
          <td><?= number_format((int)$o['quantity']) ?></td>
          <td><?= $cur.number_format((float)$o['charge'],2) ?></td>
          <td><span class="smm-badge st-<?= e($o['status']) ?>"><?= e(str_replace('_',' ',$o['status'])) ?></span></td>
          <td><a class="btn btn-sm btn-outline-primary" href="/user/order-view.php?id=<?= (int)$o['id'] ?>"><i class="fa-solid fa-eye"></i></a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$recent): ?><tr><td colspan="6" class="text-center text-muted py-4">No orders yet. <a href="/user/new-order.php">Place your first order</a>.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>