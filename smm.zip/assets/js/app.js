/* Global helpers: toast, AJAX wrapper, CSRF */
(function (w) {
  'use strict';

  const CSRF = document.querySelector('meta[name="csrf-token"]')?.content || '';

  function toastStack() {
    let s = document.querySelector('.smm-toast-stack');
    if (!s) { s = document.createElement('div'); s.className = 'smm-toast-stack'; document.body.appendChild(s); }
    return s;
  }
  function toast(msg, type = 'info', ttl = 4000) {
    const el = document.createElement('div');
    el.className = 'smm-toast ' + type;
    el.textContent = msg;
    toastStack().appendChild(el);
    setTimeout(() => el.remove(), ttl);
  }

  async function post(url, data) {
    const body = new FormData();
    Object.entries(data || {}).forEach(([k, v]) => body.append(k, v));
    if (CSRF) body.append('_csrf', CSRF);
    const r = await fetch(url, {
      method: 'POST',
      body,
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      credentials: 'same-origin'
    });
    let j = null;
    try { j = await r.json(); } catch (e) { j = { error: 'Server error (' + r.status + ')' }; }
    return { ok: r.ok, status: r.status, data: j };
  }

  async function get(url) {
    const r = await fetch(url, {
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      credentials: 'same-origin'
    });
    let j = null;
    try { j = await r.json(); } catch (e) { j = { error: 'Server error (' + r.status + ')' }; }
    return { ok: r.ok, status: r.status, data: j };
  }

  // Sidebar toggle (mobile)
  document.addEventListener('click', (ev) => {
    const t = ev.target.closest('[data-sidebar-toggle]');
    if (!t) return;
    const sb = document.querySelector('.smm-sidebar');
    if (!sb) return;
    sb.classList.toggle('open');
    let bd = document.querySelector('.smm-backdrop');
    if (sb.classList.contains('open') && !bd) {
      bd = document.createElement('div'); bd.className = 'smm-backdrop';
      bd.addEventListener('click', () => { sb.classList.remove('open'); bd.remove(); });
      document.body.appendChild(bd);
    } else if (!sb.classList.contains('open') && bd) bd.remove();
  });

  // Auto-inject CSRF meta if missing (dashboard pages)
  if (CSRF && !document.querySelector('meta[name="csrf-token"]')) {
    const m = document.createElement('meta'); m.name = 'csrf-token'; m.content = CSRF;
    document.head.appendChild(m);
  }

  w.SMM = { post, get, toast, csrf: CSRF };
})(window);