(function (w) {
  'use strict';
  const cfg = w.SMM_ORDER;
  if (!cfg) return;

  const catSel  = document.getElementById('categorySelect');
  const svcSel  = document.getElementById('serviceSelect');
  const infoBox = document.getElementById('serviceInfo');
  const alertBox= document.getElementById('orderAlert');
  const form    = document.getElementById('orderForm');
  if (!form) return;

  const state = { services: [], selected: null };

  function alertMsg(msg, type = 'danger') {
    alertBox.innerHTML = `<div class="alert alert-${type} py-2 small mb-3">${msg}</div>`;
    setTimeout(() => alertBox.innerHTML = '', 5000);
  }

  async function loadServices(catId) {
    svcSel.disabled = true;
    svcSel.innerHTML = '<option value="">Loading…</option>';
    const r = await SMM.get(`${cfg.endpoints.services}&category_id=${encodeURIComponent(catId)}`);
    if (!r.ok || r.data.error) {
      svcSel.innerHTML = '<option value="">Failed to load</option>';
      alertMsg(r.data.error || 'Failed to load services');
      return;
    }
    state.services = r.data.services || [];
    if (!state.services.length) {
      svcSel.innerHTML = '<option value="">No services in this category</option>';
      return;
    }
    svcSel.innerHTML = '<option value="">— Select a service —</option>' +
      state.services.map(s => `<option value="${s.id}">${s.name} — ${cfg.currency}${s.rate}/1k</option>`).join('');
    svcSel.disabled = false;
  }

  function onServiceChange() {
    const id = parseInt(svcSel.value, 10);
    state.selected = state.services.find(s => parseInt(s.id, 10) === id) || null;
    if (!state.selected) {
      infoBox.classList.add('d-none');
      document.getElementById('qtyInput').removeAttribute('min');
      document.getElementById('chargeOut').textContent = cfg.currency + '0.00';
      return;
    }
    const s = state.selected;
    document.getElementById('svcDesc').textContent  = s.description || '';
    document.getElementById('svcRate').textContent  = cfg.currency + s.rate;
    document.getElementById('svcMin').textContent   = s.min;
    document.getElementById('svcMax').textContent   = s.max;
    document.getElementById('svcRefill').textContent= s.refill ? 'Yes' : 'No';
    const q = document.getElementById('qtyInput');
    q.min = s.min; q.max = s.max; q.placeholder = `${s.min} – ${s.max}`;
    if (!q.value) q.value = s.min;
    infoBox.classList.remove('d-none');
    recalc();
  }

  function recalc() {
    const s = state.selected;
    const q = parseInt(document.getElementById('qtyInput').value, 10) || 0;
    if (!s || q <= 0) { document.getElementById('chargeOut').textContent = cfg.currency + '0.00'; return; }
    const total = (parseFloat(s.rate) * q) / 1000;
    document.getElementById('chargeOut').textContent = cfg.currency + total.toFixed(4);
  }

  catSel?.addEventListener('change', () => catSel.value ? loadServices(catSel.value) : svcSel.setAttribute('disabled',''));
  svcSel?.addEventListener('change', onServiceChange);
  document.getElementById('qtyInput')?.addEventListener('input', recalc);

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const btn = document.getElementById('submitBtn');
    const s = state.selected;
    const link = document.getElementById('linkInput').value.trim();
    const qty  = parseInt(document.getElementById('qtyInput').value, 10) || 0;

    if (!s)   return alertMsg('Please select a service.');
    if (!link) return alertMsg('Please enter a link.');
    if (qty < s.min || qty > s.max) return alertMsg(`Quantity must be between ${s.min} and ${s.max}.`);

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Placing…';

    const r = await SMM.post('/user/new-order.php?ajax=1', {
      service_id: s.id, link, quantity: qty
    });

    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-paper-plane me-1"></i>Place order';

    if (r.ok && !r.data.error) {
      alertMsg(`Order <b>#${r.data.order_id}</b> placed successfully. Redirecting…`, 'success');
      setTimeout(() => location.href = `/user/order-view.php?id=${r.data.order_id}`, 900);
    } else {
      alertMsg(r.data.error || 'Order failed');
    }
  });
})(window);