<?php
declare(strict_types=1);
/**
 * Reseller API v2 entry point.
 * Only POST is accepted (also supports GET for compatibility with some panels).
 * Response is always JSON. PHP notices are never emitted.
 */
ini_set('display_errors', '0');
require_once __DIR__ . '/../../config/app.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

$start = (int)(microtime(true) * 1000);

// Wrap everything to guarantee JSON error on catastrophic failure
set_exception_handler(function (\Throwable $e) use ($start) {
    \Services\ApiService::log(null, null, $_POST['action'] ?? $_GET['action'] ?? null, $_REQUEST, 500, (int)(microtime(true)*1000)-$start, $e->getMessage());
    \Response::apiError('Internal error', 500);
});
set_error_handler(function ($no, $str) { throw new \ErrorException($str); });

// Reject maintenance mode
if (\Models\Setting::get('maintenance_mode', '0') === '1') {
    \Response::apiError('Panel under maintenance', 503);
}

[$keyRow, $user] = \Services\ApiService::authenticate();
$userId = (int)$user['id'];
$action = strtolower(trim((string)($_POST['action'] ?? $_GET['action'] ?? '')));

if ($action === '') {
    \Services\ApiService::log($userId, (int)$keyRow['id'], null, $_REQUEST, 400, (int)(microtime(true)*1000)-$start, 'missing action');
    \Response::apiError('Missing action', 400);
}

try {
    switch ($action) {

        /* ============================================================
         * action=services
         * ============================================================ */
        case 'services':
            $list = \Services\ServiceCatalogService::apiCatalog();
            \Services\ApiService::log($userId, (int)$keyRow['id'], 'services', [], 200, (int)(microtime(true)*1000)-$start);
            \Response::json($list); // top-level array, compatible with common SMM API consumers
            // (Note: some implementations return {services: [...]} — both are widely supported.
            //  We return a plain array to match the majority of reseller panels; wrap in {} if you prefer.)

        /* ============================================================
         * action=add
         * Required: service, link, quantity
         * Optional: runs, interval, comments, username
         * ============================================================ */
        case 'add':
            $serviceId = (int)($_POST['service'] ?? 0);
            $link      = trim((string)($_POST['link'] ?? ''));
            $qty       = (int)($_POST['quantity'] ?? 0);
            if (!$serviceId || !$link || !$qty) {
                \Services\ApiService::log($userId, (int)$keyRow['id'], 'add', $_REQUEST, 400, (int)(microtime(true)*1000)-$start, 'missing params');
                \Response::apiError('Missing required parameters');
            }

            $service = \Services\ServiceCatalogService::apiVisible($serviceId);
            if (!$service) {
                \Services\ApiService::log($userId, (int)$keyRow['id'], 'add', $_REQUEST, 400, (int)(microtime(true)*1000)-$start, 'service invisible');
                \Response::apiError('Service not available');
            }

            $extra = [];
            foreach (['runs','interval','comments','username','min','max','delay','posts'] as $k) {
                if (isset($_POST[$k]) && $_POST[$k] !== '') $extra[$k] = $_POST[$k];
            }

            try {
                $res = \Services\OrderService::place($userId, $serviceId, $link, $qty, 'api', $extra);
            } catch (\RuntimeException $e) {
                $msg = $e->getMessage();
                $code = stripos($msg, 'insufficient') !== false ? 402 : 400;
                \Services\ApiService::log($userId, (int)$keyRow['id'], 'add', $_REQUEST, $code, (int)(microtime(true)*1000)-$start, $msg);
                \Response::apiError($msg, $code);
            }

            \Services\ApiService::log($userId, (int)$keyRow['id'], 'add', $_REQUEST, 200, (int)(microtime(true)*1000)-$start);
            \Response::json(['order' => $res['order_id']]);

        /* ============================================================
         * action=status
         * Required: order (local order id)
         * ============================================================ */
        case 'status':
            $orderId = (int)($_POST['order'] ?? 0);
            if (!$orderId) \Response::apiError('Missing order parameter');
            $o = \Models\Order::find($orderId);
            if (!$o || (int)$o['user_id'] !== $userId) {
                \Services\ApiService::log($userId, (int)$keyRow['id'], 'status', $_REQUEST, 404, (int)(microtime(true)*1000)-$start, 'order not found');
                \Response::apiError('Incorrect order ID', 404);
            }
            \Services\ApiService::log($userId, (int)$keyRow['id'], 'status', $_REQUEST, 200, (int)(microtime(true)*1000)-$start);
            \Response::json([
                'charge'      => number_format((float)$o['charge'], 4, '.', ''),
                'start_count' => (string)($o['start_count'] ?? '0'),
                'status'      => ucfirst(str_replace('_', ' ', (string)$o['status'])),
                'remains'     => (string)($o['remains'] ?? '0'),
                'currency'    => $user['currency'] ?? 'BDT',
                'order'       => (int)$o['id'],
            ]);

        /* ============================================================
         * action=orders  (multi status)
         * Required: orders (comma-separated local order ids)
         * ============================================================ */
        case 'orders':
            $raw = trim((string)($_POST['orders'] ?? ''));
            if ($raw === '') \Response::apiError('Missing orders parameter');
            $ids = array_slice(array_filter(array_map('intval', explode(',', $raw))), 0, 100);
            if (!$ids) \Response::apiError('No valid order ids');
            $in = implode(',', array_fill(0, count($ids), '?'));
            $st = \DB::conn()->prepare(
                "SELECT * FROM orders WHERE user_id=? AND id IN ($in)"
            );
            $st->execute(array_merge([$userId], $ids));
            $rows = $st->fetchAll();
            $out = new \stdClass();
            foreach ($rows as $o) {
                $out->{(string)$o['id']} = [
                    'charge'      => number_format((float)$o['charge'], 4, '.', ''),
                    'start_count' => (string)($o['start_count'] ?? '0'),
                    'status'      => ucfirst(str_replace('_', ' ', (string)$o['status'])),
                    'remains'     => (string)($o['remains'] ?? '0'),
                    'currency'    => $user['currency'] ?? 'BDT',
                ];
            }
            \Services\ApiService::log($userId, (int)$keyRow['id'], 'orders', ['orders' => $raw], 200, (int)(microtime(true)*1000)-$start);
            \Response::json($out);

        /* ============================================================
         * action=balance
         * ============================================================ */
        case 'balance':
            $u = \Models\User::find($userId);
            \Services\ApiService::log($userId, (int)$keyRow['id'], 'balance', [], 200, (int)(microtime(true)*1000)-$start);
            \Response::json([
                'balance'  => number_format((float)$u['balance'], 2, '.', ''),
                'currency' => $u['currency'] ?: 'BDT',
            ]);

        /* ============================================================
         * action=refill
         * ============================================================ */
        case 'refill':
            $orderId = (int)($_POST['order'] ?? 0);
            if (!$orderId) \Response::apiError('Missing order parameter');
            $o = \Models\Order::find($orderId);
            if (!$o || (int)$o['user_id'] !== $userId) \Response::apiError('Incorrect order ID', 404);
            if (!$o['provider_id'] || !$o['provider_order_id']) \Response::apiError('Refill not supported', 400);
            try {
                $adapter = \Adapters\Providers\ProviderFactory::make((int)$o['provider_id']);
                $res = $adapter->refillOrder((string)$o['provider_order_id']);
                \Services\ApiService::log($userId, (int)$keyRow['id'], 'refill', ['order' => $orderId], 200, (int)(microtime(true)*1000)-$start);
                \Response::json(['refill' => $res['ok'] ? (string)$orderId : 0]);
            } catch (\Throwable $e) {
                \Response::apiError('Refill failed: ' . $e->getMessage(), 400);
            }

        /* ============================================================
         * action=cancel
         * ============================================================ */
        case 'cancel':
            $orderId = (int)($_POST['order'] ?? 0);
            if (!$orderId) \Response::apiError('Missing order parameter');
            $o = \Models\Order::find($orderId);
            if (!$o || (int)$o['user_id'] !== $userId) \Response::apiError('Incorrect order ID', 404);
            if (!in_array($o['status'], ['pending','processing','in_progress'], true)) \Response::apiError('Order cannot be canceled', 400);
            if (!$o['provider_id'] || !$o['provider_order_id']) \Response::apiError('Cancel not supported', 400);
            try {
                $adapter = \Adapters\Providers\ProviderFactory::make((int)$o['provider_id']);
                $res = $adapter->cancelOrder((string)$o['provider_order_id']);
                if (!$res['ok']) \Response::apiError('Cancel rejected by provider', 400);
                \Services\ApiService::log($userId, (int)$keyRow['id'], 'cancel', ['order' => $orderId], 200, (int)(microtime(true)*1000)-$start);
                \Response::json(['cancel' => (string)$orderId]);
            } catch (\Throwable $e) {
                \Response::apiError('Cancel failed', 400);
            }

        /* ============================================================
         * Unknown
         * ============================================================ */
        default:
            \Services\ApiService::log($userId, (int)$keyRow['id'], $action, $_REQUEST, 400, (int)(microtime(true)*1000)-$start, 'unknown action');
            \Response::apiError('Invalid action', 400);
    }
} catch (\Throwable $e) {
    \Services\ApiService::log($userId, (int)$keyRow['id'], $action, $_REQUEST, 500, (int)(microtime(true)*1000)-$start, $e->getMessage());
    \Response::apiError('Internal error', 500);
}