<?php
declare(strict_types=1);
/**
 * API contract smoke test — hit the live /api/v2 endpoint.
 * Usage: php tests/api_smoke.php YOUR_API_KEY [BASE_URL]
 *   e.g. php tests/api_smoke.php SMM_abc... http://localhost
 */

require_once __DIR__ . '/../config/app.php';

$key  = $argv[1] ?? '';
$base = rtrim($argv[2] ?? APP_URL, '/');
if ($key === '') { fwrite(STDERR, "Usage: php api_smoke.php <API_KEY> [BASE_URL]\n"); exit(2); }
$url = $base . '/api/v2';

function hit(string $url, array $payload, string $key): array {
    $payload['key'] = $key;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
    ]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'body' => json_decode((string)$body, true), 'raw' => $body];
}

$fail = 0;
$tests = [
    ['services',  ['action' => 'services'],  fn($r) => is_array($r['body'])],
    ['balance',   ['action' => 'balance'],   fn($r) => isset($r['body']['balance'])],
    ['bad-action',['action' => 'nonsense'],  fn($r) => isset($r['body']['error'])],
];
foreach ($tests as [$name, $payload, $check]) {
    $r = hit($url, $payload, $key);
    $ok = $check($r);
    echo ($ok ? '  ✅ ' : '  ❌ ') . $name . " (HTTP {$r['code']})\n";
    if (!$ok) { $fail++; echo "     → " . substr((string)$r['raw'], 0, 200) . "\n"; }
}

echo $fail === 0 ? "All API checks passed.\n" : "$fail API checks failed.\n";
exit($fail ? 1 : 0);