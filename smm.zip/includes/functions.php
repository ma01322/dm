<?php
declare(strict_types=1);

/** Global safe helpers — no side effects */

function e(?string $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function base_url(string $path = ''): string {
    return APP_URL . ($path !== '' ? '/' . ltrim($path, '/') : '');
}

function redirect(string $path, int $code = 302): never {
    header('Location: ' . (str_starts_with($path, 'http') ? $path : base_url($path)), true, $code);
    exit;
}

function money(float|int|string $amount, string $currency = 'BDT'): string {
    return number_format((float)$amount, 2) . ' ' . $currency;
}

function now(): string {
    return gmdate('Y-m-d H:i:s');
}

function client_ip(): string {
    foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = trim(explode(',', (string)$_SERVER[$k])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
    }
    return '0.0.0.0';
}

function client_ua(): string {
    return substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);
}

function is_post(): bool {
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function is_ajax(): bool {
    return strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest';
}

function random_token(int $bytes = 32): string {
    return bin2hex(random_bytes($bytes));
}

function json_encode_safe(mixed $data): string {
    return json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '{}';
}

function sanitize_json_recursive(array $data, array $redactKeys = ['password','key','token','secret','api_key']): array {
    foreach ($data as $k => $v) {
        if (is_array($v)) $data[$k] = sanitize_json_recursive($v, $redactKeys);
        else foreach ($redactKeys as $r) if (stripos((string)$k, $r) !== false) { $data[$k] = '***'; break; }
    }
    return $data;
}