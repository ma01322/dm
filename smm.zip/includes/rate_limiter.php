<?php
declare(strict_types=1);

final class RateLimiter
{
    /**
     * Sliding-window-per-minute limiter backed by DB (safe for multi-worker).
     * Returns [allowed:bool, remaining:int, retry_after:int]
     */
    public static function hit(string $bucket, int $maxPerMinute): array
    {
        $window = gmdate('Y-m-d H:i:00');
        $pdo = DB::conn();
        try {
            $st = $pdo->prepare(
                'INSERT INTO rate_limits (bucket, hits, window_at) VALUES (?,1,?)
                 ON DUPLICATE KEY UPDATE hits = hits + 1'
            );
            $st->execute([$bucket, $window]);

            $st = $pdo->prepare('SELECT hits FROM rate_limits WHERE bucket = ? AND window_at = ?');
            $st->execute([$bucket, $window]);
            $hits = (int) $st->fetchColumn();

            $allowed = $hits <= $maxPerMinute;
            return [
                'allowed'     => $allowed,
                'remaining'   => max(0, $maxPerMinute - $hits),
                'retry_after' => $allowed ? 0 : (60 - (int) gmdate('s')),
            ];
        } catch (Throwable $e) {
            Logger::error('app', 'rate_limiter: ' . $e->getMessage());
            return ['allowed' => true, 'remaining' => $maxPerMinute, 'retry_after' => 0];
        }
    }

    /** Clean old windows — call from cron */
    public static function gc(): void
    {
        DB::conn()->exec("DELETE FROM rate_limits WHERE window_at < (NOW() - INTERVAL 2 HOUR)");
    }
}