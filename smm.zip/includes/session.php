<?php
declare(strict_types=1);

final class Session
{
    public static function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) return;

        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || APP_URL[4] === 's' /* https */;

        session_name(SESSION_NAME);
        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        session_start();

        // Session hijack protection — bind to UA hash
        $ua = hash('sha256', client_ua());
        if (!isset($_SESSION['_ua'])) $_SESSION['_ua'] = $ua;
        elseif (!hash_equals($_SESSION['_ua'], $ua)) {
            self::destroy();
            session_start();
            $_SESSION['_ua'] = $ua;
        }
    }

    public static function get(string $k, mixed $d = null): mixed { return $_SESSION[$k] ?? $d; }
    public static function set(string $k, mixed $v): void      { $_SESSION[$k] = $v; }
    public static function del(string $k): void                { unset($_SESSION[$k]); }

    public static function regenerate(): void {
        if (session_status() === PHP_SESSION_ACTIVE) session_regenerate_id(true);
    }

    public static function destroy(): void {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }

    public static function flash(string $key, ?string $msg = null): ?string {
        if ($msg !== null) { $_SESSION['_flash'][$key] = $msg; return null; }
        $v = $_SESSION['_flash'][$key] ?? null;
        unset($_SESSION['_flash'][$key]);
        return $v;
    }
}