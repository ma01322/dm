<?php
declare(strict_types=1);

final class Logger
{
    public static function write(string $channel, string $level, string $message, array $context = []): void
    {
        $file = LOGS_PATH . '/' . preg_replace('/[^a-z0-9_-]/i', '_', $channel) . '.log';
        $line = sprintf(
            "[%s] %s.%s %s %s\n",
            gmdate('Y-m-d H:i:s'),
            $channel,
            strtoupper($level),
            $message,
            $context ? json_encode(sanitize_json_recursive($context)) : ''
        );
        // Rotate if > 10MB
        if (is_file($file) && filesize($file) > 10 * 1024 * 1024) {
            @rename($file, $file . '.' . gmdate('YmdHis'));
        }
        @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
    }

    public static function info(string $c, string $m, array $x = []): void  { self::write($c, 'info',  $m, $x); }
    public static function warn(string $c, string $m, array $x = []): void  { self::write($c, 'warn',  $m, $x); }
    public static function error(string $c, string $m, array $x = []): void { self::write($c, 'error', $m, $x); }

    public static function activity(?int $userId, ?string $role, string $action, ?string $entity = null, ?int $entityId = null, array $meta = []): void
    {
        try {
            $st = DB::conn()->prepare(
                'INSERT INTO activity_logs (user_id, role, action, entity, entity_id, meta, ip)
                 VALUES (?,?,?,?,?,?,?)'
            );
            $st->execute([
                $userId, $role, $action, $entity, $entityId,
                $meta ? json_encode(sanitize_json_recursive($meta)) : null,
                client_ip(),
            ]);
        } catch (Throwable $e) {
            self::error('app', 'activity log failed: ' . $e->getMessage());
        }
    }

    public static function login(?int $userId, ?string $email, bool $success, ?string $reason = null): void
    {
        try {
            $st = DB::conn()->prepare(
                'INSERT INTO login_logs (user_id, email, ip, ua, success, reason)
                 VALUES (?,?,?,?,?,?)'
            );
            $st->execute([$userId, $email, client_ip(), client_ua(), $success ? 1 : 0, $reason]);
        } catch (Throwable $e) { self::error('app', 'login log failed'); }
    }
}