<?php
declare(strict_types=1);

final class Response
{
    public static function json(mixed $data, int $code = 200, array $headers = []): never
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        foreach ($headers as $k => $v) header("$k: $v");
        echo json_encode_safe($data);
        exit;
    }

    public static function apiError(string $message, int $code = 400, ?string $extra = null): never
    {
        $body = ['error' => $message];
        if ($extra !== null) $body['detail'] = $extra;
        self::json($body, $code);
    }

    public static function html(string $body, int $code = 200): never
    {
        http_response_code($code);
        header('Content-Type: text/html; charset=utf-8');
        echo $body;
        exit;
    }
}