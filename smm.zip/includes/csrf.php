<?php
declare(strict_types=1);

final class Csrf
{
    private const KEY = '_csrf';

    public static function token(): string
    {
        if (empty($_SESSION[self::KEY])) {
            $_SESSION[self::KEY] = bin2hex(random_bytes(32));
        }
        return $_SESSION[self::KEY];
    }

    public static function field(): string
    {
        return '<input type="hidden" name="_csrf" value="' . e(self::token()) . '">';
    }

    public static function validate(?string $token): bool
    {
        return is_string($token) && !empty($_SESSION[self::KEY]) && hash_equals($_SESSION[self::KEY], $token);
    }

    public static function require(): void
    {
        $token = $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
        if (!self::validate($token)) {
            if (is_ajax()) Response::json(['error' => 'CSRF token invalid or expired'], 419);
            http_response_code(419);
            exit('CSRF token invalid.');
        }
    }
}