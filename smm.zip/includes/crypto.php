<?php
declare(strict_types=1);

/**
 * AES-256-GCM encryption for provider keys & gateway credentials.
 * Requires a 32-byte base64 APP_KEY.
 */
final class Crypto
{
    private static function key(): string
    {
        $raw = base64_decode(APP_KEY_B64, true);
        if ($raw === false || strlen($raw) !== 32) {
            throw new RuntimeException('APP_KEY must be base64 of exactly 32 bytes.');
        }
        return $raw;
    }

    public static function encrypt(string $plaintext): string
    {
        $iv  = random_bytes(12);
        $tag = '';
        $ct  = openssl_encrypt($plaintext, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag);
        if ($ct === false) throw new RuntimeException('Encryption failed');
        return base64_encode($iv . $tag . $ct);
    }

    public static function decrypt(string $payload): string
    {
        $raw = base64_decode($payload, true);
        if ($raw === false || strlen($raw) < 28) throw new RuntimeException('Bad ciphertext');
        $iv  = substr($raw, 0, 12);
        $tag = substr($raw, 12, 16);
        $ct  = substr($raw, 28);
        $pt  = openssl_decrypt($ct, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag);
        if ($pt === false) throw new RuntimeException('Decryption failed');
        return $pt;
    }
}