<?php
declare(strict_types=1);

final class Auth
{
    public static function user(): ?array
    {
        static $cache = null;
        if ($cache !== null) return $cache ?: null;
        $uid = (int) Session::get('uid', 0);
        if ($uid <= 0) return null;

        $st = DB::conn()->prepare('SELECT * FROM users WHERE id = ? AND status = "active" LIMIT 1');
        $st->execute([$uid]);
        $u = $st->fetch();
        return $cache = $u ?: null;
    }

    public static function id(): int { return (int)(self::user()['id'] ?? 0); }
    public static function role(): string { return (string)(self::user()['role'] ?? 'guest'); }
    public static function check(): bool { return self::user() !== null; }

    public static function requireLogin(): array
    {
        $u = self::user();
        if (!$u) {
            if (is_ajax()) Response::json(['error' => 'Unauthenticated'], 401);
            redirect('/login.php?next=' . urlencode($_SERVER['REQUEST_URI'] ?? '/'));
        }
        return $u;
    }

    public static function requireRole(string ...$roles): array
    {
        $u = self::requireLogin();
        if (!in_array($u['role'], $roles, true)) {
            Logger::activity((int)$u['id'], $u['role'], 'auth.denied', 'role', null, ['need' => $roles]);
            http_response_code(403);
            exit('Forbidden');
        }
        return $u;
    }

    public static function requireAdmin(): array { return self::requireRole('admin'); }
    public static function requireReseller(): array { return self::requireRole('reseller','admin'); }

    public static function login(array $user): void
    {
        Session::regenerate();
        Session::set('uid', (int)$user['id']);
        Session::set('role', $user['role']);
        DB::conn()->prepare('UPDATE users SET last_login_at = NOW(), last_login_ip = ? WHERE id = ?')
            ->execute([client_ip(), $user['id']]);
        Logger::login((int)$user['id'], $user['email'], true);
        Logger::activity((int)$user['id'], $user['role'], 'auth.login');
    }

    public static function logout(): void
    {
        $u = self::user();
        if ($u) Logger::activity((int)$u['id'], $u['role'], 'auth.logout');
        Session::destroy();
    }
}