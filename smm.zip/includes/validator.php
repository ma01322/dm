<?php
declare(strict_types=1);

final class Validator
{
    private array $errors = [];
    private array $clean  = [];

    public function __construct(private array $input) {}

    public function required(string $key, string $label = null): self {
        $label ??= $key;
        $v = trim((string)($this->input[$key] ?? ''));
        if ($v === '') $this->errors[$key] = "$label is required";
        else $this->clean[$key] = $v;
        return $this;
    }

    public function email(string $key): self {
        $v = trim((string)($this->input[$key] ?? ''));
        if ($v === '' || !filter_var($v, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$key] = 'Invalid email address';
        } else $this->clean[$key] = strtolower($v);
        return $this;
    }

    public function username(string $key, int $min = 3, int $max = 30): self {
        $v = trim((string)($this->input[$key] ?? ''));
        if (!preg_match('/^[A-Za-z0-9_.]{' . $min . ',' . $max . '}$/', $v)) {
            $this->errors[$key] = 'Username must be ' . $min . '-' . $max . ' alphanumeric/_/. chars';
        } else $this->clean[$key] = $v;
        return $this;
    }

    public function password(string $key, int $min = 8): self {
        $v = (string)($this->input[$key] ?? '');
        if (strlen($v) < $min) {
            $this->errors[$key] = "Password must be at least {$min} characters";
        } elseif (!preg_match('/[A-Za-z]/', $v) || !preg_match('/\d/', $v)) {
            $this->errors[$key] = 'Password must contain letters and numbers';
        } else $this->clean[$key] = $v;
        return $this;
    }

    public function int(string $key, int $min = PHP_INT_MIN, int $max = PHP_INT_MAX): self {
        $v = $this->input[$key] ?? null;
        if (!is_numeric($v)) { $this->errors[$key] = 'Must be a number'; return $this; }
        $i = (int)$v;
        if ($i < $min || $i > $max) $this->errors[$key] = "Must be between $min and $max";
        else $this->clean[$key] = $i;
        return $this;
    }

    public function decimal(string $key, float $min = 0.0, float $max = PHP_FLOAT_MAX): self {
        $v = $this->input[$key] ?? null;
        if (!is_numeric($v)) { $this->errors[$key] = 'Must be a number'; return $this; }
        $f = (float)$v;
        if ($f < $min || $f > $max) $this->errors[$key] = "Must be between $min and $max";
        else $this->clean[$key] = $f;
        return $this;
    }

    public function url(string $key, bool $httpsOnly = false): self {
        $v = trim((string)($this->input[$key] ?? ''));
        if (!filter_var($v, FILTER_VALIDATE_URL)) {
            $this->errors[$key] = 'Invalid URL';
        } elseif ($httpsOnly && !str_starts_with($v, 'https://')) {
            $this->errors[$key] = 'URL must be https';
        } elseif (strlen($v) > 500) {
            $this->errors[$key] = 'URL too long';
        } else $this->clean[$key] = $v;
        return $this;
    }

    public function in(string $key, array $allowed): self {
        $v = $this->input[$key] ?? null;
        if (!in_array($v, $allowed, true)) $this->errors[$key] = 'Invalid value';
        else $this->clean[$key] = $v;
        return $this;
    }

    public function fails(): bool { return !empty($this->errors); }
    public function errors(): array { return $this->errors; }
    public function clean(): array { return $this->clean; }
    public function firstError(): ?string { return $this->errors ? reset($this->errors) : null; }
}