<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Orders';
$pdo = \DB::conn();

/* AJAX actions: sync/refund */
if (isset($_GET['ajax']) && is_post()) {
    \Csrf::require();
    $action = (string)($_POST['action'] ?? '');
    $id     = (int)($_POST['id'] ?? 0);
    try {
        switch ($action) {
            case 'order.sync':
                $ok = \Services\SyncService::syncOne($id);
                \Response::json(['message' => $ok ? 'Order synced' : 'No change', 'reload' => true]);
            case 'order.refund':
                $amt = (float)($_POST['amount'] ?? 0);
                \Services\OrderService::refund($id, $amt > 0 ? $amt : null, 'Admin manual refund');
                \Response::json(['message' => 'Refunded', 'reload' => true]);
            default:
                \Response::json(['error' => 'Unknown action'], 400);
        }
    } catch (\Throwable $e) {
        \Response::json(['error' => $e->getMessage()], 400);
    }
}

$status = $_GET['status'] ?? '';
$q      = trim((string)($_GET['q'] ?? ''));
$page   = max(1, (int)($_GET['page'] ?? 1));
$per    = 25; $offset = ($page-1)*$per;

$where = []; $args = [];
if ($status) { $where[] = 'o.status = ?'; $args[] = $status; }
if ($q !== '') {
    $where[] = '(o.id = ? OR o.link LIKE ? OR u.username LIKE ?)';
    array_push($args, (int)$q, '%'.$q.'%', '%'.$q.'%');
}
$sql = 'FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN services s ON s.id=o.service_id ' .
       ($where ? 'WHERE '.implode(' AND ',$where) : '');

$stc = $pdo->prepare("SELECT COUNT(*) $sql"); $stc->execute($args); $total = (int)$stc->fetchColumn();
$st = $pdo->prepare("SELECT o.*, u.username, s.name AS service $sql ORDER BY o.id DESC LIMIT $per OFFSET $offset");
$st->execute($args);
$rows = $st->fetchAll();

$cur = \Models\Setting::get('currency_symbol','৳');
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="card smm-card mb-3">
  <div class="card-body">
    <form class="row g-2" method="get">
      <div class="col-md-5"><input name="q" class="form-control" placeholder="Order # / link / username" value="<?= e($q) ?>"></div>
      <div class="col-md-3">
        <select name="status" class="form-select">
          <option value="">Any status</option>
          <?php foreach (['pending','processing','in_progress','completed','partial','canceled','refunded','failed'] as $s): ?>
            <option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= str_replace('_',' ',$s) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2"><button class="btn btn-primary w-100">Filter</button></div>
    </form>
  </div>
</div>

<div class="card smm-card">
  <div class="table-responsive">
    <table class="table smm-table align-middle mb-0">
      <thead><tr><th>#</th><th>User</th><th>Service</th><th>Link</th><th>Qty</th><th>Charge</th><th>Profit</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($rows as $o): ?>
        <tr>
          <td><a href="/admin/order-view.php?id=<?= (int)$o['id'] ?>">#<?= (int)$o['id'] ?></a></td>
          <td><?= e($o['username']) ?></td>
          <td class="text-truncate" style="max-width:180px"><?= e($o['service'] ?? '—') ?></td>
          <td class="text-truncate small" style="max-width:180px"><a href="<?= e($o['link']) ?>" target="_blank" rel="noopener"><?= e($o['link']) ?></a></td>
          <td><?= number_format((int)$o['quantity']) ?></td>
          <td><?= $cur.number_format((float)$o['charge'],2) ?></td>
          <td class="text-success"><?= $cur.number_format((float)$o['profit'],2) ?></td>
          <td><span class="smm-badge st-<?= e($o['status']) ?>"><?= e(str_replace('_',' ',$o['status'])) ?></span></td>
          <td class="d-flex gap-1">
            <button class="btn btn-sm btn-outline-primary" data-action="order.sync" data-id="<?= (int)$o['id'] ?>"><i class="fa-solid fa-rotate"></i></button>
            <?php if (in_array($o['status'], ['canceled','failed','partial'], true) && !$o['refunded']): ?>
              <button class="btn btn-sm btn-outline-success" data-action="order.refund" data-id="<?= (int)$o['id'] ?>" data-confirm="Refund this order to user wallet?"><i class="fa-solid fa-rotate-left"></i></button>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="9" class="text-center text-muted py-4">No orders.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php $tp = max(1,(int)ceil($total/$per)); if ($tp>1): ?>
  <div class="card-body d-flex justify-content-between align-items-center">
    <div class="small text-muted"><?= number_format($total) ?> orders</div>
    <nav><ul class="pagination pagination-sm mb-0">
      <?php for ($i=1;$i<=$tp;$i++): ?>
        <li class="page-item <?= $i===$page?'active':'' ?>"><a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_filter(['q'=>$q,'status'=>$status])) ?>"><?= $i ?></a></li>
      <?php endfor; ?>
    </ul></nav>
  </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>