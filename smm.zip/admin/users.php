<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Users';
$pdo = \DB::conn();

/* AJAX actions */
if (isset($_GET['ajax']) && is_post()) {
    \Csrf::require();
    $action = (string)($_POST['action'] ?? '');
    $id     = (int)($_POST['id'] ?? 0);
    if ($id <= 0) \Response::json(['error' => 'Bad id'], 400);

    $target = \Models\User::find($id);
    if (!$target) \Response::json(['error' => 'User not found'], 404);

    $me = \Auth::user();
    try {
        switch ($action) {
            case 'user.suspend':
                if ((int)$target['id'] === (int)$me['id']) \Response::json(['error' => "You can't suspend yourself"]);
                \Models\User::update($id, ['status' => 'suspended']);
                \Logger::activity((int)$me['id'], $me['role'], 'user.suspend', 'user', $id);
                \Response::json(['message' => 'User suspended']);
            case 'user.activate':
                \Models\User::update($id, ['status' => 'active']);
                \Logger::activity((int)$me['id'], $me['role'], 'user.activate', 'user', $id);
                \Response::json(['message' => 'User activated']);
            case 'user.role':
                $role = (string)($_POST['role'] ?? '');
                if (!in_array($role, ['customer','reseller','admin'], true)) \Response::json(['error' => 'Invalid role']);
                if ((int)$target['id'] === (int)$me['id']) \Response::json(['error' => "You can't change your own role"]);
                \Models\User::update($id, ['role' => $role]);
                \Logger::activity((int)$me['id'], $me['role'], 'user.role', 'user', $id, ['role' => $role]);
                \Response::json(['message' => 'Role updated']);
            default:
                \Response::json(['error' => 'Unknown action'], 400);
        }
    } catch (\Throwable $e) {
        \Response::json(['error' => 'Operation failed'], 500);
    }
}

/* Balance adjustment (form) */
if (is_post() && isset($_POST['balance_adjust'])) {
    \Csrf::require();
    $id     = (int)($_POST['user_id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);
    $note   = trim((string)($_POST['note'] ?? 'Admin adjustment'));
    $user = \Models\User::find($id);
    if (!$user || $amount == 0.0) { $err = 'Invalid user or amount.'; }
    else {
        try {
            \Services\WalletService::adjust($id, $amount, $note, (int)\Auth::id());
            $ok = 'Balance updated.';
        } catch (\Throwable $e) { $err = $e->getMessage(); }
    }
}

/* Filters */
$page   = max(1, (int)($_GET['page'] ?? 1));
$role   = $_GET['role']   ?? '';
$status = $_GET['status'] ?? '';
$q      = trim((string)($_GET['q'] ?? ''));
$filters = [];
if ($role)   $filters['role'] = $role;
if ($status) $filters['status'] = $status;
if ($q)      $filters['q'] = $q;

$data = \Models\User::paginate($page, 25, $filters);
$cur  = \Models\Setting::get('currency_symbol','৳');

include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<?php if (!empty($ok)): ?><div class="alert alert-success py-2"><?= e($ok) ?></div><?php endif; ?>
<?php if (!empty($err)): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>

<div class="card smm-card mb-3">
  <div class="card-body">
    <form class="row g-2" method="get">
      <div class="col-md-4"><input name="q" class="form-control" placeholder="Search username/email" value="<?= e($q) ?>"></div>
      <div class="col-md-2">
        <select name="role" class="form-select">
          <option value="">All roles</option>
          <?php foreach (['customer','reseller','admin'] as $r): ?>
            <option value="<?= $r ?>" <?= $role===$r?'selected':'' ?>><?= ucfirst($r) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2">
        <select name="status" class="form-select">
          <option value="">Any status</option>
          <?php foreach (['active','suspended','banned'] as $s): ?>
            <option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2"><button class="btn btn-primary w-100">Filter</button></div>
    </form>
  </div>
</div>

<div class="card smm-card">
  <div class="table-responsive">
    <table class="table smm-table align-middle mb-0">
      <thead><tr><th>#</th><th>User</th><th>Email</th><th>Role</th><th>Balance</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($data['rows'] as $u): ?>
        <tr>
          <td>#<?= (int)$u['id'] ?></td>
          <td><a href="/admin/user-view.php?id=<?= (int)$u['id'] ?>"><?= e($u['username']) ?></a></td>
          <td class="small text-muted"><?= e($u['email']) ?></td>
          <td><span class="badge bg-secondary"><?= e($u['role']) ?></span></td>
          <td><?= $cur.number_format((float)$u['balance'],2) ?></td>
          <td>
            <?php
              $badge = match($u['status']) {
                'active' => 'bg-success',
                'suspended' => 'bg-warning text-dark',
                default => 'bg-danger',
              };
            ?>
            <span class="badge <?= $badge ?>"><?= e($u['status']) ?></span>
          </td>
          <td class="d-flex gap-1">
            <?php if ($u['status'] === 'active'): ?>
              <button class="btn btn-sm btn-outline-warning" data-action="user.suspend" data-id="<?= (int)$u['id'] ?>" data-confirm="Suspend this user?">
                <i class="fa-solid fa-pause"></i>
              </button>
            <?php else: ?>
              <button class="btn btn-sm btn-outline-success" data-action="user.activate" data-id="<?= (int)$u['id'] ?>">
                <i class="fa-solid fa-play"></i>
              </button>
            <?php endif; ?>
            <button class="btn btn-sm btn-outline-secondary" data-action="user.role" data-id="<?= (int)$u['id'] ?>">
              <i class="fa-solid fa-user-tag"></i>
            </button>
            <a class="btn btn-sm btn-outline-primary" href="/admin/user-view.php?id=<?= (int)$u['id'] ?>"><i class="fa-solid fa-eye"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$data['rows']): ?>
        <tr><td colspan="7" class="text-center text-muted py-4">No users found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php
  $totalPages = max(1, (int)ceil($data['total'] / $data['per_page']));
  if ($totalPages > 1):
  ?>
  <div class="card-body d-flex justify-content-between align-items-center">
    <div class="small text-muted"><?= number_format($data['total']) ?> users</div>
    <nav><ul class="pagination pagination-sm mb-0">
      <?php for ($i=1; $i<=$totalPages; $i++): ?>
        <li class="page-item <?= $i===$page?'active':'' ?>"><a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_filter(['q'=>$q,'role'=>$role,'status'=>$status])) ?>"><?= $i ?></a></li>
      <?php endfor; ?>
    </ul></nav>
  </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>