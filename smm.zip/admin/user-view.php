<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'User Details';
$id = (int)($_GET['id'] ?? 0);
$user = \Models\User::find($id);
if (!$user) { http_response_code(404); exit('User not found'); }
$pdo = \DB::conn();

$orders = $pdo->prepare("SELECT o.*, s.name AS service FROM orders o LEFT JOIN services s ON s.id=o.service_id WHERE o.user_id=? ORDER BY o.id DESC LIMIT 20");
$orders->execute([$id]); $orders = $orders->fetchAll();

$tx = $pdo->prepare("SELECT * FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 20");
$tx->execute([$id]); $tx = $tx->fetchAll();

$cur = \Models\Setting::get('currency_symbol','৳');
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="card smm-card">
      <div class="card-body">
        <h5 class="mb-1"><?= e($user['username']) ?></h5>
        <div class="text-muted small mb-3"><?= e($user['email']) ?></div>
        <dl class="row mb-0 small">
          <dt class="col-5">Role</dt><dd class="col-7"><?= e($user['role']) ?></dd>
          <dt class="col-5">Status</dt><dd class="col-7"><?= e($user['status']) ?></dd>
          <dt class="col-5">Balance</dt><dd class="col-7 fw-bold"><?= $cur.number_format((float)$user['balance'],2) ?></dd>
          <dt class="col-5">Total spent</dt><dd class="col-7"><?= $cur.number_format((float)$user['total_spent'],2) ?></dd>
          <dt class="col-5">Total deposit</dt><dd class="col-7"><?= $cur.number_format((float)$user['total_deposit'],2) ?></dd>
          <dt class="col-5">Joined</dt><dd class="col-7"><?= e($user['created_at']) ?></dd>
          <dt class="col-5">Last login</dt><dd class="col-7"><?= e($user['last_login_at'] ?? '—') ?></dd>
        </dl>
        <hr>
        <h6 class="small text-uppercase text-muted">Adjust balance</h6>
        <form method="post" data-ajax-balance>
          <?= \Csrf::field() ?>
          <input type="hidden" name="balance_adjust" value="1">
          <input type="hidden" name="user_id" value="<?= (int)$user['id'] ?>">
          <div class="mb-2">
            <input type="number" step="0.01" name="amount" class="form-control" placeholder="e.g. 100 or -50" required>
          </div>
          <div class="mb-2">
            <input type="text" name="note" class="form-control" placeholder="Reason (admin adjustment)" maxlength="200">
          </div>
          <button class="btn btn-primary w-100">Apply</button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>Recent orders</strong></div>
      <div class="table-responsive">
        <table class="table smm-table mb-0">
          <thead><tr><th>#</th><th>Service</th><th>Charge</th><th>Status</th><th>Date</th></tr></thead>
          <tbody>
          <?php foreach ($orders as $o): ?>
            <tr>
              <td><a href="/admin/order-view.php?id=<?= (int)$o['id'] ?>">#<?= (int)$o['id'] ?></a></td>
              <td class="text-truncate" style="max-width:220px"><?= e($o['service'] ?? '—') ?></td>
              <td><?= $cur.number_format((float)$o['charge'],2) ?></td>
              <td><span class="smm-badge st-<?= e($o['status']) ?>"><?= e($o['status']) ?></span></td>
              <td class="small text-muted"><?= e($o['created_at']) ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$orders): ?><tr><td colspan="5" class="text-center text-muted py-3">No orders.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card smm-card">
      <div class="card-header bg-white"><strong>Recent transactions</strong></div>
      <div class="table-responsive">
        <table class="table smm-table mb-0">
          <thead><tr><th>#</th><th>Type</th><th>Amount</th><th>Balance</th><th>Description</th><th>Date</th></tr></thead>
          <tbody>
          <?php foreach ($tx as $t): ?>
            <tr>
              <td>#<?= (int)$t['id'] ?></td>
              <td><span class="badge bg-secondary"><?= e($t['type']) ?></span></td>
              <td class="<?= (float)$t['amount'] < 0 ? 'text-danger' : 'text-success' ?>">
                <?= ((float)$t['amount'] < 0 ? '-' : '+') . $cur . number_format(abs((float)$t['amount']),2) ?>
              </td>
              <td><?= $cur.number_format((float)$t['balance_after'],2) ?></td>
              <td class="small text-muted"><?= e($t['description'] ?? '') ?></td>
              <td class="small text-muted"><?= e($t['created_at']) ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$tx): ?><tr><td colspan="6" class="text-center text-muted py-3">No transactions.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>