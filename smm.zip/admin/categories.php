<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Categories';
\Auth::requireAdmin();
$pdo = \DB::conn();

/* AJAX: create / update / delete */
if (isset($_GET['ajax']) && is_post()) {
    \Csrf::require();
    $action = (string)($_POST['action'] ?? '');
    try {
        switch ($action) {
            case 'category.save':
                $id   = (int)($_POST['id'] ?? 0);
                $name = trim((string)($_POST['name'] ?? ''));
                if ($name === '') \Response::json(['error' => 'Name required']);
                $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $name));
                $icon = trim((string)($_POST['icon'] ?? ''));
                $sort = (int)($_POST['sort_order'] ?? 100);
                $status = in_array($_POST['status'] ?? 'active', ['active','hidden'], true) ? $_POST['status'] : 'active';

                if ($id > 0) {
                    \Models\Category::update($id, compact('name','slug','icon','sort','status'));
                    \Logger::activity((int)\Auth::id(), 'admin', 'category.update', 'category', $id);
                    \Response::json(['message' => 'Category updated', 'reload' => true]);
                } else {
                    $newId = \Models\Category::insert([
                        'name' => $name, 'slug' => $slug, 'icon' => $icon,
                        'sort_order' => $sort, 'status' => $status
                    ]);
                    \Logger::activity((int)\Auth::id(), 'admin', 'category.create', 'category', $newId);
                    \Response::json(['message' => 'Category created', 'reload' => true]);
                }
            case 'category.delete':
                $id = (int)($_POST['id'] ?? 0);
                if ($id <= 0) \Response::json(['error' => 'Bad id']);
                $has = (int) $pdo->query("SELECT COUNT(*) FROM services WHERE category_id=".(int)$id)->fetchColumn();
                if ($has > 0) \Response::json(['error' => "Cannot delete: {$has} services in this category"]);
                \Models\Category::delete($id);
                \Logger::activity((int)\Auth::id(), 'admin', 'category.delete', 'category', $id);
                \Response::json(['message' => 'Deleted', 'reload' => true]);
            default:
                \Response::json(['error' => 'Unknown action'], 400);
        }
    } catch (\Throwable $e) {
        \Response::json(['error' => 'Operation failed'], 500);
    }
}

$cats = $pdo->query(
  "SELECT c.*, (SELECT COUNT(*) FROM services s WHERE s.category_id=c.id) AS services_count
   FROM categories c ORDER BY c.sort_order ASC, c.id ASC"
)->fetchAll();

include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="d-flex justify-content-between mb-3">
  <h6 class="mb-0 text-muted">Total: <?= count($cats) ?> categories</h6>
  <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#catModal" onclick="resetCatForm()">
    <i class="fa-solid fa-plus me-1"></i>New Category
  </button>
</div>

<div class="card smm-card">
  <div class="table-responsive">
    <table class="table smm-table mb-0">
      <thead><tr><th>#</th><th>Name</th><th>Slug</th><th>Icon</th><th>Services</th><th>Sort</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($cats as $c): ?>
        <tr>
          <td>#<?= (int)$c['id'] ?></td>
          <td><?= e($c['name']) ?></td>
          <td><code><?= e($c['slug']) ?></code></td>
          <td><?= $c['icon'] ? '<i class="fa-solid '.e($c['icon']).'"></i>' : '—' ?></td>
          <td><span class="badge bg-secondary"><?= (int)$c['services_count'] ?></span></td>
          <td><?= (int)$c['sort_order'] ?></td>
          <td><span class="badge <?= $c['status']==='active'?'bg-success':'bg-secondary' ?>"><?= e($c['status']) ?></span></td>
          <td class="d-flex gap-1">
            <button class="btn btn-sm btn-outline-primary" onclick='editCat(<?= json_encode($c, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'><i class="fa-solid fa-pen"></i></button>
            <button class="btn btn-sm btn-outline-danger" data-del="<?= (int)$c['id'] ?>" data-confirm="Delete this category?"><i class="fa-solid fa-trash"></i></button>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$cats): ?><tr><td colspan="8" class="text-center text-muted py-4">No categories yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="catModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="catForm">
        <div class="modal-header"><h6 class="modal-title">Category</h6><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <input type="hidden" name="id" id="catId" value="0">
          <input type="hidden" name="action" value="category.save">
          <div class="mb-2"><label class="form-label small">Name</label><input name="name" id="catName" class="form-control" required></div>
          <div class="row g-2">
            <div class="col-6"><label class="form-label small">Icon (fa class)</label><input name="icon" id="catIcon" class="form-control" placeholder="fa-instagram"></div>
            <div class="col-3"><label class="form-label small">Sort</label><input type="number" name="sort_order" id="catSort" class="form-control" value="100"></div>
            <div class="col-3"><label class="form-label small">Status</label>
              <select name="status" id="catStatus" class="form-select">
                <option value="active">Active</option><option value="hidden">Hidden</option>
              </select>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
          <button class="btn btn-primary">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function resetCatForm(){ document.getElementById('catForm').reset(); document.getElementById('catId').value = 0; }
function editCat(c){
  document.getElementById('catId').value = c.id;
  document.getElementById('catName').value = c.name;
  document.getElementById('catIcon').value = c.icon || '';
  document.getElementById('catSort').value = c.sort_order;
  document.getElementById('catStatus').value = c.status;
  new bootstrap.Modal(document.getElementById('catModal')).show();
}
document.getElementById('catForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const r = await SMM.post('/admin/categories.php?ajax=1', Object.fromEntries(fd));
  if (r.ok && !r.data.error) { SMM.toast(r.data.message, 'success'); setTimeout(()=>location.reload(),600); }
  else SMM.toast(r.data.error || 'Failed', 'error');
});
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-del]');
  if (!b) return;
  if (!confirm(b.dataset.confirm || 'Delete?')) return;
  const r = await SMM.post('/admin/categories.php?ajax=1', { action: 'category.delete', id: b.dataset.del });
  if (r.ok && !r.data.error) { SMM.toast('Deleted', 'success'); setTimeout(()=>location.reload(),400); }
  else SMM.toast(r.data.error || 'Failed', 'error');
});
</script>

<?php include __DIR__ . '/partials/footer.php'; ?>