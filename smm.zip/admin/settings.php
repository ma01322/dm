<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Settings';
\Auth::requireAdmin();

$fields = [
    'site_name'              => 'Site name',
    'site_logo'              => 'Logo URL',
    'currency'               => 'Currency code (BDT)',
    'currency_symbol'        => 'Currency symbol (৳)',
    'timezone'               => 'Timezone (Asia/Dhaka)',
    'support_email'          => 'Support email',
    'registration_enabled'   => 'Registration enabled (0/1)',
    'reseller_api_enabled'   => 'Reseller API enabled (0/1)',
    'api_default_rate_limit' => 'Default API rate limit (req/min)',
    'minimum_deposit'        => 'Minimum deposit',
    'maximum_deposit'        => 'Maximum deposit',
    'maintenance_mode'       => 'Maintenance mode (0/1)',
];

$msg = null; $err = null;
if (is_post()) {
    \Csrf::require();
    try {
        foreach ($fields as $k => $_) {
            if (isset($_POST[$k])) \Models\Setting::set($k, trim((string)$_POST[$k]));
        }
        // Logo upload (optional file)
        if (!empty($_FILES['logo_file']['tmp_name'])) {
            $f = $_FILES['logo_file'];
            if ($f['error'] !== UPLOAD_ERR_OK) throw new \RuntimeException('Upload failed');
            if ($f['size'] > 512 * 1024) throw new \RuntimeException('Max 512 KB');
            $finfo = new \finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($f['tmp_name']);
            $allowed = ['image/png'=>'png','image/jpeg'=>'jpg','image/svg+xml'=>'svg','image/webp'=>'webp'];
            if (!isset($allowed[$mime])) throw new \RuntimeException('Only PNG/JPG/SVG/WEBP');
            $ext = $allowed[$mime];
            $name = 'logo_' . bin2hex(random_bytes(6)) . '.' . $ext;
            if (!is_dir(UPLOADS_PATH)) @mkdir(UPLOADS_PATH, 0755, true);
            if (!move_uploaded_file($f['tmp_name'], UPLOADS_PATH . '/' . $name)) throw new \RuntimeException('Save failed');
            \Models\Setting::set('site_logo', '/uploads/' . $name);
        }
        \Logger::activity((int)\Auth::id(), 'admin', 'settings.update');
        $msg = 'Settings saved.';
    } catch (\Throwable $e) { $err = $e->getMessage(); }
}

include __DIR__ . '/partials/header.php'; include __DIR__ . '/partials/sidebar.php';
?>
<?php if ($msg): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>

<form method="post" enctype="multipart/form-data" class="card smm-card"><div class="card-body row g-3">
  <?= \Csrf::field() ?>
  <?php foreach ($fields as $k => $label): ?>
    <div class="col-md-6">
      <label class="form-label small"><?= e($label) ?></label>
      <input name="<?= e($k) ?>" class="form-control" value="<?= e((string)\Models\Setting::get($k,'')) ?>">
      <div class="form-text"><code><?= e($k) ?></code></div>
    </div>
  <?php endforeach; ?>
  <div class="col-md-6">
    <label class="form-label small">Upload logo file</label>
    <input type="file" name="logo_file" class="form-control" accept="image/*">
    <div class="form-text">Overrides Logo URL if provided.</div>
  </div>
  <div class="col-12">
    <button class="btn btn-primary">Save settings</button>
  </div>
</div></form>

<?php include __DIR__ . '/partials/footer.php'; ?>