<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Reports';
\Auth::requireAdmin();
$pdo = \DB::conn();
$from = $_GET['from'] ?? gmdate('Y-m-d', time()-30*86400);
$to   = $_GET['to']   ?? gmdate('Y-m-d');
$fromD = $from.' 00:00:00';
$toD   = $to.' 23:59:59';

$summary = $pdo->prepare(
  "SELECT COUNT(*) orders, COALESCE(SUM(charge),0) revenue, COALESCE(SUM(cost),0) cost, COALESCE(SUM(profit),0) profit
   FROM orders WHERE created_at BETWEEN ? AND ? AND status NOT IN ('canceled','failed','refunded')"
);
$summary->execute([$fromD,$toD]); $sum = $summary->fetch();

$dep = $pdo->prepare("SELECT COALESCE(SUM(net_amount),0) FROM deposits WHERE status='completed' AND created_at BETWEEN ? AND ?");
$dep->execute([$fromD,$toD]); $deposits = (float)$dep->fetchColumn();

$byService = $pdo->prepare(
  "SELECT s.name, COUNT(*) c, COALESCE(SUM(o.charge),0) rev, COALESCE(SUM(o.profit),0) profit
   FROM orders o JOIN services s ON s.id=o.service_id
   WHERE o.created_at BETWEEN ? AND ? AND o.status NOT IN ('canceled','failed','refunded')
   GROUP BY s.id ORDER BY rev DESC LIMIT 20"
);
$byService->execute([$fromD,$toD]); $byService = $byService->fetchAll();

$cur = \Models\Setting::get('currency_symbol','৳');
include __DIR__ . '/partials/header.php'; include __DIR__ . '/partials/sidebar.php';
?>
<div class="card smm-card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-3"><label class="form-label small">From</label><input type="date" name="from" class="form-control" value="<?= e($from) ?>"></div>
    <div class="col-md-3"><label class="form-label small">To</label><input type="date" name="to" class="form-control" value="<?= e($to) ?>"></div>
    <div class="col-md-2 d-flex align-items-end"><button class="btn btn-primary w-100">Apply</button></div>
  </form>
</div></div>

<div class="row g-3 mb-3">
  <?php
  $cards = [
    ['Orders',  number_format((int)$sum['orders']),          'bg-primary'],
    ['Revenue', $cur.number_format((float)$sum['revenue'],2),'bg-success'],
    ['Cost',    $cur.number_format((float)$sum['cost'],2),   'bg-warning'],
    ['Profit',  $cur.number_format((float)$sum['profit'],2), 'bg-info'],
    ['Deposits',$cur.number_format($deposits,2),             'bg-secondary'],
  ];
  foreach ($cards as [$l,$v,$bg]): ?>
    <div class="col-6 col-md-2">
      <div class="card smm-card stat-card"><div class="card-body">
        <div class="stat-icon <?= e($bg) ?>"><i class="fa-solid fa-chart-simple"></i></div>
        <div class="mt-2 small text-muted"><?= e($l) ?></div>
        <div class="stat-value"><?= e($v) ?></div>
      </div></div>
    </div>
  <?php endforeach; ?>
</div>

<div class="card smm-card">
  <div class="card-header bg-white"><strong>Top services by revenue</strong></div>
  <div class="table-responsive">
    <table class="table smm-table mb-0">
      <thead><tr><th>Service</th><th>Orders</th><th>Revenue</th><th>Profit</th></tr></thead>
      <tbody>
      <?php foreach ($byService as $r): ?>
        <tr>
          <td><?= e($r['name']) ?></td>
          <td><?= (int)$r['c'] ?></td>
          <td><?= $cur.number_format((float)$r['rev'],2) ?></td>
          <td class="text-success"><?= $cur.number_format((float)$r['profit'],2) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$byService): ?><tr><td colspan="4" class="text-center text-muted py-3">No data.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>