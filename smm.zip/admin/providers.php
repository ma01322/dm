<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Providers';
\Auth::requireAdmin();
$pdo = \DB::conn();

if (isset($_GET['ajax']) && is_post()) {
    \Csrf::require();
    $action = (string)($_POST['action'] ?? '');
    $id     = (int)($_POST['id'] ?? 0);
    try {
        switch ($action) {
            case 'provider.toggle':
                $cur = $pdo->query("SELECT status FROM providers WHERE id=".(int)$id)->fetchColumn();
                if (!$cur) \Response::json(['error' => 'Not found']);
                $new = $cur === 'active' ? 'disabled' : 'active';
                \Models\Provider::update($id, ['status' => $new]);
                \Response::json(['message' => "Provider $new", 'reload' => true]);
            case 'provider.delete':
                \Models\Provider::delete($id);
                \Response::json(['message' => 'Deleted', 'reload' => true]);
            case 'provider.test':
                $res = \Services\ProviderService::testConnection($id);
                \Response::json(['message' => $res['message'], 'balance' => $res['balance'] ?? null, 'reload' => true]);
            case 'provider.balance':
                $bal = \Services\ProviderService::fetchBalance($id);
                \Response::json(['message' => 'Balance updated: ' . ($bal ?? 'unknown'), 'reload' => true]);
            case 'provider.import':
                $res = \Services\ProviderService::importServices($id);
                \Response::json(['message' => $res['imported'] . ' services imported/updated', 'reload' => false]);
            default:
                \Response::json(['error' => 'Unknown action'], 400);
        }
    } catch (\Throwable $e) {
        \Response::json(['error' => $e->getMessage()], 400);
    }
}

$rows = $pdo->query("SELECT * FROM providers ORDER BY priority ASC, id ASC")->fetchAll();
$cur = \Models\Setting::get('currency_symbol','৳');

include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="d-flex justify-content-between mb-3">
  <h6 class="mb-0 text-muted"><?= count($rows) ?> providers</h6>
  <a class="btn btn-primary btn-sm" href="/admin/provider-edit.php"><i class="fa-solid fa-plus me-1"></i>Add Provider</a>
</div>

<div class="card smm-card">
  <div class="table-responsive">
    <table class="table smm-table align-middle mb-0">
      <thead><tr><th>#</th><th>Name</th><th>API URL</th><th>Adapter</th><th>Priority</th><th>Balance</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($rows as $p): ?>
        <tr>
          <td>#<?= (int)$p['id'] ?></td>
          <td><a href="/admin/provider-edit.php?id=<?= (int)$p['id'] ?>"><?= e($p['name']) ?></a></td>
          <td class="small text-truncate" style="max-width:260px"><?= e($p['api_url']) ?></td>
          <td><span class="badge bg-secondary"><?= e($p['adapter']) ?></span></td>
          <td><?= (int)$p['priority'] ?></td>
          <td class="small">
            <?= $p['balance_cache'] !== null ? $cur.number_format((float)$p['balance_cache'],2) : '—' ?>
            <?php if ($p['balance_updated']): ?><div class="text-muted" style="font-size:.7rem"><?= e($p['balance_updated']) ?></div><?php endif; ?>
          </td>
          <td><span class="badge <?= $p['status']==='active'?'bg-success':'bg-secondary' ?>"><?= e($p['status']) ?></span></td>
          <td class="d-flex gap-1 flex-wrap">
            <button class="btn btn-sm btn-outline-info" data-act="provider.test" data-id="<?= (int)$p['id'] ?>" title="Test"><i class="fa-solid fa-vial"></i></button>
            <button class="btn btn-sm btn-outline-primary" data-act="provider.balance" data-id="<?= (int)$p['id'] ?>" title="Balance"><i class="fa-solid fa-scale-balanced"></i></button>
            <button class="btn btn-sm btn-outline-success" data-act="provider.import" data-id="<?= (int)$p['id'] ?>" title="Import services"><i class="fa-solid fa-file-import"></i></button>
            <button class="btn btn-sm btn-outline-secondary" data-act="provider.toggle" data-id="<?= (int)$p['id'] ?>" title="Toggle"><i class="fa-solid fa-power-off"></i></button>
            <a class="btn btn-sm btn-outline-primary" href="/admin/provider-edit.php?id=<?= (int)$p['id'] ?>"><i class="fa-solid fa-pen"></i></a>
            <button class="btn btn-sm btn-outline-danger" data-act="provider.delete" data-id="<?= (int)$p['id'] ?>" data-confirm="Delete provider? This will not delete services."><i class="fa-solid fa-trash"></i></button>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted py-4">No providers yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-act]');
  if (!b) return;
  if (b.dataset.confirm && !confirm(b.dataset.confirm)) return;
  b.disabled = true;
  const r = await SMM.post('/admin/providers.php?ajax=1', { action: b.dataset.act, id: b.dataset.id });
  b.disabled = false;
  if (r.ok && !r.data.error) { SMM.toast(r.data.message || 'Done','success'); if (r.data.reload) setTimeout(()=>location.reload(),700); }
  else SMM.toast(r.data.error || 'Failed','error');
});
</script>

<?php include __DIR__ . '/partials/footer.php'; ?>