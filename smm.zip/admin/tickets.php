<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Tickets';
\Auth::requireAdmin();
$pdo = \DB::conn();
$status = $_GET['status'] ?? '';
$where = $status ? 'WHERE t.status = ' . $pdo->quote($status) : '';
$rows = $pdo->query(
  "SELECT t.*, u.username,
          (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id=t.id) AS msg_count
   FROM tickets t JOIN users u ON u.id=t.user_id
   $where ORDER BY t.updated_at DESC LIMIT 200"
)->fetchAll();
include __DIR__ . '/partials/header.php'; include __DIR__ . '/partials/sidebar.php';
?>
<div class="card smm-card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-3"><select name="status" class="form-select">
      <option value="">All statuses</option>
      <?php foreach (['open','pending','answered','closed'] as $s): ?>
        <option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= $s ?></option>
      <?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><button class="btn btn-primary w-100">Filter</button></div>
  </form>
</div></div>

<div class="card smm-card"><div class="table-responsive">
<table class="table smm-table mb-0">
  <thead><tr><th>#</th><th>User</th><th>Subject</th><th>Status</th><th>Msgs</th><th>Updated</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $t): ?>
    <tr>
      <td><a href="/admin/ticket-view.php?id=<?= (int)$t['id'] ?>">#<?= (int)$t['id'] ?></a></td>
      <td><?= e($t['username']) ?></td>
      <td class="text-truncate" style="max-width:320px"><?= e($t['subject']) ?></td>
      <td><span class="badge bg-secondary"><?= e($t['status']) ?></span></td>
      <td><?= (int)$t['msg_count'] ?></td>
      <td class="small text-muted"><?= e($t['updated_at']) ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="6" class="text-center text-muted py-4">No tickets.</td></tr><?php endif; ?>
  </tbody>
</table>
</div></div>
<?php include __DIR__ . '/partials/footer.php'; ?>