<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Services';
\Auth::requireAdmin();
$pdo = \DB::conn();

/* AJAX actions */
if (isset($_GET['ajax']) && is_post()) {
    \Csrf::require();
    $action = (string)($_POST['action'] ?? '');
    $id = (int)($_POST['id'] ?? 0);
    try {
        switch ($action) {
            case 'service.toggle':
                $s = $pdo->prepare("SELECT status FROM services WHERE id=?"); $s->execute([$id]); $cur = $s->fetchColumn();
                if (!$cur) \Response::json(['error' => 'Not found']);
                $new = $cur === 'active' ? 'disabled' : 'active';
                \Models\Service::update($id, ['status' => $new]);
                \Response::json(['message' => "Service $new", 'reload' => true]);
            case 'service.visible':
                $col = $_POST['col'] ?? '';
                if (!in_array($col, ['visible_website','visible_api'], true)) \Response::json(['error' => 'Bad col']);
                $val = (int)(($_POST['value'] ?? 0) ? 1 : 0);
                \Models\Service::update($id, [$col => $val]);
                \Response::json(['message' => 'Updated', 'reload' => true]);
            case 'service.bulk_price':
                $mode = $_POST['mode'] ?? 'add'; // add | sub | set | percent_add | percent_sub
                $val  = (float)($_POST['value'] ?? 0);
                $target = $_POST['target'] ?? 'customer_price';
                $scope  = $_POST['scope'] ?? 'all'; // all | category
                $catId  = (int)($_POST['category_id'] ?? 0);

                if (!in_array($target, ['customer_price','reseller_price','cost_price'], true)) \Response::json(['error' => 'Bad target']);
                if ($val < 0) \Response::json(['error' => 'Value must be >= 0']);

                $sql = "UPDATE services SET $target = ";
                $sql .= match ($mode) {
                    'add'          => "GREATEST(0, $target + :v)",
                    'sub'          => "GREATEST(0, $target - :v)",
                    'set'          => ":v",
                    'percent_add'  => "GREATEST(0, $target * (1 + :v/100))",
                    'percent_sub'  => "GREATEST(0, $target * (1 - :v/100))",
                    default        => throw new \Exception('Bad mode'),
                };
                if ($scope === 'category' && $catId > 0) { $sql .= " WHERE category_id = " . (int)$catId; }
                $st = $pdo->prepare($sql);
                $st->execute([':v' => $val]);
                \Logger::activity((int)\Auth::id(), 'admin', 'service.bulk_price', 'service', null, compact('mode','val','target','scope','catId'));
                \Response::json(['message' => 'Prices updated', 'reload' => true]);
            case 'service.delete':
                $st = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE service_id=?"); $st->execute([$id]);
                if ((int)$st->fetchColumn() > 0) \Response::json(['error' => 'Cannot delete: orders exist']);
                \Models\Service::delete($id);
                \Response::json(['message' => 'Deleted', 'reload' => true]);
            default:
                \Response::json(['error' => 'Unknown action'], 400);
        }
    } catch (\Throwable $e) {
        \Response::json(['error' => $e->getMessage()], 400);
    }
}

$q = trim((string)($_GET['q'] ?? ''));
$catFilter = (int)($_GET['category'] ?? 0);
$provFilter = (int)($_GET['provider'] ?? 0);
$status = $_GET['status'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1)); $per = 25; $off = ($page-1)*$per;

$where = []; $args = [];
if ($q !== '') { $where[] = '(s.name LIKE ? OR s.id = ?)'; $args[] = '%'.$q.'%'; $args[] = (int)$q; }
if ($catFilter) { $where[] = 's.category_id = ?'; $args[] = $catFilter; }
if ($provFilter) { $where[] = 's.provider_id = ?'; $args[] = $provFilter; }
if ($status) { $where[] = 's.status = ?'; $args[] = $status; }

$sqlFrom = "FROM services s
            LEFT JOIN categories c ON c.id=s.category_id
            LEFT JOIN providers p ON p.id=s.provider_id
            " . ($where ? 'WHERE '.implode(' AND ', $where) : '');

$stc = $pdo->prepare("SELECT COUNT(*) $sqlFrom"); $stc->execute($args); $total = (int)$stc->fetchColumn();
$st = $pdo->prepare("SELECT s.*, c.name AS category, p.name AS provider $sqlFrom ORDER BY s.id DESC LIMIT $per OFFSET $off");
$st->execute($args);
$rows = $st->fetchAll();

$cats = $pdo->query("SELECT id, name FROM categories ORDER BY sort_order")->fetchAll();
$providers = $pdo->query("SELECT id, name FROM providers ORDER BY priority")->fetchAll();
$cur = \Models\Setting::get('currency_symbol','৳');

include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="card smm-card mb-3"><div class="card-body">
  <form class="row g-2" method="get">
    <div class="col-md-3"><input name="q" class="form-control" placeholder="Search id/name" value="<?= e($q) ?>"></div>
    <div class="col-md-2"><select name="category" class="form-select"><option value="">Any category</option>
      <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>" <?= $catFilter==(int)$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><select name="provider" class="form-select"><option value="">Any provider</option>
      <?php foreach ($providers as $p): ?><option value="<?= (int)$p['id'] ?>" <?= $provFilter==(int)$p['id']?'selected':'' ?>><?= e($p['name']) ?></option><?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><select name="status" class="form-select"><option value="">Any status</option>
      <option value="active" <?= $status==='active'?'selected':'' ?>>Active</option>
      <option value="disabled" <?= $status==='disabled'?'selected':'' ?>>Disabled</option>
    </select></div>
    <div class="col-md-1"><button class="btn btn-primary w-100">Filter</button></div>
    <div class="col-md-2 d-flex gap-1">
      <a href="/admin/service-edit.php" class="btn btn-success w-100"><i class="fa-solid fa-plus me-1"></i>Add</a>
      <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#bulkModal" title="Bulk price"><i class="fa-solid fa-percent"></i></button>
    </div>
  </form>
</div></div>

<div class="card smm-card">
  <div class="table-responsive">
    <table class="table smm-table align-middle mb-0">
      <thead><tr>
        <th>ID</th><th>Service</th><th>Provider</th><th>Cost</th><th>Customer</th><th>Reseller</th>
        <th>Min/Max</th><th>Web</th><th>API</th><th>Status</th><th></th>
      </tr></thead>
      <tbody>
      <?php foreach ($rows as $s): ?>
        <tr>
          <td><code><?= (int)$s['id'] ?></code></td>
          <td>
            <div class="fw-semibold text-truncate" style="max-width:250px"><?= e($s['name']) ?></div>
            <div class="small text-muted"><?= e($s['category'] ?? '—') ?> · PSID: <?= e($s['provider_service_id'] ?? '—') ?></div>
          </td>
          <td class="small"><?= e($s['provider'] ?? '—') ?></td>
          <td class="small"><?= $cur.number_format((float)$s['cost_price'],2) ?></td>
          <td><?= $cur.number_format((float)$s['customer_price'],2) ?></td>
          <td><?= $cur.number_format((float)$s['reseller_price'],2) ?></td>
          <td class="small"><?= (int)$s['min_quantity'] ?>–<?= (int)$s['max_quantity'] ?></td>
          <td>
            <button class="btn btn-sm <?= (int)$s['visible_website']?'btn-success':'btn-light border' ?>" data-vis="visible_website" data-id="<?= (int)$s['id'] ?>" data-val="<?= (int)$s['visible_website'] ?>">
              <i class="fa-solid <?= (int)$s['visible_website']?'fa-check':'fa-xmark' ?>"></i>
            </button>
          </td>
          <td>
            <button class="btn btn-sm <?= (int)$s['visible_api']?'btn-success':'btn-light border' ?>" data-vis="visible_api" data-id="<?= (int)$s['id'] ?>" data-val="<?= (int)$s['visible_api'] ?>">
              <i class="fa-solid <?= (int)$s['visible_api']?'fa-check':'fa-xmark' ?>"></i>
            </button>
          </td>
          <td><button class="btn btn-sm <?= $s['status']==='active'?'btn-success':'btn-secondary' ?>" data-tog="<?= (int)$s['id'] ?>"><?= e($s['status']) ?></button></td>
          <td class="d-flex gap-1">
            <a class="btn btn-sm btn-outline-primary" href="/admin/service-edit.php?id=<?= (int)$s['id'] ?>"><i class="fa-solid fa-pen"></i></a>
            <button class="btn btn-sm btn-outline-danger" data-del="<?= (int)$s['id'] ?>" data-confirm="Delete this service?"><i class="fa-solid fa-trash"></i></button>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="11" class="text-center text-muted py-4">No services.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php $tp = max(1,(int)ceil($total/$per)); if ($tp>1): ?>
    <div class="card-body d-flex justify-content-between align-items-center">
      <div class="small text-muted"><?= number_format($total) ?> services</div>
      <nav><ul class="pagination pagination-sm mb-0">
        <?php for ($i=1;$i<=$tp;$i++): ?>
          <li class="page-item <?= $i===$page?'active':'' ?>"><a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_filter(['q'=>$q,'category'=>$catFilter,'provider'=>$provFilter,'status'=>$status])) ?>"><?= $i ?></a></li>
        <?php endfor; ?>
      </ul></nav>
    </div>
  <?php endif; ?>
</div>

<!-- Bulk price modal -->
<div class="modal fade" id="bulkModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="bulkForm">
        <div class="modal-header"><h6 class="modal-title">Bulk price update</h6><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
        <div class="modal-body">
          <input type="hidden" name="action" value="service.bulk_price">
          <div class="mb-2"><label class="form-label small">Target column</label>
            <select name="target" class="form-select">
              <option value="customer_price">Customer price</option>
              <option value="reseller_price">Reseller price</option>
              <option value="cost_price">Cost price</option>
            </select>
          </div>
          <div class="mb-2"><label class="form-label small">Operation</label>
            <select name="mode" class="form-select">
              <option value="add">Add fixed</option>
              <option value="sub">Subtract fixed</option>
              <option value="set">Set to value</option>
              <option value="percent_add">Increase %</option>
              <option value="percent_sub">Decrease %</option>
            </select>
          </div>
          <div class="mb-2"><label class="form-label small">Value</label><input type="number" step="0.0001" name="value" class="form-control" required></div>
          <div class="mb-2"><label class="form-label small">Scope</label>
            <select name="scope" class="form-select">
              <option value="all">All services</option>
              <option value="category">Only category…</option>
            </select>
          </div>
          <div class="mb-2"><label class="form-label small">Category</label>
            <select name="category_id" class="form-select">
              <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="alert alert-warning small mb-0">This will update prices immediately. Be careful.</div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
          <button class="btn btn-primary" data-confirm="Apply bulk price update?">Apply</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener('click', async (e) => {
  const t = e.target.closest('[data-tog]');
  if (t) {
    const r = await SMM.post('/admin/services.php?ajax=1', { action:'service.toggle', id: t.dataset.tog });
    if (r.ok && !r.data.error) { SMM.toast(r.data.message,'success'); setTimeout(()=>location.reload(),400); }
    else SMM.toast(r.data.error || 'Failed','error'); return;
  }
  const v = e.target.closest('[data-vis]');
  if (v) {
    const r = await SMM.post('/admin/services.php?ajax=1', {
      action:'service.visible', id: v.dataset.id, col: v.dataset.vis, value: v.dataset.val === '1' ? 0 : 1
    });
    if (r.ok && !r.data.error) { SMM.toast('Updated','success'); setTimeout(()=>location.reload(),400); }
    else SMM.toast(r.data.error || 'Failed','error'); return;
  }
  const d = e.target.closest('[data-del]');
  if (d) {
    if (!confirm(d.dataset.confirm || 'Delete?')) return;
    const r = await SMM.post('/admin/services.php?ajax=1', { action:'service.delete', id: d.dataset.del });
    if (r.ok && !r.data.error) { SMM.toast('Deleted','success'); setTimeout(()=>location.reload(),400); }
    else SMM.toast(r.data.error || 'Failed','error'); return;
  }
});
document.getElementById('bulkForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const r = await SMM.post('/admin/services.php?ajax=1', Object.fromEntries(fd));
  if (r.ok && !r.data.error) { SMM.toast(r.data.message,'success'); setTimeout(()=>location.reload(),700); }
  else SMM.toast(r.data.error || 'Failed','error');
});
</script>

<?php include __DIR__ . '/partials/footer.php'; ?>