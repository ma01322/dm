<?php
declare(strict_types=1);
if (!defined('APP_CONFIG_LOADED')) { require_once dirname(__DIR__, 2) . '/config/app.php'; }
$cur = basename($_SERVER['PHP_SELF']);
$active = fn(string $f) => $cur === $f ? 'active' : '';
?>
<aside class="smm-sidebar">
  <div class="brand"><i class="fa-solid fa-bolt me-1"></i><?= e(\Models\Setting::get('site_name', APP_NAME)) ?></div>
  <nav class="py-2 flex-grow-1">
    <a class="<?= $active('index.php') ?>" href="/admin/index.php"><i class="fa-solid fa-gauge-high"></i>Dashboard</a>

    <div class="section">Users</div>
    <a class="<?= $active('users.php') ?>" href="/admin/users.php"><i class="fa-solid fa-users"></i>All Users</a>
    <a class="<?= $active('users.php') ?>&role=reseller" href="/admin/users.php?role=reseller"><i class="fa-solid fa-user-tie"></i>Resellers</a>

    <div class="section">Orders</div>
    <a class="<?= $active('orders.php') ?>" href="/admin/orders.php"><i class="fa-solid fa-receipt"></i>All Orders</a>
    <a class="<?= $active('orders.php') ?>&status=pending" href="/admin/orders.php?status=pending"><i class="fa-solid fa-hourglass-half"></i>Pending</a>
    <a class="<?= $active('orders.php') ?>&status=completed" href="/admin/orders.php?status=completed"><i class="fa-solid fa-circle-check"></i>Completed</a>
    <a class="<?= $active('orders.php') ?>&status=refunded" href="/admin/orders.php?status=refunded"><i class="fa-solid fa-rotate-left"></i>Refunded</a>

    <div class="section">Catalog</div>
    <a class="<?= $active('categories.php') ?>" href="/admin/categories.php"><i class="fa-solid fa-folder-tree"></i>Categories</a>
    <a class="<?= $active('services.php') ?>" href="/admin/services.php"><i class="fa-solid fa-cubes"></i>Services</a>
    <a class="<?= $active('import-services.php') ?>" href="/admin/import-services.php"><i class="fa-solid fa-file-import"></i>Import Services</a>

    <div class="section">Providers</div>
    <a class="<?= $active('providers.php') ?>" href="/admin/providers.php"><i class="fa-solid fa-server"></i>Providers</a>
    <a class="<?= $active('provider-edit.php') ?>" href="/admin/provider-edit.php"><i class="fa-solid fa-plus"></i>Add Provider</a>

    <div class="section">Payments</div>
    <a class="<?= $active('payments.php') ?>" href="/admin/payments.php"><i class="fa-solid fa-credit-card"></i>Gateways</a>
    <a class="<?= $active('deposits.php') ?>" href="/admin/deposits.php"><i class="fa-solid fa-circle-dollar-to-slot"></i>Deposits</a>
    <a class="<?= $active('transactions.php') ?>" href="/admin/transactions.php"><i class="fa-solid fa-arrow-right-arrow-left"></i>Transactions</a>

    <div class="section">API</div>
    <a class="<?= $active('api-users.php') ?>" href="/admin/api-users.php"><i class="fa-solid fa-key"></i>Reseller API</a>
    <a class="<?= $active('api-logs.php') ?>" href="/admin/api-logs.php"><i class="fa-solid fa-clipboard-list"></i>API Logs</a>

    <div class="section">Support</div>
    <a class="<?= $active('tickets.php') ?>" href="/admin/tickets.php"><i class="fa-solid fa-headset"></i>Tickets</a>

    <div class="section">System</div>
    <a class="<?= $active('settings.php') ?>" href="/admin/settings.php"><i class="fa-solid fa-gear"></i>Settings</a>
    <a class="<?= $active('reports.php') ?>" href="/admin/reports.php"><i class="fa-solid fa-chart-line"></i>Reports</a>
  </nav>
</aside>
<div class="smm-main">
  <header class="smm-topbar">
    <button class="btn btn-light smm-mobile-toggle" data-sidebar-toggle><i class="fa-solid fa-bars"></i></button>
    <h6 class="mb-0 flex-grow-1"><?= e($adminTitle ?? 'Admin') ?></h6>
    <div class="dropdown">
      <button class="btn btn-light dropdown-toggle" data-bs-toggle="dropdown">
        <i class="fa-solid fa-user-shield me-1"></i><?= e($u['username']) ?>
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="/user/index.php"><i class="fa-solid fa-house me-2"></i>User view</a></li>
        <li><a class="dropdown-item" href="/admin/settings.php"><i class="fa-solid fa-gear me-2"></i>Settings</a></li>
        <li><hr class="dropdown-divider"></li>
        <li>
          <form method="post" action="/admin/logout.php" class="px-3 py-1">
            <?= \Csrf::field() ?>
            <button class="btn btn-sm btn-outline-danger w-100"><i class="fa-solid fa-power-off me-2"></i>Logout</button>
          </form>
        </li>
      </ul>
    </div>
  </header>
  <main class="smm-content">