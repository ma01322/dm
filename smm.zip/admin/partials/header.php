<?php
declare(strict_types=1);
if (!defined('APP_CONFIG_LOADED')) { require_once dirname(__DIR__, 2) . '/config/app.php'; }
\Auth::requireAdmin();
$u = \Auth::user();
$adminTitle = $adminTitle ?? 'Admin';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="<?= e(\Csrf::token()) ?>">
<title><?= e($adminTitle) ?> — Admin · <?= e(\Models\Setting::get('site_name', APP_NAME)) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="/assets/css/app.css" rel="stylesheet">
<link href="/assets/css/admin.css" rel="stylesheet">
</head>
<body>
<div class="smm-app">