<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Ticket';
$me = \Auth::requireAdmin();
$pdo = \DB::conn();
$id = (int)($_GET['id'] ?? 0);

$st = $pdo->prepare("SELECT t.*, u.username, u.email FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.id=? LIMIT 1");
$st->execute([$id]); $t = $st->fetch();
if (!$t) { http_response_code(404); exit('Ticket not found'); }

if (is_post()) {
    \Csrf::require();
    $msg = trim((string)($_POST['message'] ?? ''));
    if ($msg !== '') {
        $pdo->prepare("INSERT INTO ticket_messages (ticket_id, sender_id, sender_role, message) VALUES (?,?,?,?)")
            ->execute([$id, (int)$me['id'], 'admin', $msg]);
        $pdo->prepare("UPDATE tickets SET status='answered', updated_at=NOW() WHERE id=?")->execute([$id]);
    }
    if (isset($_POST['close'])) {
        $pdo->prepare("UPDATE tickets SET status='closed' WHERE id=?")->execute([$id]);
    }
    redirect('/admin/ticket-view.php?id='.$id);
}

$msgs = $pdo->prepare("SELECT m.*, u.username FROM ticket_messages m LEFT JOIN users u ON u.id=m.sender_id WHERE m.ticket_id=? ORDER BY m.id");
$msgs->execute([$id]); $msgs = $msgs->fetchAll();

include __DIR__ . '/partials/header.php'; include __DIR__ . '/partials/sidebar.php';
?>
<div class="card smm-card">
  <div class="card-header bg-white d-flex justify-content-between">
    <div><strong>#<?= (int)$t['id'] ?> — <?= e($t['subject']) ?></strong>
      <div class="small text-muted"><?= e($t['username']) ?> · <?= e($t['email']) ?></div>
    </div>
    <span class="badge bg-secondary align-self-start"><?= e($t['status']) ?></span>
  </div>
  <div class="card-body" style="max-height:60vh;overflow:auto">
    <?php foreach ($msgs as $m): $admin = $m['sender_role']==='admin'; ?>
      <div class="mb-3 <?= $admin?'text-end':'' ?>">
        <div class="d-inline-block px-3 py-2 rounded <?= $admin?'bg-primary text-white':'bg-light' ?>" style="max-width:80%">
          <div class="small opacity-75"><?= e($m['sender_role']) ?> · <?= e($m['created_at']) ?></div>
          <div><?= nl2br(e($m['message'])) ?></div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="card-footer bg-white">
    <form method="post" class="d-flex gap-2">
      <?= \Csrf::field() ?>
      <input name="message" class="form-control" placeholder="Reply..." required>
      <button class="btn btn-primary">Reply</button>
      <?php if ($t['status'] !== 'closed'): ?>
        <button class="btn btn-outline-secondary" name="close" value="1" onclick="return confirm('Close ticket?')">Close</button>
      <?php endif; ?>
    </form>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>