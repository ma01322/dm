<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Order Details';
$id = (int)($_GET['id'] ?? 0);
$pdo = \DB::conn();
$st = $pdo->prepare(
  "SELECT o.*, u.username, u.email, s.name AS service, s.cost_price, s.customer_price,
          p.name AS provider_name, p.api_url AS provider_url
   FROM orders o
   JOIN users u ON u.id=o.user_id
   LEFT JOIN services s ON s.id=o.service_id
   LEFT JOIN providers p ON p.id=o.provider_id
   WHERE o.id=? LIMIT 1"
);
$st->execute([$id]);
$o = $st->fetch();
if (!$o) { http_response_code(404); exit('Order not found'); }

$logs = $pdo->prepare("SELECT * FROM order_logs WHERE order_id=? ORDER BY id DESC");
$logs->execute([$id]); $logs = $logs->fetchAll();

$cur = \Models\Setting::get('currency_symbol','৳');
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="card smm-card mb-3">
      <div class="card-header bg-white d-flex justify-content-between">
        <strong>Order #<?= (int)$o['id'] ?></strong>
        <span class="smm-badge st-<?= e($o['status']) ?>"><?= e(str_replace('_',' ',$o['status'])) ?></span>
      </div>
      <div class="card-body">
        <dl class="row mb-0 small">
          <dt class="col-5">User</dt><dd class="col-7"><a href="/admin/user-view.php?id=<?= (int)$o['user_id'] ?>"><?= e($o['username']) ?></a></dd>
          <dt class="col-5">Service</dt><dd class="col-7"><?= e($o['service'] ?? '—') ?></dd>
          <dt class="col-5">Link</dt><dd class="col-7 text-break"><a href="<?= e($o['link']) ?>" target="_blank" rel="noopener"><?= e($o['link']) ?></a></dd>
          <dt class="col-5">Quantity</dt><dd class="col-7"><?= number_format((int)$o['quantity']) ?></dd>
          <dt class="col-5">Charge</dt><dd class="col-7 fw-bold"><?= $cur.number_format((float)$o['charge'],2) ?></dd>
          <dt class="col-5">Cost</dt><dd class="col-7"><?= $cur.number_format((float)$o['cost'],2) ?></dd>
          <dt class="col-5">Profit</dt><dd class="col-7 text-success"><?= $cur.number_format((float)$o['profit'],2) ?></dd>
          <dt class="col-5">Source</dt><dd class="col-7"><?= e($o['source']) ?></dd>
          <dt class="col-5">Start / Remains</dt><dd class="col-7"><?= (int)($o['start_count'] ?? 0) ?> / <?= (int)($o['remains'] ?? 0) ?></dd>
          <dt class="col-5">Refunded</dt><dd class="col-7"><?= $o['refunded'] ? 'Yes ('.$cur.number_format((float)$o['refund_amount'],2).')' : 'No' ?></dd>
          <dt class="col-5">Created</dt><dd class="col-7"><?= e($o['created_at']) ?></dd>
          <dt class="col-5">Updated</dt><dd class="col-7"><?= e($o['updated_at']) ?></dd>
        </dl>
      </div>
    </div>

    <div class="card smm-card">
      <div class="card-header bg-white"><strong>Provider</strong></div>
      <div class="card-body small">
        <?php if ($o['provider_name']): ?>
          <dl class="row mb-0">
            <dt class="col-5">Name</dt><dd class="col-7"><?= e($o['provider_name']) ?></dd>
            <dt class="col-5">Provider Order ID</dt><dd class="col-7"><code><?= e($o['provider_order_id'] ?? '—') ?></code></dd>
            <dt class="col-5">API URL</dt><dd class="col-7 text-break text-muted"><?= e($o['provider_url']) ?></dd>
          </dl>
        <?php else: ?>
          <div class="text-muted">No provider assigned (manual).</div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card smm-card">
      <div class="card-header bg-white"><strong>Activity logs</strong></div>
      <div class="card-body" style="max-height:600px;overflow:auto">
        <?php foreach ($logs as $l): ?>
          <div class="border-start border-3 ps-3 mb-3">
            <div class="small fw-semibold"><?= e($l['action']) ?></div>
            <div class="small text-muted"><?= e($l['message'] ?? '') ?></div>
            <div class="small text-muted"><?= e($l['created_at']) ?></div>
          </div>
        <?php endforeach; ?>
        <?php if (!$logs): ?><div class="text-muted small">No logs.</div><?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>