<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

if (\Auth::check() && \Auth::role() === 'admin') redirect('/admin/index.php');

$error = null;
if (is_post()) {
    \Csrf::require();
    $email = trim((string)($_POST['email'] ?? ''));
    $pass  = (string)($_POST['password'] ?? '');
    $res = \Services\AuthService::attempt($email, $pass);
    if ($res['ok'] && $res['user']['role'] === 'admin') {
        redirect('/admin/index.php');
    } elseif ($res['ok']) {
        \Auth::logout();
        $error = 'This account is not an admin.';
    } else {
        $error = $res['error'];
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login — <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-dark d-flex align-items-center" style="min-height:100vh">
<div class="container" style="max-width:440px">
  <div class="card border-0 shadow-lg">
    <div class="card-body p-4">
      <div class="text-center mb-4">
        <i class="fa-solid fa-user-shield display-4 text-primary"></i>
        <h4 class="mt-2 mb-0">Admin Login</h4>
        <div class="text-muted small">Restricted area</div>
      </div>
      <?php if ($error): ?><div class="alert alert-danger py-2 small"><?= e($error) ?></div><?php endif; ?>
      <form method="post" novalidate>
        <?= \Csrf::field() ?>
        <div class="mb-3">
          <label class="form-label small">Email</label>
          <input type="email" name="email" class="form-control" required autofocus>
        </div>
        <div class="mb-3">
          <label class="form-label small">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <button class="btn btn-primary w-100">Sign in</button>
      </form>
    </div>
  </div>
  <div class="text-center text-white-50 small mt-3"><a href="/" class="text-white-50">← Back to site</a></div>
</div>
</body>
</html>