<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Transactions';
\Auth::requireAdmin();
$pdo = \DB::conn();

$type = $_GET['type'] ?? '';
$q = trim((string)($_GET['q'] ?? ''));
$page = max(1,(int)($_GET['page']??1)); $per=25; $off=($page-1)*$per;
$where = []; $args = [];
if ($type) { $where[] = 't.type = ?'; $args[] = $type; }
if ($q !== '') { $where[] = '(u.username LIKE ? OR t.reference LIKE ?)'; array_push($args, '%'.$q.'%', '%'.$q.'%'); }
$sqlFrom = "FROM transactions t JOIN users u ON u.id=t.user_id " . ($where ? 'WHERE '.implode(' AND ',$where):'');

$stc = $pdo->prepare("SELECT COUNT(*) $sqlFrom"); $stc->execute($args); $total=(int)$stc->fetchColumn();
$st = $pdo->prepare("SELECT t.*, u.username $sqlFrom ORDER BY t.id DESC LIMIT $per OFFSET $off");
$st->execute($args); $rows = $st->fetchAll();
$cur = \Models\Setting::get('currency_symbol','৳');

include __DIR__ . '/partials/header.php'; include __DIR__ . '/partials/sidebar.php';
?>
<div class="card smm-card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-4"><input name="q" class="form-control" placeholder="Username / reference" value="<?= e($q) ?>"></div>
    <div class="col-md-3"><select name="type" class="form-select">
      <option value="">All types</option>
      <?php foreach (['deposit','order','refund','bonus','adjustment','withdraw'] as $t): ?>
        <option value="<?= $t ?>" <?= $type===$t?'selected':'' ?>><?= $t ?></option>
      <?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><button class="btn btn-primary w-100">Filter</button></div>
  </form>
</div></div>

<div class="card smm-card"><div class="table-responsive">
<table class="table smm-table mb-0">
  <thead><tr><th>#</th><th>User</th><th>Type</th><th>Amount</th><th>Balance after</th><th>Ref</th><th>Desc</th><th>Date</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $t): ?>
    <tr>
      <td>#<?= (int)$t['id'] ?></td>
      <td><?= e($t['username']) ?></td>
      <td><span class="badge bg-secondary"><?= e($t['type']) ?></span></td>
      <td class="<?= (float)$t['amount']<0?'text-danger':'text-success' ?>"><?= ((float)$t['amount']<0?'-':'+').$cur.number_format(abs((float)$t['amount']),2) ?></td>
      <td><?= $cur.number_format((float)$t['balance_after'],2) ?></td>
      <td class="small"><code><?= e($t['reference'] ?? '') ?></code></td>
      <td class="small text-muted"><?= e((string)$t['description']) ?></td>
      <td class="small text-muted"><?= e($t['created_at']) ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted py-4">No transactions.</td></tr><?php endif; ?>
  </tbody>
</table>
</div>
<?php $tp = max(1,(int)ceil($total/$per)); if ($tp>1): ?>
  <div class="card-body"><nav><ul class="pagination pagination-sm mb-0">
    <?php for ($i=1;$i<=$tp;$i++): ?>
      <li class="page-item <?= $i===$page?'active':'' ?>"><a class="page-link" href="?page=<?= $i ?>&type=<?= e($type) ?>&q=<?= urlencode($q) ?>"><?= $i ?></a></li>
    <?php endfor; ?>
  </ul></nav></div>
<?php endif; ?>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>