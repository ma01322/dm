<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
\Csrf::require();
\Auth::logout();
redirect('/admin/login.php');