<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Reseller API Users';
\Auth::requireAdmin();
$pdo = \DB::conn();

if (isset($_GET['ajax']) && is_post()) {
    \Csrf::require();
    $action = (string)($_POST['action'] ?? '');
    $userId = (int)($_POST['user_id'] ?? 0);
    $keyId  = (int)($_POST['key_id'] ?? 0);
    try {
        if ($action === 'api.revoke_key') {
            $pdo->prepare('UPDATE api_keys SET status="revoked", revoked_at=NOW() WHERE id=?')->execute([$keyId]);
            \Logger::activity((int)\Auth::id(), 'admin', 'api.key_revoke', 'api_key', $keyId);
            \Response::json(['message' => 'Key revoked', 'reload' => true]);
        }
        if ($action === 'api.generate_key') {
            $limit = (int)($_POST['rate_limit'] ?? 60);
            $row = \Models\ApiKey::generate($userId, 'Admin-issued', max(1, $limit));
            \Logger::activity((int)\Auth::id(), 'admin', 'api.key_generate', 'api_key', $row['id']);
            \Response::json(['message' => 'Key: ' . $row['key'] . ' (copy now)', 'reload' => true]);
        }
        \Response::json(['error' => 'Unknown action'], 400);
    } catch (\Throwable $e) { \Response::json(['error' => $e->getMessage()], 400); }
}

$resellers = $pdo->query("SELECT id, username, email, balance, status FROM users WHERE role IN ('reseller','admin') ORDER BY id DESC LIMIT 500")->fetchAll();

include __DIR__ . '/partials/header.php'; include __DIR__ . '/partials/sidebar.php';
?>
<div class="card smm-card"><div class="table-responsive">
<table class="table smm-table align-middle mb-0">
  <thead><tr><th>User</th><th>Email</th><th>Balance</th><th>Active key</th><th>Requests 24h</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($resellers as $r):
    $st = $pdo->prepare("SELECT * FROM api_keys WHERE user_id=? AND status='active' LIMIT 1");
    $st->execute([(int)$r['id']]); $key = $st->fetch();
    $st = $pdo->prepare("SELECT COUNT(*) FROM api_logs WHERE user_id=? AND created_at >= (NOW() - INTERVAL 24 HOUR)");
    $st->execute([(int)$r['id']]); $reqs = (int)$st->fetchColumn();
  ?>
    <tr>
      <td><?= e($r['username']) ?> <span class="badge bg-secondary"><?= e($r['role']) ?></span></td>
      <td class="small text-muted"><?= e($r['email']) ?></td>
      <td><?= number_format((float)$r['balance'],2) ?></td>
      <td class="small">
        <?php if ($key): ?>
          <code><?= e($key['key_prefix']) ?>…</code>
          <div class="text-muted" style="font-size:.75rem">Limit <?= (int)$key['rate_limit'] ?>/min · Last <?= e($key['last_used_at'] ?? '—') ?></div>
        <?php else: ?><span class="text-muted">none</span><?php endif; ?>
      </td>
      <td><?= $reqs ?></td>
      <td class="d-flex gap-1">
        <?php if ($key): ?>
          <button class="btn btn-sm btn-outline-danger" data-act="api.revoke_key" data-key="<?= (int)$key['id'] ?>" data-confirm="Revoke this key?">Revoke</button>
        <?php endif; ?>
        <button class="btn btn-sm btn-outline-primary" data-act="api.generate_key" data-user="<?= (int)$r['id'] ?>">Generate</button>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div></div>

<script>
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  if (b.dataset.confirm && !confirm(b.dataset.confirm)) return;
  const payload = { action: b.dataset.act };
  if (b.dataset.key)  payload.key_id  = b.dataset.key;
  if (b.dataset.user) payload.user_id = b.dataset.user;
  const r = await SMM.post('/admin/api-users.php?ajax=1', payload);
  if (r.ok && !r.data.error) { alert(r.data.message || 'Done'); location.reload(); }
  else SMM.toast(r.data.error || 'Failed','error');
});
</script>

<?php include __DIR__ . '/partials/footer.php'; ?>