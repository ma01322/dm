<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Import Services';
\Auth::requireAdmin();
$pdo = \DB::conn();

$providers = $pdo->query("SELECT id, name, status FROM providers ORDER BY priority")->fetchAll();
$providerId = (int)($_GET['provider'] ?? ($providers[0]['id'] ?? 0));

/* AJAX: import one service from provider_services table */
if (isset($_GET['ajax']) && is_post()) {
    \Csrf::require();
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'provider.refresh') {
            $pid = (int)($_POST['provider_id'] ?? 0);
            $res = \Services\ProviderService::importServices($pid);
            \Response::json(['message' => $res['imported'].' synced', 'reload' => true]);
        }
        if ($action === 'service.import') {
            $psId = (int)($_POST['ps_id'] ?? 0);
            $newId = \Services\ProviderService::importOne($psId);
            \Response::json(['message' => 'Imported service #'.$newId, 'reload' => true]);
        }
        if ($action === 'service.import_bulk') {
            $ids = array_map('intval', (array)($_POST['ids'] ?? []));
            $count = 0;
            foreach ($ids as $psId) { try { \Services\ProviderService::importOne($psId); $count++; } catch (\Throwable $e) {} }
            \Response::json(['message' => "$count services imported", 'reload' => true]);
        }
        \Response::json(['error' => 'Unknown action'], 400);
    } catch (\Throwable $e) {
        \Response::json(['error' => $e->getMessage()], 400);
    }
}

$rows = [];
if ($providerId) {
    $st = $pdo->prepare("SELECT ps.*, s.id AS existing_service_id FROM provider_services ps
                         LEFT JOIN services s ON s.provider_id=ps.provider_id AND s.provider_service_id=ps.provider_service_id
                         WHERE ps.provider_id=? ORDER BY ps.name LIMIT 500");
    $st->execute([$providerId]);
    $rows = $st->fetchAll();
}

include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>
<div class="card smm-card mb-3"><div class="card-body">
  <div class="row g-2 align-items-end">
    <div class="col-md-4">
      <label class="form-label small">Provider</label>
      <select id="provSel" class="form-select" onchange="location.href='/admin/import-services.php?provider='+this.value">
        <option value="0">— Select —</option>
        <?php foreach ($providers as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= $providerId===(int)$p['id']?'selected':'' ?>><?= e($p['name']) ?> (<?= e($p['status']) ?>)</option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-8 text-md-end">
      <?php if ($providerId): ?>
        <button class="btn btn-primary" data-act="provider.refresh" data-id="<?= $providerId ?>">
          <i class="fa-solid fa-rotate me-1"></i>Fetch from provider
        </button>
      <?php endif; ?>
    </div>
  </div>
</div></div>

<?php if ($providerId): ?>
<div class="card smm-card">
  <div class="card-header bg-white d-flex justify-content-between align-items-center">
    <strong><?= count($rows) ?> provider services cached</strong>
    <button class="btn btn-sm btn-outline-success" id="bulkImportBtn"><i class="fa-solid fa-download me-1"></i>Import selected</button>
  </div>
  <div class="table-responsive">
    <table class="table smm-table align-middle mb-0">
      <thead><tr>
        <th style="width:30px"><input type="checkbox" id="chkAll"></th>
        <th>PSID</th><th>Name</th><th>Category</th><th>Cost</th><th>Min/Max</th><th>Status</th><th></th>
      </tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?php if (!$r['existing_service_id']): ?><input type="checkbox" class="chk" value="<?= (int)$r['id'] ?>"><?php endif; ?></td>
          <td><code><?= e($r['provider_service_id']) ?></code></td>
          <td class="text-truncate" style="max-width:280px"><?= e($r['name']) ?></td>
          <td class="small"><?= e($r['category'] ?? '—') ?></td>
          <td><?= number_format((float)$r['rate'],4) ?></td>
          <td class="small"><?= (int)$r['min'] ?>–<?= (int)$r['max'] ?></td>
          <td>
            <?php if ($r['existing_service_id']): ?>
              <span class="badge bg-success">Imported #<?= (int)$r['existing_service_id'] ?></span>
            <?php else: ?>
              <span class="badge bg-secondary">Not imported</span>
            <?php endif; ?>
          </td>
          <td>
            <?php if (!$r['existing_service_id']): ?>
              <button class="btn btn-sm btn-primary" data-act="service.import" data-id="<?= (int)$r['id'] ?>">Import</button>
            <?php else: ?>
              <a class="btn btn-sm btn-outline-secondary" href="/admin/service-edit.php?id=<?= (int)$r['existing_service_id'] ?>">Edit</a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted py-4">No cached services. Click "Fetch from provider".</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
document.getElementById('chkAll')?.addEventListener('change', e => {
  document.querySelectorAll('.chk').forEach(c => c.checked = e.target.checked);
});
document.getElementById('bulkImportBtn')?.addEventListener('click', async () => {
  const ids = Array.from(document.querySelectorAll('.chk:checked')).map(c => c.value);
  if (!ids.length) return SMM.toast('Nothing selected','error');
  const r = await SMM.post('/admin/import-services.php?ajax=1', { action:'service.import_bulk', 'ids[]': ids });
  // send arrays properly:
});
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-act]');
  if (!b) return;
  b.disabled = true;
  const r = await SMM.post('/admin/import-services.php?ajax=1', { action: b.dataset.act, id: b.dataset.id, provider_id: b.dataset.id });
  b.disabled = false;
  if (r.ok && !r.data.error) { SMM.toast(r.data.message,'success'); setTimeout(()=>location.reload(),700); }
  else SMM.toast(r.data.error || 'Failed','error');
});
document.getElementById('bulkImportBtn')?.addEventListener('click', async () => {
  const ids = Array.from(document.querySelectorAll('.chk:checked')).map(c => c.value);
  if (!ids.length) return SMM.toast('Nothing selected','error');
  const body = new FormData();
  body.append('action','service.import_bulk');
  body.append('_csrf', document.querySelector('meta[name="csrf-token"]').content);
  ids.forEach(v => body.append('ids[]', v));
  const r = await fetch('/admin/import-services.php?ajax=1', { method:'POST', body, headers:{'X-Requested-With':'XMLHttpRequest'}, credentials:'same-origin' });
  const j = await r.json();
  if (j.error) SMM.toast(j.error,'error'); else { SMM.toast(j.message,'success'); setTimeout(()=>location.reload(),700); }
});
</script>

<?php else: ?>
<div class="alert alert-info">Select a provider to view cached services.</div>
<?php endif; ?>

<?php include __DIR__ . '/partials/footer.php'; ?>