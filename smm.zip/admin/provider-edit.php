<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Provider';
\Auth::requireAdmin();

$id = (int)($_GET['id'] ?? 0);
$isNew = $id === 0;
$p = $isNew ? [
    'id'=>0,'name'=>'','api_url'=>'','adapter'=>'standard','priority'=>10,'status'=>'active','meta'=>null
] : \Models\Provider::find($id);
if (!$p) { http_response_code(404); exit('Provider not found'); }

$err=null; $msg=null;
if (is_post()) {
    \Csrf::require();
    $v = (new \Validator($_POST))->required('name','Name')->url('api_url');
    if ($v->fails()) $err = $v->firstError();
    else {
        $c = $v->clean();
        $data = [
            'name'     => $c['name'],
            'api_url'  => $c['api_url'],
            'adapter'  => preg_replace('/[^a-z0-9_]/i','', (string)($_POST['adapter'] ?? 'standard')) ?: 'standard',
            'priority' => (int)($_POST['priority'] ?? 10),
            'status'   => in_array($_POST['status'] ?? 'active', ['active','disabled'], true) ? $_POST['status'] : 'active',
            'meta'     => json_encode(['notes' => (string)($_POST['notes'] ?? '')]),
        ];
        // Only update key when provided
        $key = trim((string)($_POST['api_key'] ?? ''));
        if ($key !== '') $data['api_key'] = \Crypto::encrypt($key);

        try {
            if ($isNew) {
                if (empty($data['api_key'])) throw new \RuntimeException('API key required');
                $newId = \Models\Provider::insert($data);
                \Logger::activity((int)\Auth::id(), 'admin', 'provider.create', 'provider', $newId);
                redirect('/admin/provider-edit.php?id='.$newId);
            } else {
                \Models\Provider::update($id, $data);
                \Logger::activity((int)\Auth::id(), 'admin', 'provider.update', 'provider', $id);
                $msg = 'Saved.';
                $p = \Models\Provider::find($id);
            }
        } catch (\Throwable $e) {
            $err = $e->getMessage();
        }
    }
}

$adapters = [];
$dir = ADAPTERS_PATH . '/providers';
if (is_dir($dir)) {
    foreach (scandir($dir) as $f) {
        if (str_ends_with($f, 'Adapter.php')) $adapters[] = strtolower(substr($f, 0, -11));
    }
}
if (!in_array('standard', $adapters, true)) $adapters[] = 'standard';

include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>
<?php if ($msg): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>

<form method="post" class="row g-3">
  <?= \Csrf::field() ?>
  <div class="col-lg-8">
    <div class="card smm-card"><div class="card-body">
      <div class="mb-2"><label class="form-label small">Provider name</label>
        <input name="name" class="form-control" required value="<?= e($p['name']) ?>"></div>
      <div class="mb-2"><label class="form-label small">API URL</label>
        <input name="api_url" class="form-control" required placeholder="https://provider.com/api/v2" value="<?= e($p['api_url']) ?>"></div>
      <div class="mb-2"><label class="form-label small">API Key <?= $isNew?'':'<span class="text-muted">(leave blank to keep current)</span>' ?></label>
        <input name="api_key" class="form-control" autocomplete="off" <?= $isNew?'required':'' ?>>
        <div class="form-text">Stored AES-256-GCM encrypted. Never displayed after save.</div>
      </div>
      <div class="row g-2">
        <div class="col-md-6"><label class="form-label small">Adapter</label>
          <select name="adapter" class="form-select">
            <?php foreach ($adapters as $a): ?><option value="<?= e($a) ?>" <?= $p['adapter']===$a?'selected':'' ?>><?= e($a) ?></option><?php endforeach; ?>
          </select></div>
        <div class="col-md-3"><label class="form-label small">Priority</label>
          <input type="number" name="priority" class="form-control" value="<?= (int)$p['priority'] ?>"></div>
        <div class="col-md-3"><label class="form-label small">Status</label>
          <select name="status" class="form-select">
            <option value="active" <?= $p['status']==='active'?'selected':'' ?>>Active</option>
            <option value="disabled" <?= $p['status']==='disabled'?'selected':'' ?>>Disabled</option>
          </select></div>
      </div>
      <div class="mt-2"><label class="form-label small">Internal notes</label>
        <textarea name="notes" class="form-control" rows="2"><?php
          $meta = $p['meta'] ? json_decode((string)$p['meta'], true) : [];
          echo e((string)($meta['notes'] ?? ''));
        ?></textarea></div>
      <button class="btn btn-primary mt-3"><?= $isNew?'Create provider':'Save changes' ?></button>
      <?php if (!$isNew): ?>
        <a class="btn btn-outline-secondary mt-3 ms-1" href="/admin/providers.php">Back</a>
      <?php endif; ?>
    </div></div>
  </div>
  <div class="col-lg-4">
    <div class="card smm-card"><div class="card-body">
      <h6>Balance snapshot</h6>
      <div class="small">
        Last known: <b><?= $p['balance_cache'] !== null ? number_format((float)$p['balance_cache'],2) : '—' ?></b><br>
        Updated: <?= e($p['balance_updated'] ?? '—') ?><br>
        Last error: <span class="text-danger small"><?= e((string)$p['last_error']) ?></span>
      </div>
    </div></div>
  </div>
</form>

<?php include __DIR__ . '/partials/footer.php'; ?>