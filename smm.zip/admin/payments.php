<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Payment Gateways';
\Auth::requireAdmin();
$pdo = \DB::conn();

if (isset($_GET['ajax']) && is_post()) {
    \Csrf::require();
    $action = (string)($_POST['action'] ?? '');
    $id = (int)($_POST['id'] ?? 0);
    try {
        switch ($action) {
            case 'gateway.toggle':
                $cur = $pdo->query("SELECT status FROM payment_gateways WHERE id=".(int)$id)->fetchColumn();
                if (!$cur) \Response::json(['error' => 'Not found']);
                $new = $cur === 'active' ? 'disabled' : 'active';
                \Models\PaymentGateway::update($id, ['status' => $new]);
                \Response::json(['message' => "Gateway $new", 'reload' => true]);
            case 'gateway.save':
                $data = [
                    'name'         => trim((string)($_POST['name'] ?? '')),
                    'adapter'      => preg_replace('/[^a-z0-9_]/i','', (string)($_POST['adapter'] ?? 'manual')) ?: 'manual',
                    'status'       => in_array($_POST['status'] ?? 'disabled', ['active','disabled'], true) ? $_POST['status'] : 'disabled',
                    'mode'         => in_array($_POST['mode'] ?? 'sandbox', ['sandbox','live'], true) ? $_POST['mode'] : 'sandbox',
                    'min_deposit'  => max(0, (float)($_POST['min_deposit'] ?? 10)),
                    'max_deposit'  => max(0, (float)($_POST['max_deposit'] ?? 100000)),
                    'fee_percent'  => max(0, (float)($_POST['fee_percent'] ?? 0)),
                    'fee_fixed'    => max(0, (float)($_POST['fee_fixed'] ?? 0)),
                    'instructions' => trim((string)($_POST['instructions'] ?? '')),
                    'sort_order'   => (int)($_POST['sort_order'] ?? 100),
                ];
                // Credentials (only overwrite when non-empty)
                $credsJson = trim((string)($_POST['credentials'] ?? ''));
                if ($credsJson !== '') {
                    json_decode($credsJson, true);
                    if (json_last_error() !== JSON_ERROR_NONE) \Response::json(['error' => 'Credentials must be valid JSON']);
                    $data['credentials'] = \Crypto::encrypt($credsJson);
                }
                if ($id > 0) {
                    \Models\PaymentGateway::update($id, $data);
                    \Logger::activity((int)\Auth::id(), 'admin', 'gateway.update', 'gateway', $id);
                    \Response::json(['message' => 'Gateway updated', 'reload' => true]);
                } else {
                    $data['code'] = strtolower(preg_replace('/[^a-z0-9_]/i','', $data['adapter'] . '_' . substr(md5((string)microtime(true)),0,6)));
                    $new = \Models\PaymentGateway::insert($data);
                    \Logger::activity((int)\Auth::id(), 'admin', 'gateway.create', 'gateway', $new);
                    \Response::json(['message' => 'Gateway created', 'reload' => true]);
                }
            default:
                \Response::json(['error' => 'Unknown action'], 400);
        }
    } catch (\Throwable $e) {
        \Response::json(['error' => $e->getMessage()], 400);
    }
}

$rows = $pdo->query("SELECT * FROM payment_gateways ORDER BY sort_order, id")->fetchAll();
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="d-flex justify-content-between mb-3">
  <h6 class="mb-0 text-muted"><?= count($rows) ?> gateways</h6>
  <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#gwModal" onclick="resetGw()"><i class="fa-solid fa-plus me-1"></i>Add Gateway</button>
</div>

<div class="card smm-card"><div class="table-responsive">
  <table class="table smm-table align-middle mb-0">
    <thead><tr><th>#</th><th>Name</th><th>Adapter</th><th>Mode</th><th>Min/Max</th><th>Fee</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $g): ?>
      <tr>
        <td>#<?= (int)$g['id'] ?></td>
        <td><?= e($g['name']) ?><div class="small text-muted"><?= e($g['code']) ?></div></td>
        <td><span class="badge bg-secondary"><?= e($g['adapter']) ?></span></td>
        <td><?= e($g['mode']) ?></td>
        <td class="small"><?= number_format((float)$g['min_deposit'],2) ?> – <?= number_format((float)$g['max_deposit'],2) ?></td>
        <td class="small"><?= number_format((float)$g['fee_percent'],2) ?>% + <?= number_format((float)$g['fee_fixed'],2) ?></td>
        <td><span class="badge <?= $g['status']==='active'?'bg-success':'bg-secondary' ?>"><?= e($g['status']) ?></span></td>
        <td class="d-flex gap-1">
          <button class="btn btn-sm btn-outline-secondary" data-act="gateway.toggle" data-id="<?= (int)$g['id'] ?>"><i class="fa-solid fa-power-off"></i></button>
          <button class="btn btn-sm btn-outline-primary" onclick='editGw(<?= json_encode($g, JSON_HEX_APOS|JSON_HEX_QUOT) ?>)'><i class="fa-solid fa-pen"></i></button>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted py-4">No gateways yet.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div></div>

<div class="modal fade" id="gwModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content">
  <form id="gwForm">
    <div class="modal-header"><h6 class="modal-title">Payment Gateway</h6><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body row g-2">
      <input type="hidden" name="action" value="gateway.save">
      <input type="hidden" name="id" id="gwId" value="0">
      <div class="col-md-6"><label class="form-label small">Name</label><input name="name" id="gwName" class="form-control" required></div>
      <div class="col-md-3"><label class="form-label small">Adapter</label>
        <select name="adapter" id="gwAdapter" class="form-select">
          <?php foreach (\Adapters\Payments\GatewayFactory::supported() as $a): ?><option value="<?= e($a) ?>"><?= e($a) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3"><label class="form-label small">Mode</label>
        <select name="mode" id="gwMode" class="form-select"><option value="sandbox">Sandbox</option><option value="live">Live</option></select>
      </div>
      <div class="col-md-3"><label class="form-label small">Min deposit</label><input type="number" step="0.01" name="min_deposit" id="gwMin" class="form-control" value="10"></div>
      <div class="col-md-3"><label class="form-label small">Max deposit</label><input type="number" step="0.01" name="max_deposit" id="gwMax" class="form-control" value="100000"></div>
      <div class="col-md-3"><label class="form-label small">Fee %</label><input type="number" step="0.01" name="fee_percent" id="gwPct" class="form-control" value="0"></div>
      <div class="col-md-3"><label class="form-label small">Fixed fee</label><input type="number" step="0.01" name="fee_fixed" id="gwFix" class="form-control" value="0"></div>
      <div class="col-md-3"><label class="form-label small">Sort order</label><input type="number" name="sort_order" id="gwSort" class="form-control" value="100"></div>
      <div class="col-md-3"><label class="form-label small">Status</label>
        <select name="status" id="gwStatus" class="form-select"><option value="active">Active</option><option value="disabled">Disabled</option></select>
      </div>
      <div class="col-12"><label class="form-label small">Instructions (shown to customer)</label>
        <textarea name="instructions" id="gwNotes" class="form-control" rows="2"></textarea>
      </div>
      <div class="col-12"><label class="form-label small">Credentials (JSON, encrypted at rest — leave blank to keep current)</label>
        <textarea name="credentials" class="form-control font-monospace" rows="4" placeholder='{"base_url":"...","app_key":"...","app_secret":"...","username":"...","password":"...","callback_url":"..."}'></textarea>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
      <button class="btn btn-primary">Save</button>
    </div>
  </form>
</div></div></div>

<script>
function resetGw(){ document.getElementById('gwForm').reset(); document.getElementById('gwId').value = 0; }
function editGw(g){
  document.getElementById('gwId').value = g.id;
  document.getElementById('gwName').value = g.name;
  document.getElementById('gwAdapter').value = g.adapter;
  document.getElementById('gwMode').value = g.mode;
  document.getElementById('gwMin').value = g.min_deposit;
  document.getElementById('gwMax').value = g.max_deposit;
  document.getElementById('gwPct').value = g.fee_percent;
  document.getElementById('gwFix').value = g.fee_fixed;
  document.getElementById('gwSort').value = g.sort_order;
  document.getElementById('gwStatus').value = g.status;
  document.getElementById('gwNotes').value = g.instructions || '';
  document.querySelector('#gwForm [name=credentials]').value = '';
  new bootstrap.Modal(document.getElementById('gwModal')).show();
}
document.getElementById('gwForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const r = await SMM.post('/admin/payments.php?ajax=1', Object.fromEntries(fd));
  if (r.ok && !r.data.error) { SMM.toast(r.data.message,'success'); setTimeout(()=>location.reload(),600); }
  else SMM.toast(r.data.error || 'Failed','error');
});
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const r = await SMM.post('/admin/payments.php?ajax=1', { action:b.dataset.act, id:b.dataset.id });
  if (r.ok && !r.data.error) { SMM.toast(r.data.message,'success'); setTimeout(()=>location.reload(),500); }
  else SMM.toast(r.data.error || 'Failed','error');
});
</script>

<?php include __DIR__ . '/partials/footer.php'; ?>