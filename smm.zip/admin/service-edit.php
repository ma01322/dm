<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Edit Service';
\Auth::requireAdmin();
$pdo = \DB::conn();

$id = (int)($_GET['id'] ?? 0);
$isNew = $id === 0;
$service = $isNew ? [
    'id'=>0,'name'=>'','description'=>'','category_id'=>0,'provider_id'=>0,'provider_service_id'=>'',
    'type'=>'default','cost_price'=>0,'customer_price'=>0,'reseller_price'=>0,
    'min_quantity'=>100,'max_quantity'=>100000,'dripfeed'=>0,'refill'=>0,'cancel'=>0,
    'speed'=>'','avg_time'=>'','sort_order'=>100,'status'=>'active','visible_website'=>1,'visible_api'=>1,
] : \Models\Service::find($id);
if (!$service) { http_response_code(404); exit('Not found'); }

$err = null; $msg = null;
if (is_post()) {
    \Csrf::require();
    $v = (new \Validator($_POST))
        ->required('name','Name')
        ->decimal('customer_price', 0)
        ->decimal('reseller_price', 0)
        ->decimal('cost_price', 0)
        ->int('min_quantity', 1, 100_000_000)
        ->int('max_quantity', 1, 1_000_000_000);
    if ($v->fails()) $err = $v->firstError();
    else {
        $c = $v->clean();
        $data = [
            'name'                => $c['name'],
            'description'         => trim((string)($_POST['description'] ?? '')),
            'category_id'         => (int)($_POST['category_id'] ?? 0) ?: null,
            'provider_id'         => (int)($_POST['provider_id'] ?? 0) ?: null,
            'provider_service_id' => trim((string)($_POST['provider_service_id'] ?? '')),
            'type'                => in_array($_POST['type'] ?? 'default', ['default','package','custom_comments','subscriptions','dripfeed'], true) ? $_POST['type'] : 'default',
            'cost_price'          => $c['cost_price'],
            'customer_price'      => $c['customer_price'],
            'reseller_price'      => $c['reseller_price'],
            'min_quantity'        => $c['min_quantity'],
            'max_quantity'        => $c['max_quantity'],
            'dripfeed'            => (int)!(empty($_POST['dripfeed'])),
            'refill'              => (int)!(empty($_POST['refill'])),
            'cancel'              => (int)!(empty($_POST['cancel'])),
            'speed'               => trim((string)($_POST['speed'] ?? '')),
            'avg_time'            => trim((string)($_POST['avg_time'] ?? '')),
            'sort_order'          => (int)($_POST['sort_order'] ?? 100),
            'status'              => in_array($_POST['status'] ?? 'active', ['active','disabled'], true) ? $_POST['status'] : 'active',
            'visible_website'     => (int)!(empty($_POST['visible_website'])),
            'visible_api'         => (int)!(empty($_POST['visible_api'])),
        ];
        try {
            if ($isNew) {
                $newId = \Models\Service::insert($data);
                \Logger::activity((int)\Auth::id(), 'admin', 'service.create', 'service', $newId);
                redirect('/admin/services.php');
            } else {
                \Models\Service::update($id, $data);
                \Logger::activity((int)\Auth::id(), 'admin', 'service.update', 'service', $id);
                $msg = 'Saved.';
                $service = \Models\Service::find($id);
            }
        } catch (\Throwable $e) {
            $err = 'Save failed: ' . $e->getMessage();
        }
    }
}

$cats = $pdo->query("SELECT id, name FROM categories ORDER BY sort_order")->fetchAll();
$providers = $pdo->query("SELECT id, name FROM providers ORDER BY priority")->fetchAll();
$providerServices = $service['provider_id']
    ? $pdo->query("SELECT provider_service_id, name, rate FROM provider_services WHERE provider_id=".(int)$service['provider_id']." ORDER BY name")->fetchAll()
    : [];

include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>
<?php if ($msg): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>

<form method="post" class="row g-3">
  <?= \Csrf::field() ?>
  <div class="col-lg-8">
    <div class="card smm-card"><div class="card-body">
      <h6 class="mb-3">Basic info</h6>
      <div class="mb-2"><label class="form-label small">Service name</label>
        <input name="name" class="form-control" required value="<?= e($service['name']) ?>"></div>
      <div class="mb-2"><label class="form-label small">Description</label>
        <textarea name="description" class="form-control" rows="4"><?= e((string)$service['description']) ?></textarea></div>
      <div class="row g-2">
        <div class="col-md-6"><label class="form-label small">Category</label>
          <select name="category_id" class="form-select">
            <option value="0">— None —</option>
            <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)$service['category_id']===(int)$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="col-md-6"><label class="form-label small">Type</label>
          <select name="type" class="form-select">
            <?php foreach (['default','package','custom_comments','subscriptions','dripfeed'] as $t): ?>
              <option value="<?= $t ?>" <?= $service['type']===$t?'selected':'' ?>><?= $t ?></option>
            <?php endforeach; ?>
          </select></div>
      </div>
      <div class="row g-2 mt-1">
        <div class="col-md-6"><label class="form-label small">Speed</label>
          <input name="speed" class="form-control" value="<?= e((string)$service['speed']) ?>" placeholder="e.g. 10k/day"></div>
        <div class="col-md-6"><label class="form-label small">Average time</label>
          <input name="avg_time" class="form-control" value="<?= e((string)$service['avg_time']) ?>" placeholder="e.g. 30 min"></div>
      </div>
    </div></div>
  </div>

  <div class="col-lg-4">
    <div class="card smm-card mb-3"><div class="card-body">
      <h6 class="mb-3">Pricing (per 1000)</h6>
      <div class="mb-2"><label class="form-label small">Cost price</label>
        <input type="number" step="0.0001" name="cost_price" class="form-control" value="<?= e((string)$service['cost_price']) ?>"></div>
      <div class="mb-2"><label class="form-label small">Customer price</label>
        <input type="number" step="0.0001" name="customer_price" class="form-control" value="<?= e((string)$service['customer_price']) ?>"></div>
      <div class="mb-2"><label class="form-label small">Reseller price</label>
        <input type="number" step="0.0001" name="reseller_price" class="form-control" value="<?= e((string)$service['reseller_price']) ?>"></div>
      <div class="small text-muted">Profit = (sale - cost) × qty / 1000</div>
    </div></div>

    <div class="card smm-card mb-3"><div class="card-body">
      <h6 class="mb-3">Quantity range</h6>
      <div class="row g-2">
        <div class="col-6"><label class="form-label small">Min</label>
          <input type="number" name="min_quantity" class="form-control" value="<?= (int)$service['min_quantity'] ?>"></div>
        <div class="col-6"><label class="form-label small">Max</label>
          <input type="number" name="max_quantity" class="form-control" value="<?= (int)$service['max_quantity'] ?>"></div>
      </div>
      <div class="mt-3 d-flex flex-wrap gap-3">
        <label class="form-check"><input type="checkbox" name="dripfeed" class="form-check-input" <?= (int)$service['dripfeed']?'checked':'' ?>> <span class="form-check-label small">Drip-feed</span></label>
        <label class="form-check"><input type="checkbox" name="refill" class="form-check-input" <?= (int)$service['refill']?'checked':'' ?>> <span class="form-check-label small">Refill</span></label>
        <label class="form-check"><input type="checkbox" name="cancel" class="form-check-input" <?= (int)$service['cancel']?'checked':'' ?>> <span class="form-check-label small">Cancel</span></label>
      </div>
    </div></div>

    <div class="card smm-card mb-3"><div class="card-body">
      <h6 class="mb-3">Provider mapping</h6>
      <div class="mb-2"><label class="form-label small">Provider</label>
        <select name="provider_id" class="form-select" onchange="location.href='/admin/service-edit.php?id=<?= (int)$id ?>&provider_id='+this.value">
          <option value="0">— None (manual) —</option>
          <?php foreach ($providers as $p): ?><option value="<?= (int)$p['id'] ?>" <?= (int)$service['provider_id']===(int)$p['id']?'selected':'' ?>><?= e($p['name']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="mb-2"><label class="form-label small">Provider service ID</label>
        <?php if ($providerServices): ?>
          <select name="provider_service_id" class="form-select">
            <option value="">— Select —</option>
            <?php foreach ($providerServices as $ps): ?>
              <option value="<?= e($ps['provider_service_id']) ?>" <?= (string)$service['provider_service_id']===(string)$ps['provider_service_id']?'selected':'' ?>>
                <?= e($ps['provider_service_id']) ?> — <?= e($ps['name']) ?> (<?= e((string)$ps['rate']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        <?php else: ?>
          <input name="provider_service_id" class="form-control" value="<?= e((string)$service['provider_service_id']) ?>" placeholder="e.g. 101">
        <?php endif; ?>
      </div>
      <div class="small text-muted">Tip: run "Import services" to sync provider service list.</div>
    </div></div>

    <div class="card smm-card"><div class="card-body">
      <h6 class="mb-3">Visibility & status</h6>
      <div class="mb-2"><label class="form-label small">Sort order</label>
        <input type="number" name="sort_order" class="form-control" value="<?= (int)$service['sort_order'] ?>"></div>
      <div class="mb-2"><label class="form-label small">Status</label>
        <select name="status" class="form-select">
          <option value="active" <?= $service['status']==='active'?'selected':'' ?>>Active</option>
          <option value="disabled" <?= $service['status']==='disabled'?'selected':'' ?>>Disabled</option>
        </select></div>
      <label class="form-check"><input type="checkbox" name="visible_website" class="form-check-input" <?= (int)$service['visible_website']?'checked':'' ?>> <span class="form-check-label small">Visible on website</span></label>
      <label class="form-check"><input type="checkbox" name="visible_api" class="form-check-input" <?= (int)$service['visible_api']?'checked':'' ?>> <span class="form-check-label small">Visible via API</span></label>
      <hr>
      <button class="btn btn-primary w-100"><?= $isNew ? 'Create service' : 'Save changes' ?></button>
    </div></div>
  </div>
</form>

<?php include __DIR__ . '/partials/footer.php'; ?>