<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Dashboard';
$pdo = \DB::conn();

$stats = [
  'users'         => (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role <> 'admin'")->fetchColumn(),
  'resellers'     => (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'reseller'")->fetchColumn(),
  'orders_today'  => (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at)=UTC_DATE()")->fetchColumn(),
  'orders_total'  => (int) $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn(),
  'pending'       => (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE status IN ('pending','processing','in_progress')")->fetchColumn(),
  'revenue_today' => (float) $pdo->query("SELECT COALESCE(SUM(charge),0) FROM orders WHERE DATE(created_at)=UTC_DATE() AND status NOT IN ('canceled','failed','refunded')")->fetchColumn(),
  'profit_today'  => (float) $pdo->query("SELECT COALESCE(SUM(profit),0) FROM orders WHERE DATE(created_at)=UTC_DATE() AND status NOT IN ('canceled','failed','refunded')")->fetchColumn(),
  'deposits_today'=> (float) $pdo->query("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE DATE(created_at)=UTC_DATE() AND status='completed'")->fetchColumn(),
];

$recentOrders = $pdo->query(
  "SELECT o.id, o.link, o.quantity, o.charge, o.status, o.created_at, u.username, s.name AS service
   FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN services s ON s.id=o.service_id
   ORDER BY o.id DESC LIMIT 8"
)->fetchAll();

// 7-day chart data
$chart = $pdo->query(
  "SELECT DATE(created_at) d, COUNT(*) c, COALESCE(SUM(charge),0) rev
   FROM orders WHERE created_at >= (NOW() - INTERVAL 7 DAY)
   GROUP BY DATE(created_at) ORDER BY d ASC"
)->fetchAll();

$cur = \Models\Setting::get('currency_symbol','৳');
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="row g-3 mb-4">
  <?php
  $cards = [
    ['Users',           number_format($stats['users']),        'fa-users','bg-primary'],
    ['Resellers',       number_format($stats['resellers']),    'fa-user-tie','bg-info'],
    ['Orders today',    number_format($stats['orders_today']), 'fa-receipt','bg-success'],
    ['In progress',     number_format($stats['pending']),      'fa-hourglass-half','bg-warning'],
    ['Revenue today',   $cur.number_format($stats['revenue_today'],2),'fa-sack-dollar','bg-success'],
    ['Profit today',    $cur.number_format($stats['profit_today'],2), 'fa-chart-line','bg-primary'],
    ['Deposits today',  $cur.number_format($stats['deposits_today'],2),'fa-circle-dollar-to-slot','bg-info'],
    ['Total orders',    number_format($stats['orders_total']), 'fa-layer-group','bg-secondary'],
  ];
  foreach ($cards as [$label,$value,$icon,$bg]): ?>
    <div class="col-6 col-md-3">
      <div class="card smm-card stat-card h-100">
        <div class="card-body d-flex align-items-center gap-3">
          <div class="stat-icon <?= e($bg) ?>"><i class="fa-solid <?= e($icon) ?>"></i></div>
          <div>
            <div class="text-muted small"><?= e($label) ?></div>
            <div class="stat-value"><?= e($value) ?></div>
          </div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="card smm-card">
      <div class="card-header bg-white border-0 d-flex justify-content-between align-items-center">
        <strong>Recent orders</strong>
        <a href="/admin/orders.php" class="small">View all →</a>
      </div>
      <div class="table-responsive">
        <table class="table smm-table align-middle mb-0">
          <thead><tr><th>#</th><th>User</th><th>Service</th><th>Charge</th><th>Status</th><th>Time</th></tr></thead>
          <tbody>
          <?php if (!$recentOrders): ?>
            <tr><td colspan="6" class="text-center text-muted py-4">No orders yet.</td></tr>
          <?php endif; ?>
          <?php foreach ($recentOrders as $o): ?>
            <tr>
              <td><a href="/admin/order-view.php?id=<?= (int)$o['id'] ?>">#<?= (int)$o['id'] ?></a></td>
              <td><?= e($o['username']) ?></td>
              <td class="text-truncate" style="max-width:220px"><?= e($o['service'] ?? '—') ?></td>
              <td><?= $cur.number_format((float)$o['charge'],2) ?></td>
              <td><span class="smm-badge st-<?= e($o['status']) ?>"><?= e(str_replace('_',' ',$o['status'])) ?></span></td>
              <td class="small text-muted"><?= e($o['created_at']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card smm-card">
      <div class="card-header bg-white border-0"><strong>Last 7 days</strong></div>
      <div class="card-body">
        <?php
        $max = 1;
        foreach ($chart as $c) $max = max($max, (int)$c['c']);
        ?>
        <?php foreach ($chart as $c): ?>
          <div class="d-flex align-items-center mb-2">
            <div class="small text-muted" style="width:80px"><?= e($c['d']) ?></div>
            <div class="flex-grow-1 bg-light rounded" style="height:14px;overflow:hidden">
              <div class="bg-primary h-100" style="width:<?= (int)round(($c['c']/$max)*100) ?>%"></div>
            </div>
            <div class="small ms-2" style="width:50px;text-align:right"><?= (int)$c['c'] ?></div>
          </div>
        <?php endforeach; ?>
        <?php if (!$chart): ?><div class="text-muted small">No data.</div><?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>