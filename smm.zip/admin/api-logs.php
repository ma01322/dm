<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'API Logs';
\Auth::requireAdmin();
$pdo = \DB::conn();

$userId = (int)($_GET['user_id'] ?? 0);
$action = trim((string)($_GET['action'] ?? ''));
$page = max(1,(int)($_GET['page']??1)); $per=50; $off=($page-1)*$per;
$where = []; $args = [];
if ($userId) { $where[] = 'l.user_id = ?'; $args[] = $userId; }
if ($action !== '') { $where[] = 'l.action = ?'; $args[] = $action; }
$sqlFrom = "FROM api_logs l LEFT JOIN users u ON u.id=l.user_id " . ($where ? 'WHERE '.implode(' AND ',$where):'');
$stc = $pdo->prepare("SELECT COUNT(*) $sqlFrom"); $stc->execute($args); $total=(int)$stc->fetchColumn();
$st = $pdo->prepare("SELECT l.*, u.username $sqlFrom ORDER BY l.id DESC LIMIT $per OFFSET $off");
$st->execute($args); $rows = $st->fetchAll();

include __DIR__ . '/partials/header.php'; include __DIR__ . '/partials/sidebar.php';
?>
<div class="card smm-card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-3"><input name="user_id" type="number" class="form-control" placeholder="User ID" value="<?= $userId ?: '' ?>"></div>
    <div class="col-md-3"><input name="action" class="form-control" placeholder="action" value="<?= e($action) ?>"></div>
    <div class="col-md-2"><button class="btn btn-primary w-100">Filter</button></div>
  </form>
</div></div>

<div class="card smm-card"><div class="table-responsive">
<table class="table smm-table mb-0 small">
  <thead><tr><th>#</th><th>User</th><th>Action</th><th>IP</th><th>Code</th><th>ms</th><th>Error</th><th>Date</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $l): ?>
    <tr>
      <td>#<?= (int)$l['id'] ?></td>
      <td><?= e($l['username'] ?? '—') ?></td>
      <td><code><?= e((string)$l['action']) ?></code></td>
      <td class="text-muted"><?= e((string)$l['ip']) ?></td>
      <td><span class="badge <?= (int)$l['response_code']>=200 && (int)$l['response_code']<300 ? 'bg-success':'bg-danger' ?>"><?= (int)$l['response_code'] ?></span></td>
      <td><?= (int)$l['response_ms'] ?></td>
      <td class="text-danger"><?= e((string)$l['error']) ?></td>
      <td class="text-muted"><?= e($l['created_at']) ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted py-4">No logs.</td></tr><?php endif; ?>
  </tbody>
</table>
</div>
<?php $tp = max(1,(int)ceil($total/$per)); if ($tp>1): ?>
  <div class="card-body"><nav><ul class="pagination pagination-sm mb-0">
    <?php for ($i=1;$i<=$tp;$i++): ?>
      <li class="page-item <?= $i===$page?'active':'' ?>"><a class="page-link" href="?page=<?= $i ?>&user_id=<?= $userId ?>&action=<?= urlencode($action) ?>"><?= $i ?></a></li>
    <?php endfor; ?>
  </ul></nav></div>
<?php endif; ?>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>