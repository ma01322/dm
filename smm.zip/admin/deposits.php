<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$adminTitle = 'Deposits';
\Auth::requireAdmin();
$pdo = \DB::conn();

if (isset($_GET['ajax']) && is_post()) {
    \Csrf::require();
    $action = (string)($_POST['action'] ?? '');
    $id = (int)($_POST['id'] ?? 0);
    try {
        if ($action === 'deposit.approve') {
            \Services\DepositService::complete($id, 'admin');
            \Logger::activity((int)\Auth::id(), 'admin', 'deposit.approve', 'deposit', $id);
            \Response::json(['message' => 'Deposit approved', 'reload' => true]);
        }
        if ($action === 'deposit.reject') {
            \Services\DepositService::cancel($id, 'rejected_by_admin');
            \Logger::activity((int)\Auth::id(), 'admin', 'deposit.reject', 'deposit', $id);
            \Response::json(['message' => 'Deposit rejected', 'reload' => true]);
        }
        \Response::json(['error' => 'Unknown action'], 400);
    } catch (\Throwable $e) { \Response::json(['error' => $e->getMessage()], 400); }
}

$status = $_GET['status'] ?? '';
$page = max(1,(int)($_GET['page']??1)); $per=25; $off=($page-1)*$per;
$where = []; $args = [];
if ($status) { $where[] = 'd.status = ?'; $args[] = $status; }
$sqlFrom = "FROM deposits d JOIN users u ON u.id=d.user_id JOIN payment_gateways g ON g.id=d.gateway_id " . ($where ? 'WHERE '.implode(' AND ',$where):'');
$stc = $pdo->prepare("SELECT COUNT(*) $sqlFrom"); $stc->execute($args); $total=(int)$stc->fetchColumn();
$st = $pdo->prepare("SELECT d.*, u.username, g.name AS gateway $sqlFrom ORDER BY d.id DESC LIMIT $per OFFSET $off");
$st->execute($args); $rows = $st->fetchAll();
$cur = \Models\Setting::get('currency_symbol','৳');

include __DIR__ . '/partials/header.php'; include __DIR__ . '/partials/sidebar.php';
?>
<div class="card smm-card mb-3"><div class="card-body">
  <form method="get" class="row g-2">
    <div class="col-md-3"><select name="status" class="form-select">
      <option value="">All statuses</option>
      <?php foreach (['pending','processing','completed','failed','canceled','refunded'] as $s): ?>
        <option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= $s ?></option>
      <?php endforeach; ?>
    </select></div>
    <div class="col-md-2"><button class="btn btn-primary w-100">Filter</button></div>
  </form>
</div></div>

<div class="card smm-card"><div class="table-responsive">
<table class="table smm-table mb-0">
  <thead><tr><th>#</th><th>User</th><th>Gateway</th><th>Amount</th><th>Fee</th><th>Net</th><th>Ref</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($rows as $d): ?>
    <tr>
      <td>#<?= (int)$d['id'] ?></td>
      <td><?= e($d['username']) ?></td>
      <td><?= e($d['gateway']) ?></td>
      <td><?= $cur.number_format((float)$d['amount'],2) ?></td>
      <td><?= $cur.number_format((float)$d['fee'],2) ?></td>
      <td class="fw-bold"><?= $cur.number_format((float)$d['net_amount'],2) ?></td>
      <td class="small"><code><?= e($d['reference'] ?? '') ?></code></td>
      <td><span class="badge <?= $d['status']==='completed'?'bg-success':($d['status']==='pending'?'bg-warning text-dark':'bg-secondary') ?>"><?= e($d['status']) ?></span></td>
      <td class="d-flex gap-1">
        <?php if ($d['status'] === 'pending'): ?>
          <button class="btn btn-sm btn-success" data-act="deposit.approve" data-id="<?= (int)$d['id'] ?>" data-confirm="Credit <?= $cur.number_format((float)$d['net_amount'],2) ?> to user?"><i class="fa-solid fa-check"></i></button>
          <button class="btn btn-sm btn-danger" data-act="deposit.reject" data-id="<?= (int)$d['id'] ?>" data-confirm="Reject this deposit?"><i class="fa-solid fa-xmark"></i></button>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="9" class="text-center text-muted py-4">No deposits.</td></tr><?php endif; ?>
  </tbody>
</table>
</div>
<?php $tp = max(1,(int)ceil($total/$per)); if ($tp>1): ?>
  <div class="card-body"><nav><ul class="pagination pagination-sm mb-0">
    <?php for ($i=1;$i<=$tp;$i++): ?>
      <li class="page-item <?= $i===$page?'active':'' ?>"><a class="page-link" href="?page=<?= $i ?>&status=<?= e($status) ?>"><?= $i ?></a></li>
    <?php endfor; ?>
  </ul></nav></div>
<?php endif; ?>
</div>

<script>
document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  if (b.dataset.confirm && !confirm(b.dataset.confirm)) return;
  const r = await SMM.post('/admin/deposits.php?ajax=1', { action:b.dataset.act, id:b.dataset.id });
  if (r.ok && !r.data.error) { SMM.toast(r.data.message,'success'); setTimeout(()=>location.reload(),600); }
  else SMM.toast(r.data.error || 'Failed','error');
});
</script>

<?php include __DIR__ . '/partials/footer.php'; ?>