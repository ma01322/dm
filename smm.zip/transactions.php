<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$userTitle = 'Transactions';
$me = \Auth::requireLogin();
$pdo = \DB::conn();
$page = max(1,(int)($_GET['page']??1)); $per=25; $off=($page-1)*$per;

$stc = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE user_id=?"); $stc->execute([(int)$me['id']]);
$total = (int)$stc->fetchColumn();

$st = $pdo->prepare("SELECT * FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT $per OFFSET $off");
$st->execute([(int)$me['id']]); $rows = $st->fetchAll();

$cur = \Models\Setting::get('currency_symbol','৳');
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>
<div class="card smm-card">
  <div class="table-responsive">
    <table class="table smm-table align-middle mb-0">
      <thead><tr><th>#</th><th>Type</th><th>Amount</th><th>Balance after</th><th>Description</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $t): ?>
        <tr>
          <td>#<?= (int)$t['id'] ?></td>
          <td><span class="badge bg-secondary"><?= e($t['type']) ?></span></td>
          <td class="<?= (float)$t['amount']<0?'text-danger':'text-success' ?>">
            <?= ((float)$t['amount']<0?'-':'+').$cur.number_format(abs((float)$t['amount']),2) ?>
          </td>
          <td><?= $cur.number_format((float)$t['balance_after'],2) ?></td>
          <td class="small text-muted"><?= e($t['description'] ?? '') ?></td>
          <td class="small text-muted"><?= e($t['created_at']) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="6" class="text-center text-muted py-4">No transactions.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>