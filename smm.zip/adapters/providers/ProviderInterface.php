<?php
declare(strict_types=1);
namespace Adapters\Providers;

interface ProviderInterface
{
    /**
     * @return array<int, array{service:string,name:string,category?:string,rate:string|float,min?:int,max?:int,type?:string,refill?:bool,cancel?:bool,dripfeed?:bool}>
     */
    public function getServices(): array;

    public function getBalance(): array;

    public function addOrder(string $serviceId, string $link, int $quantity, array $extra = []): array;

    public function getOrderStatus(string $providerOrderId): array;

    /** @param string[] $ids @return array<string,array> */
    public function getMultipleOrderStatus(array $ids): array;

    public function cancelOrder(string $providerOrderId): array;

    public function refillOrder(string $providerOrderId): array;
}