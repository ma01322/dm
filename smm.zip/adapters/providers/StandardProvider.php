<?php
declare(strict_types=1);
namespace Adapters\Providers;

/**
 * Standard adapter supporting the widely-adopted
 * `POST url  key=...&action=...` SMM-panel API contract.
 */
final class StandardProvider extends AbstractProvider
{
    public function getServices(): array
    {
        $res = $this->request(['action' => 'services']);
        if (!is_array($res) || !isset($res[0]) && !isset($res['services'])) {
            if (isset($res['error'])) throw new \RuntimeException('Provider: ' . (string)$res['error']);
        }
        $list = $res['services'] ?? $res;
        $out = [];
        foreach ((array)$list as $row) {
            if (!is_array($row) || !isset($row['service'])) continue;
            $out[] = [
                'service'  => (string)$row['service'],
                'name'     => (string)($row['name'] ?? ''),
                'category' => (string)($row['category'] ?? ''),
                'rate'     => (string)($row['rate'] ?? '0'),
                'min'      => (int)($row['min'] ?? 1),
                'max'      => (int)($row['max'] ?? 100000),
                'type'     => (string)($row['type'] ?? 'default'),
                'refill'   => !empty($row['refill']),
                'cancel'   => !empty($row['cancel']),
                'dripfeed' => !empty($row['dripfeed']),
            ];
        }
        return $out;
    }

    public function getBalance(): array
    {
        $res = $this->request(['action' => 'balance']);
        if (isset($res['error'])) throw new \RuntimeException('Provider: ' . $res['error']);
        return [
            'balance'  => (float)($res['balance'] ?? 0),
            'currency' => (string)($res['currency'] ?? 'USD'),
        ];
    }

    public function addOrder(string $serviceId, string $link, int $quantity, array $extra = []): array
    {
        $payload = ['action' => 'add', 'service' => $serviceId, 'link' => $link, 'quantity' => $quantity];
        foreach (['comments','runs','interval','username','min','max','delay','posts'] as $k) {
            if (!empty($extra[$k])) $payload[$k] = $extra[$k];
        }
        $res = $this->request($payload);
        if (isset($res['error'])) throw new \RuntimeException('Provider: ' . $res['error']);
        $orderId = (string)($res['order'] ?? '');
        if ($orderId === '') throw new \RuntimeException('Provider did not return an order id');
        return ['order' => $orderId, 'raw' => $res];
    }

    public function getOrderStatus(string $providerOrderId): array
    {
        $res = $this->request(['action' => 'status', 'order' => $providerOrderId]);
        if (isset($res['error'])) throw new \RuntimeException('Provider: ' . $res['error']);
        return [
            'status'      => $this->normalizeStatus($res['status'] ?? null),
            'start_count' => isset($res['start_count']) ? (int)$res['start_count'] : null,
            'remains'     => isset($res['remains'])     ? (int)$res['remains']     : null,
            'charge'      => isset($res['charge'])      ? (float)$res['charge']    : null,
            'raw'         => $res,
        ];
    }

    public function getMultipleOrderStatus(array $ids): array
    {
        $res = $this->request(['action' => 'status', 'orders' => implode(',', $ids)]);
        $out = [];
        if (!is_array($res)) return $out;
        foreach ($res as $oid => $row) {
            if (!is_array($row)) continue;
            $out[(string)$oid] = [
                'status'      => $this->normalizeStatus($row['status'] ?? null),
                'start_count' => isset($row['start_count']) ? (int)$row['start_count'] : null,
                'remains'     => isset($row['remains'])     ? (int)$row['remains']     : null,
                'charge'      => isset($row['charge'])      ? (float)$row['charge']    : null,
            ];
        }
        return $out;
    }

    public function cancelOrder(string $providerOrderId): array
    {
        $res = $this->request(['action' => 'cancel', 'order' => $providerOrderId]);
        return ['ok' => !isset($res['error']), 'raw' => $res];
    }

    public function refillOrder(string $providerOrderId): array
    {
        $res = $this->request(['action' => 'refill', 'order' => $providerOrderId]);
        return ['ok' => !isset($res['error']), 'raw' => $res];
    }
}