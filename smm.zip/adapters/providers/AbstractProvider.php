<?php
declare(strict_types=1);
namespace Adapters\Providers;

abstract class AbstractProvider implements ProviderInterface
{
    protected string $url;
    protected string $key;
    protected array  $provider;

    public function __construct(array $provider, string $decryptedKey)
    {
        $this->provider = $provider;
        $this->url      = rtrim($provider['api_url'], '/');
        $this->key      = $decryptedKey;
    }

    /**
     * HTTP POST with timeout, no exposed credentials in logs.
     */
    protected function request(array $payload): array
    {
        $payload['key'] = $this->key;

        $ch = curl_init($this->url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 25,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT      => 'SMMPanel/1.0',
            CURLOPT_HTTPHEADER     => ['Accept: application/json'],
        ]);
        $body = curl_exec($ch);
        $errno= curl_errno($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        // Log request (sanitized)
        $logReq = $payload; unset($logReq['key']);
        \Logger::info('provider', 'request', [
            'provider_id' => $this->provider['id'] ?? null,
            'url'         => $this->url,
            'payload'     => $logReq,
            'http_code'   => $code,
        ]);

        if ($errno) {
            \Logger::error('provider', 'curl error', ['id' => $this->provider['id'] ?? null, 'errno' => $errno, 'error' => $err]);
            throw new \RuntimeException('Provider connection failed: ' . $err);
        }
        if ($code >= 400) {
            \Logger::error('provider', 'http error', ['id' => $this->provider['id'] ?? null, 'code' => $code, 'body' => substr((string)$body, 0, 500)]);
            throw new \RuntimeException('Provider returned HTTP ' . $code);
        }

        $decoded = json_decode((string)$body, true);
        if (!is_array($decoded)) {
            \Logger::error('provider', 'invalid json', ['id' => $this->provider['id'] ?? null, 'body' => substr((string)$body, 0, 500)]);
            throw new \RuntimeException('Invalid response from provider');
        }

        // Sanitize response log
        $logRes = $decoded;
        if (isset($logRes['services']) && is_array($logRes['services'])) $logRes['services'] = '[…'.count($logRes['services']).']';
        \Logger::info('provider', 'response', ['id' => $this->provider['id'] ?? null, 'response' => $logRes]);

        return $decoded;
    }

    protected function normalizeStatus(?string $status): string
    {
        $s = strtolower(trim((string)$status));
        return match (true) {
            str_contains($s, 'complete')                         => 'completed',
            str_contains($s, 'partial')                          => 'partial',
            str_contains($s, 'cancel')                           => 'canceled',
            str_contains($s, 'refund')                           => 'refunded',
            str_contains($s, 'fail'), str_contains($s, 'error')  => 'failed',
            str_contains($s, 'progress'), str_contains($s, 'active') => 'in_progress',
            str_contains($s, 'pending'), str_contains($s, 'process') => 'processing',
            default                                              => 'processing',
        };
    }
}