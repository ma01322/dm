<?php
declare(strict_types=1);
namespace Adapters\Providers;

use Models\Provider;

final class ProviderFactory
{
    private const ADAPTERS = [
        'standard'      => StandardProvider::class,
    ];

    public static function make(int $providerId): ProviderInterface
    {
        $p = Provider::find($providerId);
        if (!$p) throw new \RuntimeException('Provider not found');
        if ($p['status'] !== 'active') throw new \RuntimeException('Provider disabled');

        $key = Provider::decryptedKey($p);
        $adapter = strtolower($p['adapter'] ?: 'standard');
        $class = self::ADAPTERS[$adapter] ?? StandardProvider::class;
        return new $class($p, $key);
    }

    public static function makeFromRow(array $p): ProviderInterface
    {
        $key = Provider::decryptedKey($p);
        $adapter = strtolower($p['adapter'] ?: 'standard');
        $class = self::ADAPTERS[$adapter] ?? StandardProvider::class;
        return new $class($p, $key);
    }

    public static function register(string $slug, string $class): void
    {
        // Simple runtime registration for custom adapters
        // (self::ADAPTERS is const so we keep dynamic registry separate)
        self::$dynamic[$slug] = $class;
    }

    private static array $dynamic = [];

    public static function resolveClass(string $slug): string
    {
        return self::$dynamic[strtolower($slug)] ?? self::ADAPTERS[strtolower($slug)] ?? StandardProvider::class;
    }
}