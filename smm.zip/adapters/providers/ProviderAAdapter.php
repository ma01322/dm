<?php
// Placeholder component.
