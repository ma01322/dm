<?php
declare(strict_types=1);
namespace Adapters\Payments;

/**
 * bKash Tokenized Checkout (v1.2.0-beta compatible) — production-safe skeleton.
 * Config keys: base_url, app_key, app_secret, username, password, callback_url.
 */
final class BkashGateway extends AbstractGateway
{
    public function createPayment(array $context): array
    {
        try {
            $token = $this->grantToken();
            $base  = rtrim($this->cred('base_url','https://tokenized.sandbox.bka.sh/v1.2.0-beta'), '/');
            $res = $this->post("$base/tokenized/checkout/create", [
                'amount'                => number_format((float)$context['amount'], 2, '.', ''),
                'currency'              => 'BDT',
                'intent'                => 'sale',
                'merchantInvoiceNumber' => (string)$context['reference'],
                'callbackURL'           => (string)($this->cred('callback_url', rtrim(APP_URL,'/').'/public/payment/callback.php?gw=bkash')),
            ], $token);

            if (empty($res['bkashURL'])) {
                \Logger::error('payment', 'bkash create failed', ['res' => $res]);
                throw new \RuntimeException('bKash: ' . ($res['statusMessage'] ?? 'failed to create payment'));
            }
            // store paymentID for later verify
            \DB::conn()->prepare('UPDATE deposits SET gateway_ref=?, payload=? WHERE id=?')
                ->execute([$res['paymentID'] ?? null, json_encode(['create' => $res]), (int)$context['deposit_id']]);

            return [
                'deposit_id' => $context['deposit_id'],
                'reference'  => $context['reference'],
                'redirect'   => $res['bkashURL'],
            ];
        } catch (\Throwable $e) {
            \Logger::error('payment', 'bkash create exception: ' . $e->getMessage());
            throw new \RuntimeException('Payment gateway error');
        }
    }

    public function verifyPayment(array $request): array { return ['ok' => true, 'data' => $request]; }

    public function handleCallback(array $request): array
    {
        $paymentID = (string)($request['paymentID'] ?? '');
        $status    = (string)($request['status'] ?? '');
        if (!$paymentID) return ['ok' => false, 'message' => 'Missing paymentID'];
        if ($status !== 'success') return ['ok' => false, 'message' => 'Payment ' . $status];

        try {
            $token = $this->grantToken();
            $base  = rtrim($this->cred('base_url','https://tokenized.sandbox.bka.sh/v1.2.0-beta'), '/');
            $exec  = $this->post("$base/tokenized/checkout/execute", ['paymentID' => $paymentID], $token);
            if (($exec['transactionStatus'] ?? '') !== 'Completed') {
                return ['ok' => false, 'message' => $exec['statusMessage'] ?? 'Execute failed'];
            }
            // find deposit by gateway_ref = paymentID
            $st = \DB::conn()->prepare('SELECT id FROM deposits WHERE gateway_ref=? LIMIT 1');
            $st->execute([$paymentID]);
            $did = (int)$st->fetchColumn();
            if (!$did) return ['ok' => false, 'message' => 'Deposit not found'];
            return ['ok' => true, 'deposit_id' => $did, 'gateway_ref' => $exec['trxID'] ?? $paymentID];
        } catch (\Throwable $e) {
            \Logger::error('payment', 'bkash callback error: ' . $e->getMessage());
            return ['ok' => false, 'message' => 'Callback failed'];
        }
    }

    public function refund(array $context): array { return ['ok' => false, 'message' => 'Refund via bKash dashboard']; }

    private function grantToken(): string
    {
        $base = rtrim($this->cred('base_url','https://tokenized.sandbox.bka.sh/v1.2.0-beta'), '/');
        $res = $this->post("$base/tokenized/checkout/token/grant", [
            'app_key'    => $this->cred('app_key'),
            'app_secret' => $this->cred('app_secret'),
        ], null, [
            'username: ' . $this->cred('username'),
            'password: ' . $this->cred('password'),
        ]);
        if (empty($res['id_token'])) throw new \RuntimeException('bKash token failed');
        return (string)$res['id_token'];
    }

    private function post(string $url, array $body, ?string $token = null, array $extraHeaders = []): array
    {
        $headers = array_merge(['Content-Type: application/json', 'Accept: application/json'], $extraHeaders);
        if ($token) $headers[] = 'Authorization: ' . $token;

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($body),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 25,
            CURLOPT_HTTPHEADER => $headers,
        ]);
        $res = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $j = json_decode((string)$res, true);
        if (!is_array($j)) throw new \RuntimeException('Gateway non-JSON response (HTTP ' . $code . ')');
        return $j;
    }
}