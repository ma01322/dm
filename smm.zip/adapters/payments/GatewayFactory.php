<?php
declare(strict_types=1);
namespace Adapters\Payments;

final class GatewayFactory
{
    private const MAP = [
        'manual' => ManualGateway::class,
        'bkash'  => BkashGateway::class,
        'nagad'  => NagadGateway::class,
    ];

    public static function make(array $gatewayRow): PaymentGatewayInterface
    {
        $slug  = strtolower($gatewayRow['adapter'] ?: $gatewayRow['code'] ?: 'manual');
        $class = self::MAP[$slug] ?? ManualGateway::class;
        return new $class($gatewayRow);
    }

    public static function supported(): array { return array_keys(self::MAP); }
}