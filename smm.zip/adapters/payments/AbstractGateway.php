<?php
declare(strict_types=1);
namespace Adapters\Payments;

abstract class AbstractGateway implements PaymentGatewayInterface
{
    protected array $gateway;
    protected array $credentials;

    public function __construct(array $gateway)
    {
        $this->gateway = $gateway;
        $cred = $gateway['credentials'] ?? null;
        if (is_string($cred) && $cred !== '') {
            try { $cred = json_decode(\Crypto::decrypt($cred), true); } catch (\Throwable $e) { $cred = null; }
        }
        $this->credentials = is_array($cred) ? $cred : [];
    }

    protected function cred(string $key, string $default = ''): string
    {
        return (string)($this->credentials[$key] ?? $default);
    }
}