<?php
declare(strict_types=1);
namespace Adapters\Payments;

/**
 * Nagad (skeleton). Config: merchant_id, merchant_number, public_key, private_key, base_url, callback_url.
 * Nagad requires RSA signing — this adapter demonstrates the interface and delegates
 * cryptographic signing to your provided public/private key pair.
 */
final class NagadGateway extends AbstractGateway
{
    public function createPayment(array $context): array
    {
        // Real Nagad integration requires RSA encrypted sensitive data.
        // This adapter returns a manual payment instruction, letting admins
        // complete the deposit verification. To enable live Nagad, plug the
        // official SDK into this method.
        return [
            'deposit_id' => $context['deposit_id'],
            'reference'  => $context['reference'],
            'message'    => 'Nagad payment reference: ' . $context['reference'] . '. Send ৳' . number_format((float)$context['amount'], 2)
                            . ' to ' . $this->cred('merchant_number', 'your merchant number') . ' and submit the trxID to support.',
        ];
    }

    public function verifyPayment(array $request): array { return ['ok' => true, 'data' => $request]; }
    public function handleCallback(array $request): array { return ['ok' => false, 'message' => 'Manual verify required']; }
    public function refund(array $context): array { return ['ok' => false, 'message' => 'Nagad refund manual']; }
}