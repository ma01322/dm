<?php
declare(strict_types=1);
namespace Adapters\Payments;

interface PaymentGatewayInterface
{
    /** Initiate a payment. Return array with optional 'redirect' URL or 'message'. */
    public function createPayment(array $context): array;

    /** Verify an incoming callback/IPN against the gateway. Return [ok, data]. */
    public function verifyPayment(array $request): array;

    /** Handle a callback to complete/cancel a deposit. */
    public function handleCallback(array $request): array;

    /** Refund (best-effort; manual gateways return false). */
    public function refund(array $context): array;
}