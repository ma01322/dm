<?php
declare(strict_types=1);
namespace Adapters\Payments;

final class ManualGateway extends AbstractGateway
{
    public function createPayment(array $context): array
    {
        return [
            'deposit_id' => $context['deposit_id'],
            'reference'  => $context['reference'],
            'message'    => $this->gateway['instructions']
                ?: 'Send the exact amount and submit the transaction ID to support. Your deposit will be credited after review.',
        ];
    }

    public function verifyPayment(array $request): array
    {
        return ['ok' => true, 'data' => $request];
    }

    public function handleCallback(array $request): array
    {
        return ['ok' => false, 'message' => 'Manual gateway has no automated callback.'];
    }

    public function refund(array $context): array
    {
        return ['ok' => false, 'message' => 'Manual refund requires admin action.'];
    }
}