<?php
class Database {}
