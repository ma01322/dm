<?php
declare(strict_types=1);
namespace Core;

use PDO;

abstract class Model
{
    protected static string $table = '';
    protected static string $primaryKey = 'id';

    protected static function pdo(): PDO { return \DB::conn(); }

    public static function find(int $id): ?array
    {
        $st = static::pdo()->prepare('SELECT * FROM ' . static::$table . ' WHERE ' . static::$primaryKey . ' = ? LIMIT 1');
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    public static function all(string $orderBy = 'id DESC', int $limit = 1000, int $offset = 0): array
    {
        // Whitelist order-by token-wise
        $orderBy = preg_replace('/[^A-Za-z0-9_ ,\.]/', '', $orderBy) ?: 'id DESC';
        $st = static::pdo()->prepare('SELECT * FROM ' . static::$table . " ORDER BY $orderBy LIMIT :l OFFSET :o");
        $st->bindValue(':l', $limit, PDO::PARAM_INT);
        $st->bindValue(':o', $offset, PDO::PARAM_INT);
        $st->execute();
        return $st->fetchAll();
    }

    public static function insert(array $data): int
    {
        $cols = array_keys($data);
        $ph   = array_map(fn($c) => ':' . $c, $cols);
        $sql  = sprintf('INSERT INTO %s (%s) VALUES (%s)', static::$table, implode(',', $cols), implode(',', $ph));
        $st   = static::pdo()->prepare($sql);
        foreach ($data as $k => $v) $st->bindValue(':' . $k, $v);
        $st->execute();
        return (int) static::pdo()->lastInsertId();
    }

    public static function update(int $id, array $data): bool
    {
        if (!$data) return false;
        $sets = implode(',', array_map(fn($c) => "$c = :$c", array_keys($data)));
        $st = static::pdo()->prepare('UPDATE ' . static::$table . " SET $sets WHERE " . static::$primaryKey . ' = :__id');
        foreach ($data as $k => $v) $st->bindValue(':' . $k, $v);
        $st->bindValue(':__id', $id, PDO::PARAM_INT);
        return $st->execute();
    }

    public static function delete(int $id): bool
    {
        $st = static::pdo()->prepare('DELETE FROM ' . static::$table . ' WHERE ' . static::$primaryKey . ' = ?');
        return $st->execute([$id]);
    }
}