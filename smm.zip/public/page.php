<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

$pages = [
    'terms'   => ['Terms of Service',   'By using this panel you agree to use it only for lawful social-media growth services. Orders are non-refundable once started, unless the provider fails to deliver.'],
    'privacy' => ['Privacy Policy',     'We store only the data needed to operate the panel: account info, orders, wallet movements and security logs. We never sell your data. Provider keys and gateway credentials are encrypted at rest.'],
    'contact' => ['Contact',           'For any question, open a support ticket from your dashboard, or email ' . \Models\Setting::get('support_email','support@example.com') . '.'],
];

$key = (string)($_GET['p'] ?? 'terms');
if (!isset($pages[$key])) $key = 'terms';
[$title,$body] = $pages[$key];
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> — <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/css/app.css" rel="stylesheet">
</head><body>
<nav class="navbar navbar-dark smm-nav"><div class="container">
  <a class="navbar-brand fw-bold" href="/"><i class="fa-solid fa-bolt me-1 text-warning"></i><?= e(\Models\Setting::get('site_name', APP_NAME)) ?></a>
  <a class="btn btn-warning btn-sm" href="/login.php">Login</a>
</div></nav>
<div class="container py-5" style="max-width:820px">
  <h1 class="mb-3"><?= e($title) ?></h1>
  <div class="card smm-card"><div class="card-body"><p class="mb-0"><?= nl2br(e($body)) ?></p></div></div>
  <div class="mt-3"><a href="/">← Back home</a></div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>