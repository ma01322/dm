<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

if (\Auth::check() && \Auth::role() === 'reseller') {
    redirect('/reseller/api-docs.php');
}
if (\Auth::check() && \Auth::role() === 'admin') {
    redirect('/reseller/api-docs.php');
}
$apiUrl = rtrim(APP_URL, '/') . '/api/v2';
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>API — <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="/assets/css/app.css" rel="stylesheet">
</head><body>
<nav class="navbar navbar-dark smm-nav"><div class="container">
  <a class="navbar-brand fw-bold" href="/"><i class="fa-solid fa-bolt me-1 text-warning"></i><?= e(\Models\Setting::get('site_name', APP_NAME)) ?></a>
  <div><a class="btn btn-warning btn-sm" href="/register.php">Become a reseller</a></div>
</div></nav>
<div class="container py-5" style="max-width:820px">
  <h1>Reseller REST API</h1>
  <p class="lead">Automate orders on <code><?= e($apiUrl) ?></code>. Sign up as a reseller to unlock your personal API key.</p>
  <div class="card smm-card"><div class="card-body">
    <h5>Quick peek</h5>
    <pre class="bg-dark text-light p-3 rounded"><code>POST <?= e($apiUrl) ?>
key=YOUR_KEY
action=services</code></pre>
    <p class="mb-0 small text-muted">Actions: <code>services</code>, <code>add</code>, <code>status</code>, <code>orders</code>, <code>balance</code>, <code>refill</code>, <code>cancel</code>.</p>
  </div></div>
  <div class="mt-4">
    <a class="btn btn-primary" href="/register.php"><i class="fa-solid fa-user-plus me-1"></i>Create reseller account</a>
    <a class="btn btn-outline-secondary" href="/login.php">Sign in</a>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>