<?php
declare(strict_types=1);
require_once __DIR__ . '/../../config/app.php';

$gw = strtolower((string)($_GET['gw'] ?? ''));
$pdo = \DB::conn();
$st = $pdo->prepare("SELECT * FROM payment_gateways WHERE code LIKE ? OR adapter = ? LIMIT 1");
$st->execute([$gw.'%', $gw]);
$g = $st->fetch();
if (!$g) { http_response_code(404); exit('Gateway not found'); }

try {
    $adapter = \Adapters\Payments\GatewayFactory::make($g);
    $result = $adapter->handleCallback($_REQUEST);
    if (!empty($result['ok']) && !empty($result['deposit_id'])) {
        \Services\DepositService::complete((int)$result['deposit_id'], (string)($result['gateway_ref'] ?? null));
        redirect('/user/add-funds.php?success=1');
    } else {
        \Logger::warn('payment', 'callback failed', ['gw' => $gw, 'msg' => $result['message'] ?? null]);
        redirect('/user/add-funds.php?failed=1');
    }
} catch (\Throwable $e) {
    \Logger::error('payment', 'callback exception: ' . $e->getMessage());
    redirect('/user/add-funds.php?failed=1');
}