<?php
declare(strict_types=1);
/**
 * Server-to-server webhook endpoint.
 * Real gateways POST here without a browser session.
 */
require_once __DIR__ . '/../../config/app.php';
header('Content-Type: application/json');

$gw = strtolower((string)($_GET['gw'] ?? ''));
$st = \DB::conn()->prepare("SELECT * FROM payment_gateways WHERE code LIKE ? OR adapter = ? LIMIT 1");
$st->execute([$gw.'%', $gw]);
$g = $st->fetch();
if (!$g) { http_response_code(404); echo json_encode(['error' => 'gateway']); exit; }

$body = file_get_contents('php://input');
$data = json_decode((string)$body, true) ?: $_POST;

try {
    $adapter = \Adapters\Payments\GatewayFactory::make($g);
    $result = $adapter->handleCallback($data);
    if (!empty($result['ok']) && !empty($result['deposit_id'])) {
        \Services\DepositService::complete((int)$result['deposit_id'], (string)($result['gateway_ref'] ?? null));
        echo json_encode(['ok' => true]);
    } else {
        echo json_encode(['ok' => false, 'message' => $result['message'] ?? 'not ok']);
    }
} catch (\Throwable $e) {
    \Logger::error('payment', 'ipn error: ' . $e->getMessage());
    echo json_encode(['ok' => false]);
}