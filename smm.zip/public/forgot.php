<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

if (\Auth::check()) redirect('/user/index.php');

$msg = null; $err = null;
if (is_post()) {
    \Csrf::require();
    $email = trim((string)($_POST['email'] ?? ''));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = 'Enter a valid email.';
    } else {
        $user = \Models\User::findByEmail($email);
        // Always show success to avoid user enumeration
        $msg = 'If that email exists, a reset link has been sent.';
        if ($user) {
            $token = bin2hex(random_bytes(32));
            \DB::conn()->prepare('UPDATE users SET reset_token=?, reset_expires=DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id=?')
                ->execute([hash('sha256', $token), (int)$user['id']]);
            $link = rtrim(APP_URL, '/') . '/public/reset.php?token=' . $token . '&id=' . (int)$user['id'];
            // Attempt to send — if no mailer configured, log the link (dev fallback)
            $sent = @mail($email, 'Password reset', "Reset your password: $link", 'From: ' . \Models\Setting::get('support_email','no-reply@localhost'));
            if (!$sent) \Logger::info('app', 'password reset link (mail not configured)', ['user' => (int)$user['id'], 'link' => $link]);
        }
    }
}
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Forgot password — <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light">
<div class="container py-5" style="max-width:460px">
  <div class="card shadow-sm border-0"><div class="card-body p-4">
    <h4 class="mb-3 text-center">Reset your password</h4>
    <?php if ($msg): ?><div class="alert alert-success py-2 small"><?= e($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="alert alert-danger py-2 small"><?= e($err) ?></div><?php endif; ?>
    <form method="post" novalidate>
      <?= \Csrf::field() ?>
      <div class="mb-3"><label class="form-label small">Email</label>
        <input name="email" type="email" class="form-control" required></div>
      <button class="btn btn-primary w-100">Send reset link</button>
    </form>
    <div class="text-center mt-3 small"><a href="/login.php">Back to login</a></div>
  </div></div>
</div></body></html>