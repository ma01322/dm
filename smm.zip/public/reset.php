<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

$token = (string)($_GET['token'] ?? '');
$id    = (int)($_GET['id'] ?? 0);
if ($token === '' || !$id) { http_response_code(400); exit('Invalid link'); }

$pdo = \DB::conn();
$st = $pdo->prepare('SELECT * FROM users WHERE id=? AND reset_token=? AND reset_expires > NOW() LIMIT 1');
$st->execute([$id, hash('sha256', $token)]);
$user = $st->fetch();
if (!$user) { http_response_code(400); exit('Link expired or invalid'); }

$msg = null; $err = null;
if (is_post()) {
    \Csrf::require();
    $p1 = (string)($_POST['password'] ?? '');
    $p2 = (string)($_POST['confirm'] ?? '');
    if ($p1 !== $p2) $err = 'Passwords do not match.';
    else {
        $v = (new \Validator(['password'=>$p1]))->password('password');
        if ($v->fails()) $err = $v->firstError();
        else {
            $pdo->prepare('UPDATE users SET password_hash=?, reset_token=NULL, reset_expires=NULL WHERE id=?')
                ->execute([password_hash($p1, PASSWORD_BCRYPT, ['cost'=>12]), $id]);
            \Logger::activity($id, (string)$user['role'], 'user.password_reset', 'user', $id);
            $msg = 'Password reset successful. You can now <a href="/login.php">sign in</a>.';
        }
    }
}
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reset password — <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light">
<div class="container py-5" style="max-width:460px">
  <div class="card shadow-sm border-0"><div class="card-body p-4">
    <h4 class="mb-3 text-center">Choose a new password</h4>
    <?php if ($msg): ?><div class="alert alert-success py-2 small"><?= $msg ?></div><?php endif; ?>
    <?php if ($err): ?><div class="alert alert-danger py-2 small"><?= e($err) ?></div><?php endif; ?>
    <?php if (!$msg): ?>
    <form method="post" novalidate>
      <?= \Csrf::field() ?>
      <div class="mb-3"><label class="form-label small">New password</label>
        <input type="password" name="password" class="form-control" required></div>
      <div class="mb-3"><label class="form-label small">Confirm</label>
        <input type="password" name="confirm" class="form-control" required></div>
      <button class="btn btn-primary w-100">Update password</button>
    </form>
    <?php endif; ?>
  </div></div>
</div></body></html>