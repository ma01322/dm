<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$userTitle = 'API';
$me = \Auth::requireReseller();
$pdo = \DB::conn();
$userId = (int)$me['id'];

if (is_post()) {
    \Csrf::require();
    $do = (string)($_POST['do'] ?? '');
    try {
        if ($do === 'generate') {
            $active = \Models\ApiKey::activeForUser($userId);
            if ($active) throw new \RuntimeException('Revoke your current key first.');
            $limit = (int)\Models\Setting::get('api_default_rate_limit', '60');
            $row = \Models\ApiKey::generate($userId, 'Default', $limit);
            \Session::flash('new_key', $row['key']);
            \Logger::activity($userId, 'reseller', 'api.key_generate', 'api_key', $row['id']);
            redirect('/reseller/api.php');
        }
        if ($do === 'revoke') {
            $id = (int)($_POST['key_id'] ?? 0);
            if (\Models\ApiKey::revoke($id, $userId)) {
                \Logger::activity($userId, 'reseller', 'api.key_revoke', 'api_key', $id);
                \Session::flash('ok', 'API key revoked.');
            } else \Session::flash('err', 'Key not found.');
            redirect('/reseller/api.php');
        }
        if ($do === 'regenerate') {
            // Revoke all actives, then generate fresh
            $pdo->prepare('UPDATE api_keys SET status="revoked", revoked_at=NOW() WHERE user_id=? AND status="active"')->execute([$userId]);
            $limit = (int)\Models\Setting::get('api_default_rate_limit', '60');
            $row = \Models\ApiKey::generate($userId, 'Default', $limit);
            \Session::flash('new_key', $row['key']);
            \Logger::activity($userId, 'reseller', 'api.key_regenerate', 'api_key', $row['id']);
            redirect('/reseller/api.php');
        }
    } catch (\Throwable $e) {
        \Session::flash('err', $e->getMessage());
        redirect('/reseller/api.php');
    }
}

$active = \Models\ApiKey::activeForUser($userId);
$all    = \Models\ApiKey::stats($userId);
$newKey = \Session::flash('new_key');
$ok     = \Session::flash('ok');
$err    = \Session::flash('err');
$apiUrl = rtrim(APP_URL, '/') . '/api/v2';
$enabled = \Models\Setting::get('reseller_api_enabled','1') === '1';

include __DIR__ . '/../user/partials/header.php';
include __DIR__ . '/../user/partials/sidebar.php';
?>

<?php if ($ok): ?><div class="alert alert-success py-2"><?= e($ok) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>
<?php if (!$enabled): ?><div class="alert alert-warning py-2">Reseller API is currently disabled by the administrator.</div><?php endif; ?>

<?php if ($newKey): ?>
  <div class="alert alert-warning">
    <strong>Save this API key now. It will not be shown again.</strong>
    <div class="input-group mt-2">
      <input id="newKey" class="form-control font-monospace" value="<?= e($newKey) ?>" readonly>
      <button class="btn btn-outline-secondary" onclick="navigator.clipboard.writeText(document.getElementById('newKey').value); SMM.toast('Copied','success')">Copy</button>
    </div>
  </div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="card smm-card mb-3"><div class="card-body">
      <h6>API endpoint</h6>
      <div class="input-group">
        <input class="form-control font-monospace" value="<?= e($apiUrl) ?>" readonly>
        <a class="btn btn-outline-secondary" href="/reseller/api-docs.php">Docs</a>
      </div>
      <div class="small text-muted mt-2">POST <code>action=services</code> · <code>action=add</code> · <code>action=status</code> · <code>action=orders</code> · <code>action=balance</code></div>
    </div></div>

    <div class="card smm-card mb-3"><div class="card-body">
      <h6>Active key</h6>
      <?php if ($active): ?>
        <div class="d-flex flex-wrap gap-2 align-items-center">
          <code class="me-2"><?= e($active['key_prefix']) ?>••••••••••••••••••••••••••••••••••••••••</code>
          <span class="badge bg-success">active</span>
        </div>
        <div class="small text-muted mt-2">
          Rate limit: <?= (int)$active['rate_limit'] ?>/min ·
          Total requests: <?= (int)$active['total_requests'] ?> ·
          Last used: <?= e($active['last_used_at'] ?? '—') ?>
        </div>
        <div class="mt-3 d-flex gap-2">
          <form method="post" onsubmit="return confirm('Regenerating will immediately invalidate your current key. Continue?')">
            <?= \Csrf::field() ?>
            <input type="hidden" name="do" value="regenerate">
            <button class="btn btn-outline-warning"><i class="fa-solid fa-rotate me-1"></i>Regenerate key</button>
          </form>
          <form method="post" onsubmit="return confirm('Revoke this key? API access will stop immediately.')">
            <?= \Csrf::field() ?>
            <input type="hidden" name="do" value="revoke">
            <input type="hidden" name="key_id" value="<?= (int)$active['id'] ?>">
            <button class="btn btn-outline-danger"><i class="fa-solid fa-ban me-1"></i>Revoke key</button>
          </form>
        </div>
      <?php else: ?>
        <div class="alert alert-info small mb-3">You don't have an active API key.</div>
        <form method="post">
          <?= \Csrf::field() ?>
          <input type="hidden" name="do" value="generate">
          <button class="btn btn-primary"><i class="fa-solid fa-key me-1"></i>Generate API key</button>
        </form>
      <?php endif; ?>
    </div></div>

    <div class="card smm-card">
      <div class="card-header bg-white"><strong>Key history</strong></div>
      <div class="table-responsive">
        <table class="table smm-table mb-0">
          <thead><tr><th>Prefix</th><th>Status</th><th>Total requests</th><th>Last used</th><th>Created</th></tr></thead>
          <tbody>
          <?php foreach ($all as $k): ?>
            <tr>
              <td><code><?= e($k['key_prefix']) ?>…</code></td>
              <td><span class="badge <?= $k['status']==='active'?'bg-success':'bg-secondary' ?>"><?= e($k['status']) ?></span></td>
              <td><?= (int)$k['total_requests'] ?> <span class="text-muted small">(24h: <?= (int)$k['req_24h'] ?>)</span></td>
              <td class="small text-muted"><?= e($k['last_used_at'] ?? '—') ?></td>
              <td class="small text-muted"><?= e($k['created_at']) ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$all): ?><tr><td colspan="5" class="text-center text-muted py-3">No keys yet.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card smm-card mb-3"><div class="card-body">
      <h6>Quick reference</h6>
      <pre class="bg-dark text-light p-2 rounded small mb-0" style="overflow:auto">
POST <?= e($apiUrl) ?>
Content-Type: application/x-www-form-urlencoded

key=YOUR_KEY
&action=balance</pre>
      <a class="small" href="/reseller/api-docs.php">Full documentation →</a>
    </div></div>

    <div class="card smm-card"><div class="card-body">
      <h6>Your stats (24h)</h6>
      <?php
        $st = \DB::conn()->prepare("SELECT COUNT(*) AS c, COALESCE(AVG(response_ms),0) AS avg_ms
                                    FROM api_logs WHERE user_id=? AND created_at >= (NOW() - INTERVAL 24 HOUR)");
        $st->execute([$userId]); $stt = $st->fetch();
      ?>
      <div class="d-flex justify-content-between"><span class="text-muted small">Requests</span><b><?= (int)$stt['c'] ?></b></div>
      <div class="d-flex justify-content-between"><span class="text-muted small">Avg latency</span><b><?= number_format((float)$stt['avg_ms'],0) ?> ms</b></div>
    </div></div>
  </div>
</div>

<?php include __DIR__ . '/../user/partials/footer.php'; ?>