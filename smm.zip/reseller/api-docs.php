<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$userTitle = 'API Documentation';
$me = \Auth::requireReseller();
$apiUrl = rtrim(APP_URL, '/') . '/api/v2';
$sampleKey = 'SMM_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
include __DIR__ . '/../user/partials/header.php';
include __DIR__ . '/../user/partials/sidebar.php';
?>

<div class="card smm-card mb-3"><div class="card-body">
  <h4>API Documentation</h4>
  <p class="text-muted mb-0">Resell our services from your own panel, website, or software. All requests are <code>POST</code> with <code>application/x-www-form-urlencoded</code> body and return JSON.</p>
</div></div>

<div class="row g-3">
  <div class="col-lg-9">

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>Base URL</strong></div>
      <div class="card-body">
        <pre class="mb-0"><code>POST <?= e($apiUrl) ?></code></pre>
      </div>
    </div>

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>Authentication</strong></div>
      <div class="card-body">
        <p class="small mb-2">Every request must include your personal <code>key</code> parameter. Requests without a valid key are rejected with HTTP 401.</p>
        <pre class="mb-0"><code>key=<?= e($sampleKey) ?></code></pre>
        <p class="small mt-3 mb-0">Rate limit: 60 req/min per key (configurable). Exceeding the limit returns HTTP 429.</p>
      </div>
    </div>

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>1. Services</strong></div>
      <div class="card-body">
        <p class="small">Returns all API-visible services.</p>
        <p class="small mb-1"><b>Parameters:</b> <code>action=services</code></p>
<pre class="bg-dark text-light p-3 rounded"><code>curl -X POST <?= e($apiUrl) ?> \
  -d "key=YOUR_KEY" \
  -d "action=services"</code></pre>
<pre class="bg-dark text-light p-3 rounded"><code>[
  {
    "service": 1,
    "name": "Instagram Followers",
    "category": "Instagram",
    "rate": "1.50",
    "min": "100",
    "max": "10000",
    "type": "default",
    "refill": false,
    "cancel": true,
    "dripfeed": false
  }
]</code></pre>
      </div>
    </div>

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>2. Add order</strong></div>
      <div class="card-body">
        <p class="small mb-1"><b>Parameters:</b></p>
        <table class="table table-sm small">
          <thead><tr><th>Field</th><th>Required</th><th>Description</th></tr></thead>
          <tbody>
            <tr><td><code>action</code></td><td>Yes</td><td><code>add</code></td></tr>
            <tr><td><code>service</code></td><td>Yes</td><td>Service ID from the services list</td></tr>
            <tr><td><code>link</code></td><td>Yes</td><td>Public URL to boost</td></tr>
            <tr><td><code>quantity</code></td><td>Yes</td><td>Integer within min/max of the service</td></tr>
            <tr><td><code>runs</code>, <code>interval</code></td><td>No</td><td>Drip-feed only</td></tr>
            <tr><td><code>comments</code>, <code>username</code></td><td>No</td><td>Custom comments / mentions</td></tr>
          </tbody>
        </table>
<pre class="bg-dark text-light p-3 rounded"><code>POST <?= e($apiUrl) ?>
key=YOUR_KEY
action=add
service=1
link=https://instagram.com/p/xxxx
quantity=1000</code></pre>
<pre class="bg-dark text-light p-3 rounded"><code>{ "order": 123456 }</code></pre>
      </div>
    </div>

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>3. Order status</strong></div>
      <div class="card-body">
        <p class="small mb-1"><b>Parameters:</b> <code>action=status</code> <code>order=123456</code></p>
<pre class="bg-dark text-light p-3 rounded"><code>curl -X POST <?= e($apiUrl) ?> -d "key=YOUR_KEY" -d "action=status" -d "order=123456"</code></pre>
<pre class="bg-dark text-light p-3 rounded"><code>{
  "charge": "1.5000",
  "start_count": "100",
  "status": "In progress",
  "remains": "500",
  "currency": "BDT",
  "order": 123456
}</code></pre>
      </div>
    </div>

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>4. Multiple order status</strong></div>
      <div class="card-body">
        <p class="small mb-1"><b>Parameters:</b> <code>action=orders</code> <code>orders=111,222,333</code> (max 100)</p>
<pre class="bg-dark text-light p-3 rounded"><code>{
  "111": { "charge":"1.50","start_count":"0","status":"Processing","remains":"1000","currency":"BDT" },
  "222": { "charge":"2.00","start_count":"50","status":"Completed","remains":"0","currency":"BDT" }
}</code></pre>
      </div>
    </div>

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>5. Balance</strong></div>
      <div class="card-body">
        <p class="small mb-1"><b>Parameters:</b> <code>action=balance</code></p>
<pre class="bg-dark text-light p-3 rounded"><code>{ "balance": "100.00", "currency": "BDT" }</code></pre>
      </div>
    </div>

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>6. Refill</strong></div>
      <div class="card-body">
        <p class="small mb-1"><b>Parameters:</b> <code>action=refill</code> <code>order=123456</code></p>
<pre class="bg-dark text-light p-3 rounded"><code>{ "refill": "123456" }</code></pre>
      </div>
    </div>

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>7. Cancel</strong></div>
      <div class="card-body">
        <p class="small mb-1"><b>Parameters:</b> <code>action=cancel</code> <code>order=123456</code></p>
<pre class="bg-dark text-light p-3 rounded"><code>{ "cancel": "123456" }</code></pre>
      </div>
    </div>

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>Error format</strong></div>
      <div class="card-body">
<pre class="bg-dark text-light p-3 rounded"><code>{ "error": "Insufficient balance" }</code></pre>
        <div class="small text-muted">Common errors: Missing API key · Invalid API key · Account is not active · Rate limit exceeded · Service not available · Insufficient balance · Incorrect order ID · Order cannot be canceled</div>
      </div>
    </div>

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>Integration examples</strong></div>
      <div class="card-body">
        <ul class="nav nav-tabs small" role="tablist">
          <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#php">PHP</button></li>
          <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#js">JavaScript</button></li>
          <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#py">Python</button></li>
          <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#curl">cURL</button></li>
        </ul>
        <div class="tab-content pt-3">
          <div class="tab-pane fade show active" id="php">
<pre class="bg-dark text-light p-3 rounded"><code>&lt;?php
$api = '<?= e($apiUrl) ?>';
$key = '<?= e($sampleKey) ?>';

function api($api, $key, $params) {
    $params['key'] = $key;
    $ch = curl_init($api);
    curl_setopt_array($ch, [
        CURLOPT_POST           =&gt; true,
        CURLOPT_POSTFIELDS     =&gt; http_build_query($params),
        CURLOPT_RETURNTRANSFER =&gt; true,
        CURLOPT_TIMEOUT        =&gt; 30,
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}

// Fetch services
$services = api($api, $key, ['action' =&gt; 'services']);

// Place order
$order = api($api, $key, [
    'action'   =&gt; 'add',
    'service'  =&gt; 1,
    'link'     =&gt; 'https://instagram.com/p/xxx',
    'quantity' =&gt; 1000,
]);
echo $order['order'];</code></pre>
          </div>
          <div class="tab-pane fade" id="js">
<pre class="bg-dark text-light p-3 rounded"><code>const API = '<?= e($apiUrl) ?>';
const KEY = '<?= e($sampleKey) ?>';

async function api(params) {
  const body = new URLSearchParams({ key: KEY, ...params });
  const r = await fetch(API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body
  });
  return r.json();
}

// Balance
api({ action: 'balance' }).then(console.log);

// Add order
api({ action: 'add', service: 1, link: 'https://...', quantity: 1000 })
  .then(res =&gt; console.log(res.order));</code></pre>
          </div>
          <div class="tab-pane fade" id="py">
<pre class="bg-dark text-light p-3 rounded"><code>import requests

API = '<?= e($apiUrl) ?>'
KEY = '<?= e($sampleKey) ?>'

def api(**params):
    params['key'] = KEY
    r = requests.post(API, data=params, timeout=30)
    return r.json()

print(api(action='balance'))
print(api(action='add', service=1, link='https://...', quantity=1000))</code></pre>
          </div>
          <div class="tab-pane fade" id="curl">
<pre class="bg-dark text-light p-3 rounded"><code>curl -X POST <?= e($apiUrl) ?> \
  -d "key=<?= e($sampleKey) ?>" \
  -d "action=services"</code></pre>
          </div>
        </div>
      </div>
    </div>

    <div class="card smm-card mb-3">
      <div class="card-header bg-white"><strong>Best practices</strong></div>
      <div class="card-body small">
        <ul class="mb-0 ps-3">
          <li>Cache the services list — refresh a few times per day.</li>
          <li>Handle HTTP 429 by backing off, not by retrying immediately.</li>
          <li>Always verify <code>order</code> exists in the response before storing it.</li>
          <li>Never expose your API key in client-side code.</li>
          <li>Use the <code>orders</code> endpoint (batch) rather than many <code>status</code> calls.</li>
        </ul>
      </div>
    </div>

  </div>

  <div class="col-lg-3">
    <div class="card smm-card sticky-top" style="top:80px">
      <div class="card-body small">
        <strong>On this page</strong>
        <ul class="list-unstyled mt-2 mb-0">
          <li><a href="#">Base URL</a></li>
          <li><a href="#">Authentication</a></li>
          <li><a href="#">1. Services</a></li>
          <li><a href="#">2. Add order</a></li>
          <li><a href="#">3. Order status</a></li>
          <li><a href="#">4. Multiple order status</a></li>
          <li><a href="#">5. Balance</a></li>
          <li><a href="#">6. Refill</a></li>
          <li><a href="#">7. Cancel</a></li>
          <li><a href="#">Errors</a></li>
          <li><a href="#">Integration examples</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../user/partials/footer.php'; ?>