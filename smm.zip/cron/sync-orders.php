<?php
declare(strict_types=1);
require_once __DIR__ . '/_bootstrap.php';

if (!cron_lock('sync-orders', 300)) { cron_log('sync-orders: already locked'); exit; }

try {
    $res = \Services\SyncService::syncBatch(200);
    cron_log("sync-orders: checked={$res['checked']} changed={$res['changed']}");
} catch (\Throwable $e) {
    cron_log('sync-orders ERROR: ' . $e->getMessage());
} finally {
    cron_unlock('sync-orders');
}