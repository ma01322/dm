<?php
declare(strict_types=1);
/**
 * Shared cron bootstrap:
 *  - prevents duplicate runs via cron_locks
 *  - logs to cron.log
 *  - CLI-only (or admin via secret token)
 */
require_once __DIR__ . '/../config/app.php';

if (PHP_SAPI !== 'cli') {
    // Allow web invocation only with token
    $token = $_GET['token'] ?? '';
    if ($token === '' || $token !== hash_hmac('sha256', 'cron', APP_KEY_B64)) {
        http_response_code(403); exit('Forbidden');
    }
    header('Content-Type: text/plain');
}

function cron_lock(string $name, int $ttlSeconds = 600): bool
{
    $pdo = \DB::conn();
    $pdo->prepare('DELETE FROM cron_locks WHERE name=? AND expires_at < NOW()')->execute([$name]);
    try {
        $pdo->prepare('INSERT INTO cron_locks (name, locked_at, expires_at, owner) VALUES (?, NOW(), DATE_ADD(NOW(), INTERVAL ? SECOND), ?)')
            ->execute([$name, $ttlSeconds, gethostname() ?: 'unknown']);
        return true;
    } catch (\Throwable $e) {
        return false; // already locked
    }
}
function cron_unlock(string $name): void
{
    \DB::conn()->prepare('DELETE FROM cron_locks WHERE name=?')->execute([$name]);
}
function cron_log(string $msg): void
{
    $line = '[' . gmdate('Y-m-d H:i:s') . '] ' . $msg . PHP_EOL;
    @file_put_contents(LOGS_PATH . '/cron.log', $line, FILE_APPEND | LOCK_EX);
    if (PHP_SAPI === 'cli') echo $line;
}