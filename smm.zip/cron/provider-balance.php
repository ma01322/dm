<?php
declare(strict_types=1);
require_once __DIR__ . '/_bootstrap.php';

if (!cron_lock('provider-balance', 600)) { cron_log('provider-balance: already locked'); exit; }
try {
    $providers = \Models\Provider::active();
    foreach ($providers as $p) {
        try {
            $bal = \Services\ProviderService::fetchBalance((int)$p['id']);
            cron_log("provider-balance #{$p['id']} {$p['name']} = " . ($bal ?? 'null'));
        } catch (\Throwable $e) {
            cron_log("provider-balance #{$p['id']} FAILED: " . $e->getMessage());
        }
    }
} finally {
    cron_unlock('provider-balance');
}