<?php
declare(strict_types=1);
require_once __DIR__ . '/_bootstrap.php';

if (!cron_lock('process-refunds', 300)) { cron_log('process-refunds: already locked'); exit; }

try {
    $pdo = \DB::conn();
    // Auto-cancel stale pending orders (older than 24h, still pending with no provider order)
    $stale = $pdo->query("SELECT id FROM orders
                          WHERE status='pending' AND provider_order_id IS NULL
                          AND created_at < (NOW() - INTERVAL 1 DAY) LIMIT 200")->fetchAll();
    $count = 0;
    foreach ($stale as $row) {
        try {
            \Services\OrderService::refund((int)$row['id'], null, 'Auto refund: manual review timeout');
            $pdo->prepare("UPDATE orders SET status='failed' WHERE id=?")->execute([(int)$row['id']]);
            $count++;
        } catch (\Throwable $e) { cron_log('refund #' . $row['id'] . ' failed: ' . $e->getMessage()); }
    }
    cron_log("process-refunds: $count orders refunded");
} finally {
    cron_unlock('process-refunds');
}