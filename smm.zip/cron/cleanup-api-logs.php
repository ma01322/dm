<?php
declare(strict_types=1);
require_once __DIR__ . '/_bootstrap.php';

if (!cron_lock('cleanup-api-logs', 3600)) { cron_log('cleanup-api-logs: already locked'); exit; }
try {
    $pdo = \DB::conn();
    $deleted = $pdo->exec("DELETE FROM api_logs WHERE created_at < (NOW() - INTERVAL 30 DAY)");
    $pdo->exec("DELETE FROM login_logs WHERE created_at < (NOW() - INTERVAL 90 DAY)");
    $pdo->exec("DELETE FROM rate_limits WHERE window_at < (NOW() - INTERVAL 2 HOUR)");
    $pdo->exec("DELETE FROM cron_locks WHERE expires_at < NOW()");
    cron_log("cleanup-api-logs: removed $deleted api_logs rows");
} finally {
    cron_unlock('cleanup-api-logs');
}