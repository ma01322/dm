<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

if (\Auth::check()) {
    $r = \Auth::role();
    redirect($r === 'admin' ? '/admin/index.php' : '/user/index.php');
}

$error = null;
if (is_post()) {
    \Csrf::require();
    $email = trim((string)($_POST['email'] ?? ''));
    $pass  = (string)($_POST['password'] ?? '');
    $res   = \Services\AuthService::attempt($email, $pass);
    if ($res['ok']) {
        $r = $res['user']['role'];
        redirect($r === 'admin' ? '/admin/index.php' : '/user/index.php');
    }
    $error = $res['error'];
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login — <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5" style="max-width:460px">
  <div class="card shadow-sm border-0">
    <div class="card-body p-4">
      <h4 class="mb-3 text-center"><i class="fa-solid fa-right-to-bracket me-2"></i>Sign in</h4>
      <?php if ($error): ?>
        <div class="alert alert-danger py-2 small"><?= e($error) ?></div>
      <?php endif; ?>
      <form method="post" autocomplete="off" novalidate>
        <?= \Csrf::field() ?>
        <div class="mb-3">
          <label class="form-label small">Email</label>
          <input type="email" name="email" class="form-control" required value="<?= e((string)($_POST['email'] ?? '')) ?>">
        </div>
        <div class="mb-3">
          <label class="form-label small">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <button class="btn btn-primary w-100">Login</button>
      </form>
      <div class="text-center mt-3 small">
        <a href="/register.php">Create an account</a> · <a href="/forgot.php">Forgot password?</a>
      </div>
    </div>
  </div>
</div>
</body>
</html>