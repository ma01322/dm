<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

// --- PSR-4-ish autoloader for our namespaces ---
spl_autoload_register(function (string $class): void {
    $map = [
        'Core\\'      => CORE_PATH . '/',
        'Models\\'    => MODELS_PATH . '/',
        'Services\\'  => SERVICES_PATH . '/',
        'Adapters\\'  => ADAPTERS_PATH . '/',
        'Controllers\\' => CONTROLLERS_PATH . '/',
    ];
    foreach ($map as $prefix => $dir) {
        if (str_starts_with($class, $prefix)) {
            $rel = substr($class, strlen($prefix));
            $file = $dir . str_replace('\\', '/', $rel) . '.php';
            if (is_file($file)) require_once $file;
            return;
        }
    }
});

require_once INCLUDES_PATH . '/functions.php';
require_once INCLUDES_PATH . '/session.php';
require_once INCLUDES_PATH . '/csrf.php';
require_once INCLUDES_PATH . '/response.php';
require_once INCLUDES_PATH . '/validator.php';
require_once INCLUDES_PATH . '/logger.php';
require_once INCLUDES_PATH . '/crypto.php';
require_once INCLUDES_PATH . '/rate_limiter.php';
require_once INCLUDES_PATH . '/middleware.php';

// Start session with hardened cookie params
Session::start();