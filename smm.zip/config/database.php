<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

/**
 * PDO singleton with safe defaults.
 * All queries across the app go through this connection.
 */
final class DB
{
    private static ?PDO $pdo = null;

    public static function conn(): PDO
    {
        if (self::$pdo instanceof PDO) return self::$pdo;

        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
            DB_HOST, DB_PORT, DB_NAME
        );

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_STRINGIFY_FETCHES  => false,
            PDO::ATTR_PERSISTENT         => false,
        ];

        try {
            self::$pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            self::$pdo->exec("SET time_zone = '+00:00'");
        } catch (PDOException $e) {
            // Log raw, return generic
            error_log('[DB] ' . $e->getMessage());
            if (APP_DEBUG) throw $e;
            http_response_code(500);
            exit('Service temporarily unavailable.');
        }
        return self::$pdo;
    }

    public static function transaction(callable $fn): mixed
    {
        $pdo = self::conn();
        $pdo->beginTransaction();
        try {
            $result = $fn($pdo);
            $pdo->commit();
            return $result;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('[DB TX] ' . $e->getMessage());
            throw $e;
        }
    }
}