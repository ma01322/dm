<?php
declare(strict_types=1);

/**
 * Loads .env and defines global constants.
 * Never echo or log any value from this file.
 */

if (defined('APP_CONFIG_LOADED')) {
    return;
}
define('APP_CONFIG_LOADED', true);

$root = dirname(__DIR__);

// --- Minimal .env parser (no external dependency) ---
function _load_env(string $file): void {
    if (!is_file($file) || !is_readable($file)) {
        return;
    }
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') continue;
        if (!str_contains($line, '=')) continue;
        [$k, $v] = explode('=', $line, 2);
        $k = trim($k);
        $v = trim($v);
        // strip surrounding quotes
        if (strlen($v) >= 2 && (($v[0] === '"' && $v[-1] === '"') || ($v[0] === "'" && $v[-1] === "'"))) {
            $v = substr($v, 1, -1);
        }
        if (getenv($k) === false) {
            putenv("$k=$v");
            $_ENV[$k] = $v;
        }
    }
}
_load_env($root . '/.env');

function env(string $key, mixed $default = null): mixed {
    $v = getenv($key);
    if ($v === false || $v === '') return $default;
    // Cast common booleans/numbers
    return match (strtolower((string)$v)) {
        'true',  '(true)'  => true,
        'false', '(false)' => false,
        'null',  '(null)'  => null,
        default => $v,
    };
}

// --- Paths ---
define('ROOT_PATH',      $root);
define('CONFIG_PATH',    $root . '/config');
define('INCLUDES_PATH',  $root . '/includes');
define('CORE_PATH',      $root . '/core');
define('MODELS_PATH',    $root . '/models');
define('SERVICES_PATH',  $root . '/services');
define('ADAPTERS_PATH',  $root . '/adapters');
define('CONTROLLERS_PATH', $root . '/controllers');
define('VIEWS_PATH',     $root . '/views');
define('UPLOADS_PATH',   $root . '/uploads');
define('LOGS_PATH',      $root . '/' . (env('LOG_PATH', 'logs')));
define('CRON_PATH',      $root . '/cron');

// --- App ---
define('APP_NAME',   (string) env('APP_NAME',  'SMM Panel'));
define('APP_URL',    rtrim((string) env('APP_URL', 'http://smm.dmghor.com'), '/'));
define('APP_ENV',    (string) env('APP_ENV',   'production'));
define('APP_DEBUG',  (bool)   env('APP_DEBUG', false));
define('APP_KEY_B64',(string) env('APP_KEY',   ''));

// --- DB ---
define('DB_HOST', (string) env('DB_HOST', '127.0.0.1'));
define('DB_PORT', (int)    env('DB_PORT', 3306));
define('DB_NAME', (string) env('DB_NAME', 'dmghorco_smm'));
define('DB_USER', (string) env('DB_USER', 'dmghorco_smm'));
define('DB_PASS', (string) env('DB_PASSWORD', 'dmghorco_smm'));

// --- Session ---
define('SESSION_NAME',     (string) env('SESSION_NAME', 'smm_sid'));
define('SESSION_LIFETIME', (int)    env('SESSION_LIFETIME', 7200));

// --- Error handling (never leak to users) ---
if (APP_DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
}
if (!is_dir(LOGS_PATH)) @mkdir(LOGS_PATH, 0755, true);
ini_set('error_log', LOGS_PATH . '/error.log');

date_default_timezone_set((string) env('APP_TIMEZONE', 'Asia/Dhaka'));