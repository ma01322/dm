<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$me = \Auth::requireLogin();

/* AJAX: fetch services in category (visibility filtered for website) */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'list') {
    $catId = (int)($_GET['category_id'] ?? 0);
    $isReseller = ($me['role'] === 'reseller');
    $pdo = \DB::conn();

    $sql = "SELECT id, name, description, customer_price, reseller_price, min_quantity, max_quantity, refill
            FROM services
            WHERE status='active' AND visible_website=1";
    $args = [];
    if ($catId > 0) { $sql .= " AND category_id = ?"; $args[] = $catId; }
    $sql .= " ORDER BY sort_order ASC, id ASC LIMIT 500";
    $st = $pdo->prepare($sql);
    $st->execute($args);
    $rows = $st->fetchAll();

    $out = [];
    foreach ($rows as $r) {
        $rate = $isReseller && (float)$r['reseller_price'] > 0 ? $r['reseller_price'] : $r['customer_price'];
        $out[] = [
            'id'          => (int)$r['id'],
            'name'        => $r['name'],
            'description' => (string)($r['description'] ?? ''),
            'rate'        => number_format((float)$rate, 4, '.', ''),
            'min'         => (int)$r['min_quantity'],
            'max'         => (int)$r['max_quantity'],
            'refill'      => (int)$r['refill'] === 1,
        ];
    }
    \Response::json(['services' => $out]);
}

$userTitle = 'Services';
$pdo = \DB::conn();
$isReseller = ($me['role'] === 'reseller');

$services = $pdo->query(
  "SELECT s.*, c.name AS category FROM services s
   LEFT JOIN categories c ON c.id=s.category_id
   WHERE s.status='active' AND s.visible_website=1
   ORDER BY c.sort_order, s.sort_order, s.id"
)->fetchAll();

$cur = \Models\Setting::get('currency_symbol','৳');
include __DIR__ . '/partials/header.php';
include __DIR__ . '/partials/sidebar.php';
?>

<div class="card smm-card">
  <div class="table-responsive">
    <table class="table smm-table align-middle mb-0">
      <thead><tr><th>Category</th><th>Service</th><th>Rate/1k</th><th>Min</th><th>Max</th><th>Refill</th></tr></thead>
      <tbody>
      <?php foreach ($services as $s):
        $rate = $isReseller && (float)$s['reseller_price'] > 0 ? $s['reseller_price'] : $s['customer_price'];
      ?>
        <tr>
          <td><span class="badge bg-light text-dark"><?= e($s['category'] ?? 'General') ?></span></td>
          <td>
            <div class="fw-semibold"><?= e($s['name']) ?></div>
            <div class="small text-muted">#<?= (int)$s['id'] ?> — <?= e(mb_substr((string)$s['description'],0,120)) ?></div>
          </td>
          <td class="fw-bold"><?= $cur.number_format((float)$rate,4) ?></td>
          <td><?= (int)$s['min_quantity'] ?></td>
          <td><?= (int)$s['max_quantity'] ?></td>
          <td><?= (int)$s['refill'] ? '<i class="fa-solid fa-check text-success"></i>' : '<i class="fa-solid fa-xmark text-muted"></i>' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$services): ?><tr><td colspan="6" class="text-center text-muted py-4">No services available.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>