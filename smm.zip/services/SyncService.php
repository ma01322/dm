<?php
declare(strict_types=1);
namespace Services;

use DB;
use Logger;
use Adapters\Providers\ProviderFactory;

final class SyncService
{
    public const ACTIVE_STATUSES = ['pending','processing','in_progress'];
    private const MAX_ATTEMPTS = 15;

    /**
     * Sync a single order against its provider.
     * Safe to call frequently (dedupes via last_sync_at).
     */
    public static function syncOne(int $orderId, bool $force = false): bool
    {
        $pdo = DB::conn();
        $st = $pdo->prepare('SELECT * FROM orders WHERE id=? LIMIT 1');
        $st->execute([$orderId]);
        $o = $st->fetch();
        if (!$o) return false;
        if (!in_array($o['status'], self::ACTIVE_STATUSES, true)) return false;
        if (!$o['provider_id'] || !$o['provider_order_id']) {
            // Manual order — nothing to sync
            return false;
        }
        if (!$force && $o['last_sync_at'] && strtotime((string)$o['last_sync_at']) > time() - 60) {
            return false; // dedupe: at most once per minute unless forced
        }

        try {
            $adapter = ProviderFactory::make((int)$o['provider_id']);
            $status = $adapter->getOrderStatus((string)$o['provider_order_id']);
        } catch (\Throwable $e) {
            $pdo->prepare('UPDATE orders SET sync_attempts = sync_attempts + 1, last_sync_at = NOW() WHERE id=?')
                ->execute([$orderId]);
            Logger::error('provider', 'sync failed', ['order' => $orderId, 'err' => $e->getMessage()]);

            // Give up after N attempts → mark failed
            $attempts = (int)$o['sync_attempts'] + 1;
            if ($attempts >= self::MAX_ATTEMPTS) {
                try { OrderService::refund($orderId, null, 'Auto refund: provider sync failed after '.$attempts.' attempts'); }
                catch (\Throwable $e2) { Logger::error('app', 'sync auto-refund failed', ['order' => $orderId, 'err' => $e2->getMessage()]); }
                $pdo->prepare('UPDATE orders SET status="failed" WHERE id=?')->execute([$orderId]);
            }
            return false;
        }

        return DB::transaction(function ($pdo) use ($o, $status, $orderId) {
            $newStatus = $status['status'] ?? $o['status'];
            $startCount = $status['start_count'] ?? $o['start_count'];
            $remains    = $status['remains']     ?? $o['remains'];

            $pdo->prepare('UPDATE orders SET status=?, start_count=?, remains=?, last_sync_at=NOW(), sync_attempts=sync_attempts+1 WHERE id=?')
                ->execute([$newStatus, $startCount, $remains, $orderId]);

            $pdo->prepare('INSERT INTO order_logs (order_id, action, message, meta) VALUES (?,?,?,?)')
                ->execute([$orderId, 'sync', 'Synced from provider', json_encode([
                    'status' => $newStatus, 'start_count' => $startCount, 'remains' => $remains,
                ])]);

            // Auto refund on final failed/canceled/partial
            if (in_array($newStatus, ['canceled','failed','partial'], true) && (int)$o['refunded'] === 0) {
                $refundAmt = null;
                if ($newStatus === 'partial' && $remains !== null && (int)$o['quantity'] > 0) {
                    // Refund proportional to undelivered
                    $delivered = max(0, (int)$o['quantity'] - (int)$remains);
                    $refundAmt = round(((float)$o['charge']) * (1 - $delivered / (int)$o['quantity']), 4);
                }
                try { OrderService::refund($orderId, $refundAmt, 'Auto refund: status ' . $newStatus); }
                catch (\Throwable $e) { Logger::error('app', 'auto refund on ' . $newStatus . ' failed', ['order' => $orderId, 'err' => $e->getMessage()]); }
            }
            return true;
        });
    }

    /**
     * Batch sync active orders. Called by cron. Safe: uses lock + rate limit.
     * @return array{checked:int,changed:int}
     */
    public static function syncBatch(int $limit = 100): array
    {
        $pdo = DB::conn();
        $st = $pdo->query(
            "SELECT id FROM orders
             WHERE status IN ('pending','processing','in_progress')
               AND provider_id IS NOT NULL
               AND provider_order_id IS NOT NULL
               AND (last_sync_at IS NULL OR last_sync_at < (NOW() - INTERVAL 90 SECOND))
             ORDER BY last_sync_at IS NULL DESC, last_sync_at ASC
             LIMIT " . (int)$limit
        );
        $ids = array_map(fn($r) => (int)$r['id'], $st->fetchAll());
        $checked = 0; $changed = 0;
        foreach ($ids as $id) {
            $checked++;
            try { if (self::syncOne($id, true)) $changed++; }
            catch (\Throwable $e) { Logger::error('provider', 'sync batch item failed', ['id' => $id, 'err' => $e->getMessage()]); }
        }
        return ['checked' => $checked, 'changed' => $changed];
    }
}