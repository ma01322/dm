<?php
declare(strict_types=1);
namespace Services;

use DB;
use Logger;

final class WalletService
{
    /**
     * Adjust wallet balance inside a transaction and always write a transaction row.
     * $amount may be positive (credit) or negative (debit).
     */
    public static function adjust(int $userId, float $amount, string $note, int $adminId = 0, string $type = 'adjustment', ?string $reference = null): array
    {
        if ($amount == 0.0) throw new \InvalidArgumentException('Amount must be non-zero');

        return DB::transaction(function ($pdo) use ($userId, $amount, $note, $adminId, $type, $reference) {
            // Lock user row
            $st = $pdo->prepare('SELECT id, balance, total_spent, total_deposit FROM users WHERE id = ? FOR UPDATE');
            $st->execute([$userId]);
            $u = $st->fetch();
            if (!$u) throw new \RuntimeException('User not found');

            $new = round((float)$u['balance'] + $amount, 4);
            if ($new < 0) throw new \RuntimeException('Insufficient balance');

            $pdo->prepare('UPDATE users SET balance = ? WHERE id = ?')->execute([$new, $userId]);

            $pdo->prepare(
                'INSERT INTO transactions (user_id, type, amount, balance_after, reference, description)
                 VALUES (?,?,?,?,?,?)'
            )->execute([$userId, $type, $amount, $new, $reference, $note]);

            Logger::activity($adminId ?: null, $adminId ? 'admin' : null, 'wallet.' . $type, 'user', $userId, ['amount' => $amount, 'note' => $note]);

            return ['balance' => $new];
        });
    }

    /** Debit + charge to user (used at order placement). Called INSIDE an existing DB transaction. */
    public static function debitForOrder(\PDO $pdo, int $userId, float $amount, int $orderId, string $note): float
    {
        if ($amount <= 0) throw new \RuntimeException('Amount must be positive');
        $st = $pdo->prepare('SELECT balance FROM users WHERE id = ? FOR UPDATE');
        $st->execute([$userId]);
        $balance = (float)$st->fetchColumn();
        if ($balance < $amount) throw new \RuntimeException('Insufficient balance');
        $new = round($balance - $amount, 4);
        $pdo->prepare('UPDATE users SET balance = ?, total_spent = total_spent + ? WHERE id = ?')
            ->execute([$new, $amount, $userId]);
        $pdo->prepare(
            'INSERT INTO transactions (user_id, type, amount, balance_after, reference, description)
             VALUES (?,?,?,?,?,?)'
        )->execute([$userId, 'order', -$amount, $new, (string)$orderId, $note]);
        return $new;
    }

    /** Credit refund (inside an existing DB transaction). */
    public static function creditRefund(\PDO $pdo, int $userId, float $amount, int $orderId, string $note): float
    {
        if ($amount <= 0) return 0.0;
        $st = $pdo->prepare('SELECT balance FROM users WHERE id = ? FOR UPDATE');
        $st->execute([$userId]);
        $balance = (float)$st->fetchColumn();
        $new = round($balance + $amount, 4);
        $pdo->prepare('UPDATE users SET balance = ? WHERE id = ?')->execute([$new, $userId]);
        $pdo->prepare(
            'INSERT INTO transactions (user_id, type, amount, balance_after, reference, description)
             VALUES (?,?,?,?,?,?)'
        )->execute([$userId, 'refund', $amount, $new, (string)$orderId, $note]);
        return $new;
    }

    /** Credit a completed deposit (inside existing transaction). */
    public static function creditDeposit(\PDO $pdo, int $userId, float $netAmount, int $depositId, string $note): float
    {
        $st = $pdo->prepare('SELECT balance FROM users WHERE id = ? FOR UPDATE');
        $st->execute([$userId]);
        $balance = (float)$st->fetchColumn();
        $new = round($balance + $netAmount, 4);
        $pdo->prepare('UPDATE users SET balance = ?, total_deposit = total_deposit + ? WHERE id = ?')
            ->execute([$new, $netAmount, $userId]);
        $pdo->prepare(
            'INSERT INTO transactions (user_id, type, amount, balance_after, reference, description)
             VALUES (?,?,?,?,?,?)'
        )->execute([$userId, 'deposit', $netAmount, $new, (string)$depositId, $note]);
        return $new;
    }
}