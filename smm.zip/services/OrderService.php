<?php
declare(strict_types=1);
namespace Services;

use DB;
use Logger;
use Models\Service;
use Adapters\Providers\ProviderFactory;

final class OrderService
{
    /**
     * Place an order. All money manipulation runs in a single DB transaction.
     * If provider dispatch fails, order is marked 'failed' and funds are refunded in the same transaction.
     *
     * @param string $source 'web' | 'api' | 'admin'
     * @return array{order_id:int, charge:float, balance:float, status:string}
     */
    public static function place(int $userId, int $serviceId, string $link, int $quantity, string $source = 'web', array $extra = []): array
    {
        // -------- Validation before touching DB --------
        $link = trim($link);
        if (!filter_var($link, FILTER_VALIDATE_URL)) throw new \RuntimeException('Invalid link');
        if (strlen($link) > 500) throw new \RuntimeException('Link too long');
        if ($quantity < 1) throw new \RuntimeException('Invalid quantity');

        $user = \Models\User::find($userId);
        if (!$user) throw new \RuntimeException('User not found');
        if ($user['status'] !== 'active') throw new \RuntimeException('Account is not active');

        $service = Service::find($serviceId);
        if (!$service) throw new \RuntimeException('Service not found');
        if ($service['status'] !== 'active') throw new \RuntimeException('Service unavailable');
        if ($quantity < (int)$service['min_quantity'] || $quantity > (int)$service['max_quantity']) {
            throw new \RuntimeException("Quantity must be between {$service['min_quantity']} and {$service['max_quantity']}");
        }

        // Price: prefer reseller price for resellers if set > 0
        $isReseller = $user['role'] === 'reseller';
        $price = (float)$service['customer_price'];
        if ($isReseller && (float)$service['reseller_price'] > 0) $price = (float)$service['reseller_price'];

        $charge = round($price * $quantity / 1000, 4);
        $cost   = round((float)$service['cost_price'] * $quantity / 1000, 4);
        $profit = round($charge - $cost, 4);

        if ($charge <= 0) throw new \RuntimeException('Invalid charge');

        // -------- Create + debit + dispatch (atomic on money) --------
        $orderId = null; $newBalance = 0.0; $finalStatus = 'pending';

        try {
            $result = DB::transaction(function ($pdo) use ($userId, $serviceId, $service, $link, $quantity, $charge, $cost, $profit, $source, $extra) {
                // Debit wallet & insert order
                $pdo->prepare(
                    'INSERT INTO orders (user_id, service_id, provider_id, link, quantity, charge, cost, profit, status, source)
                     VALUES (?,?,?,?,?,?,?,?,?,?)'
                )->execute([
                    $userId, $serviceId, $service['provider_id'] ?: null,
                    $link, $quantity, $charge, $cost, $profit, 'pending', $source
                ]);
                $orderId = (int)$pdo->lastInsertId();

                try {
                    $newBalance = WalletService::debitForOrder($pdo, $userId, $charge, $orderId, 'Order #' . $orderId);
                } catch (\Throwable $e) {
                    throw new \RuntimeException('Insufficient balance');
                }

                $pdo->prepare('INSERT INTO order_logs (order_id, action, message) VALUES (?,?,?)')
                    ->execute([$orderId, 'created', 'Order created via ' . $source]);

                return ['order_id' => $orderId, 'balance' => $newBalance];
            });
            $orderId     = $result['order_id'];
            $newBalance  = $result['balance'];
        } catch (\Throwable $e) {
            // Rolled back — no money moved
            Logger::error('app', 'order create failed', ['user' => $userId, 'err' => $e->getMessage()]);
            throw $e;
        }

        // -------- Dispatch to provider (OUTSIDE transaction; failure => refund) --------
        try {
            if (!empty($service['provider_id']) && !empty($service['provider_service_id'])) {
                $dispatch = self::dispatch($orderId, $service, $link, $quantity, $extra);
                $finalStatus = $dispatch['status'];
            } else {
                // Manual service: leave pending for admin
                $finalStatus = 'pending';
                $pdo = DB::conn();
                $pdo->prepare('UPDATE orders SET status="pending" WHERE id=?')->execute([$orderId]);
            }
        } catch (\Throwable $e) {
            Logger::error('app', 'provider dispatch failed', ['order' => $orderId, 'err' => $e->getMessage()]);
            // Refund + mark failed
            try {
                self::refund($orderId, null, 'Auto refund: provider dispatch failed', true);
            } catch (\Throwable $e2) {
                Logger::error('app', 'auto refund failed', ['order' => $orderId, 'err' => $e2->getMessage()]);
            }
            $finalStatus = 'failed';
        }

        $order = \Models\Order::find($orderId);
        return [
            'order_id' => $orderId,
            'charge'   => (float)$order['charge'],
            'balance'  => (float)$order['charge'] > 0 ? (float)\Models\User::find($userId)['balance'] : $newBalance,
            'status'   => $order['status'],
        ];
    }

    /** Dispatch order to provider + save provider_order_id. */
    public static function dispatch(int $orderId, array $service, string $link, int $quantity, array $extra = []): array
    {
        $pdo = DB::conn();
        $order = \Models\Order::find($orderId);
        if (!$order) throw new \RuntimeException('Order missing');

        $adapter = ProviderFactory::make((int)$service['provider_id']);
        $res = $adapter->addOrder((string)$service['provider_service_id'], $link, $quantity, $extra);

        $pdo->prepare('UPDATE orders SET provider_order_id=?, status="processing", last_sync_at=NOW() WHERE id=?')
            ->execute([$res['order'], $orderId]);
        $pdo->prepare('INSERT INTO order_logs (order_id, action, message, meta) VALUES (?,?,?,?)')
            ->execute([$orderId, 'dispatched', 'Sent to provider', json_encode(['provider_order_id' => $res['order']])]);

        return ['status' => 'processing', 'provider_order_id' => $res['order']];
    }

    /** Refund order — safe under DB transaction, idempotent (won't refund twice). */
    public static function refund(int $orderId, ?float $amount = null, string $note = 'Refund', bool $auto = false): array
    {
        return DB::transaction(function ($pdo) use ($orderId, $amount, $note) {
            $st = $pdo->prepare('SELECT * FROM orders WHERE id=? FOR UPDATE');
            $st->execute([$orderId]);
            $o = $st->fetch();
            if (!$o) throw new \RuntimeException('Order not found');
            if ((int)$o['refunded'] === 1) return ['already' => true, 'amount' => (float)$o['refund_amount']];

            $refund = $amount ?? (float)$o['charge'];
            if ($refund <= 0) $refund = (float)$o['charge'];
            if ($refund > (float)$o['charge']) $refund = (float)$o['charge'];

            $newBal = WalletService::creditRefund($pdo, (int)$o['user_id'], $refund, $orderId, $note);

            $pdo->prepare('UPDATE orders SET refunded=1, refund_amount=?, status=IF(status IN ("canceled","failed","partial"), status, "refunded") WHERE id=?')
                ->execute([$refund, $orderId]);

            $pdo->prepare('INSERT INTO order_logs (order_id, action, message, meta) VALUES (?,?,?,?)')
                ->execute([$orderId, 'refund', $note, json_encode(['amount' => $refund])]);

            Logger::activity((int)$o['user_id'], null, 'order.refund', 'order', $orderId, ['amount' => $refund, 'note' => $note]);

            return ['refunded' => true, 'amount' => $refund, 'balance' => $newBal];
        });
    }
}