<?php
declare(strict_types=1);
namespace Services;

use DB;
use Logger;
use Response;
use RateLimiter;

final class ApiService
{
    public static function log(?int $userId, ?int $keyId, ?string $action, array $request, int $code, int $ms, ?string $error = null): void
    {
        try {
            DB::conn()->prepare(
                'INSERT INTO api_logs (user_id, api_key_id, action, ip, method, endpoint, request, response_code, response_ms, error)
                 VALUES (?,?,?,?,?,?,?,?,?,?)'
            )->execute([
                $userId, $keyId, $action, client_ip(),
                $_SERVER['REQUEST_METHOD'] ?? 'POST',
                substr((string)($_SERVER['REQUEST_URI'] ?? ''), 0, 200),
                json_encode(sanitize_json_recursive($request)),
                $code, $ms, $error,
            ]);
        } catch (\Throwable $e) {
            Logger::error('api', 'log insert failed: ' . $e->getMessage());
        }
    }

    /** Authenticate the API key. Returns [keyRow, userRow]. Exits on failure. */
    public static function authenticate(): array
    {
        $key = $_POST['key'] ?? $_GET['key'] ?? null;
        if (!is_string($key) || $key === '') {
            Response::apiError('Missing API key', 401);
        }
        if (strlen($key) > 128) Response::apiError('Invalid API key', 401);

        $row = \Models\ApiKey::findByFullKey($key);
        if (!$row) Response::apiError('Invalid API key', 401);
        if (($row['user_status'] ?? '') !== 'active') Response::apiError('Account is not active', 403);
        if (!in_array($row['role'] ?? '', ['reseller','admin'], true)) Response::apiError('API access denied', 403);

        // Rate limiting per key
        $rl = RateLimiter::hit('api:' . (int)$row['id'], max(1, (int)$row['rate_limit']));
        if (!$rl['allowed']) {
            header('Retry-After: ' . $rl['retry_after']);
            Response::apiError('Rate limit exceeded', 429);
        }
        header('X-RateLimit-Limit: ' . (int)$row['rate_limit']);
        header('X-RateLimit-Remaining: ' . $rl['remaining']);

        \Models\ApiKey::touch((int)$row['id'], client_ip());
        return [$row, [
            'id' => (int)$row['user_id'],
            'username' => $row['username'],
            'role' => $row['role'],
            'balance' => (float)$row['balance'],
            'currency' => $row['currency'],
        ]];
    }
}