<?php
declare(strict_types=1);
namespace Services;

use DB;
use Logger;

final class DepositService
{
    /**
     * Create a deposit request. For manual gateways, returns a message
     * (pending admin approval). For automated gateways, redirect URL.
     */
    public static function create(int $userId, int $gatewayId, float $amount): array
    {
        if ($amount <= 0) throw new \RuntimeException('Amount must be positive');
        $pdo = DB::conn();

        $st = $pdo->prepare("SELECT * FROM payment_gateways WHERE id=? AND status='active' LIMIT 1");
        $st->execute([$gatewayId]);
        $g = $st->fetch();
        if (!$g) throw new \RuntimeException('Gateway unavailable');
        if ($amount < (float)$g['min_deposit'] || $amount > (float)$g['max_deposit']) {
            throw new \RuntimeException("Amount must be between {$g['min_deposit']} and {$g['max_deposit']}");
        }

        $fee = round((float)$g['fee_fixed'] + $amount * ((float)$g['fee_percent'] / 100), 4);
        $net = round($amount - $fee, 4);
        if ($net <= 0) throw new \RuntimeException('Amount after fees is zero');

        $ref = 'DEP-' . strtoupper(bin2hex(random_bytes(6)));

        $pdo->prepare(
            'INSERT INTO deposits (user_id, gateway_id, amount, fee, net_amount, currency, status, reference)
             VALUES (?,?,?,?,?,?,?,?)'
        )->execute([$userId, $gatewayId, $amount, $fee, $net, \Models\Setting::get('currency','BDT'), 'pending', $ref]);

        $depositId = (int)$pdo->lastInsertId();
        Logger::activity($userId, null, 'deposit.create', 'deposit', $depositId, ['amount' => $amount, 'gateway' => $g['code']]);

        // Adapter hook (manual gateway returns instructions; live gateways return redirect URL)
        $adapterClass = 'Adapters\\Payments\\' . ucfirst($g['adapter']) . 'Gateway';
        if (class_exists($adapterClass)) {
            $adapter = new $adapterClass($g);
            return $adapter->createPayment([
                'deposit_id' => $depositId,
                'user_id'    => $userId,
                'amount'     => $amount,
                'reference'  => $ref,
            ]);
        }

        return [
            'deposit_id' => $depositId,
            'reference'  => $ref,
            'message'    => 'Deposit ' . $ref . ' created. Follow the gateway instructions.',
        ];
    }

    /** Called by IPN/callback or admin. Idempotent. */
    public static function complete(int $depositId, string $gatewayRef = null): void
    {
        DB::transaction(function ($pdo) use ($depositId, $gatewayRef) {
            $st = $pdo->prepare('SELECT * FROM deposits WHERE id=? FOR UPDATE');
            $st->execute([$depositId]);
            $d = $st->fetch();
            if (!$d) throw new \RuntimeException('Deposit not found');
            if ($d['status'] === 'completed') return;

            $pdo->prepare('UPDATE deposits SET status="completed", completed_at=NOW(), gateway_ref=? WHERE id=?')
                ->execute([$gatewayRef, $depositId]);

            WalletService::creditDeposit($pdo, (int)$d['user_id'], (float)$d['net_amount'], $depositId, 'Deposit ' . $d['reference']);

            Logger::activity((int)$d['user_id'], null, 'deposit.complete', 'deposit', $depositId, ['amount' => (float)$d['net_amount']]);
        });
    }

    public static function cancel(int $depositId, string $reason = 'canceled'): void
    {
        DB::conn()->prepare('UPDATE deposits SET status=?, note=? WHERE id=? AND status="pending"')
            ->execute([$reason, $reason, $depositId]);
    }
}