<?php
declare(strict_types=1);
namespace Services;

use DB;
use Logger;
use Models\Provider;
use Models\Service;
use Adapters\Providers\ProviderFactory;

final class ProviderService
{
    public static function testConnection(int $providerId): array
    {
        $p = Provider::find($providerId);
        if (!$p) throw new \RuntimeException('Provider not found');
        try {
            $adapter = ProviderFactory::make($providerId);
            $bal = $adapter->getBalance();
            DB::conn()->prepare('UPDATE providers SET balance_cache=?, balance_updated=NOW(), last_error=NULL WHERE id=?')
                ->execute([$bal['balance'], $providerId]);
            return ['ok' => true, 'balance' => $bal['balance'], 'message' => 'Connected. Balance: '.number_format($bal['balance'], 4).' '.$bal['currency']];
        } catch (\Throwable $e) {
            DB::conn()->prepare('UPDATE providers SET last_error=? WHERE id=?')
                ->execute([substr($e->getMessage(), 0, 500), $providerId]);
            throw new \RuntimeException($e->getMessage());
        }
    }

    public static function fetchBalance(int $providerId): ?float
    {
        $adapter = ProviderFactory::make($providerId);
        $bal = $adapter->getBalance();
        DB::conn()->prepare('UPDATE providers SET balance_cache=?, balance_updated=NOW(), last_error=NULL WHERE id=?')
            ->execute([$bal['balance'], $providerId]);
        return $bal['balance'];
    }

    /**
     * Fetch services from provider and store them in provider_services cache.
     * @return array{imported:int}
     */
    public static function importServices(int $providerId): array
    {
        $adapter = ProviderFactory::make($providerId);
        $list = $adapter->getServices();
        $pdo = DB::conn();
        $pdo->beginTransaction();
        try {
            $ins = $pdo->prepare(
                'INSERT INTO provider_services (provider_id, provider_service_id, name, category, rate, min, max, raw, synced_at)
                 VALUES (?,?,?,?,?,?,?,?,NOW())
                 ON DUPLICATE KEY UPDATE name=VALUES(name), category=VALUES(category), rate=VALUES(rate),
                 min=VALUES(min), max=VALUES(max), raw=VALUES(raw), synced_at=NOW()'
            );
            foreach ($list as $s) {
                $ins->execute([
                    $providerId,
                    $s['service'],
                    mb_substr($s['name'], 0, 200),
                    mb_substr((string)($s['category'] ?? ''), 0, 120),
                    (float)$s['rate'],
                    (int)($s['min'] ?? 1),
                    (int)($s['max'] ?? 100000),
                    json_encode(['type' => $s['type'] ?? 'default', 'refill' => $s['refill'] ?? false, 'cancel' => $s['cancel'] ?? false, 'dripfeed' => $s['dripfeed'] ?? false]),
                ]);
            }
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
        return ['imported' => count($list)];
    }

    /** Import a single cached provider service into `services` (as a new service row). */
    public static function importOne(int $psId): int
    {
        $pdo = DB::conn();
        $st = $pdo->prepare('SELECT * FROM provider_services WHERE id=? LIMIT 1');
        $st->execute([$psId]);
        $ps = $st->fetch();
        if (!$ps) throw new \RuntimeException('Provider service not found');

        $exists = $pdo->prepare('SELECT id FROM services WHERE provider_id=? AND provider_service_id=? LIMIT 1');
        $exists->execute([$ps['provider_id'], $ps['provider_service_id']]);
        $ex = $exists->fetchColumn();
        if ($ex) throw new \RuntimeException('Already imported as #'.$ex);

        // Default markup 30% over cost
        $cost = (float)$ps['rate'];
        $customer = round($cost * 1.30, 4);
        $reseller = round($cost * 1.15, 4);

        $meta = $ps['raw'] ? json_decode((string)$ps['raw'], true) : [];
        $type = in_array($meta['type'] ?? '', ['default','package','custom_comments','subscriptions','dripfeed'], true) ? $meta['type'] : 'default';

        return Service::insert([
            'category_id'         => null,
            'name'                => mb_substr($ps['name'], 0, 200),
            'description'         => '',
            'type'                => $type,
            'provider_id'         => (int)$ps['provider_id'],
            'provider_service_id' => (string)$ps['provider_service_id'],
            'cost_price'          => $cost,
            'customer_price'      => $customer,
            'reseller_price'      => $reseller,
            'min_quantity'        => (int)($ps['min'] ?? 1),
            'max_quantity'        => (int)($ps['max'] ?? 100000),
            'dripfeed'            => (int)!(empty($meta['dripfeed'])),
            'refill'              => (int)!(empty($meta['refill'])),
            'cancel'              => (int)!(empty($meta['cancel'])),
            'speed'               => '',
            'avg_time'            => '',
            'sort_order'          => 100,
            'status'              => 'active',
            'visible_website'     => 1,
            'visible_api'         => 1,
        ]);
    }
}