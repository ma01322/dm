<?php
declare(strict_types=1);
namespace Services;

final class ServiceCatalogService
{
    /** Public (website) catalog for a given role. Returns array keyed by category. */
    public static function websiteCatalog(?string $role): array
    {
        $rows = \Models\Service::websiteListFor($role);
        $isReseller = $role === 'reseller';
        $out = [];
        foreach ($rows as $r) {
            $rate = $isReseller && (float)$r['reseller_price'] > 0 ? $r['reseller_price'] : $r['customer_price'];
            $out[] = [
                'id'       => (int)$r['id'],
                'name'     => $r['name'],
                'category' => $r['category'] ?? 'General',
                'rate'     => (float)$rate,
                'min'      => (int)$r['min_quantity'],
                'max'      => (int)$r['max_quantity'],
                'refill'   => (bool)$r['refill'],
                'cancel'   => (bool)$r['cancel'],
                'dripfeed' => (bool)$r['dripfeed'],
                'type'     => $r['type'],
            ];
        }
        return $out;
    }

    /** API catalog — only services with visible_api=1. */
    public static function apiCatalog(): array
    {
        $rows = \Models\Service::apiListAll();
        $out = [];
        foreach ($rows as $r) {
            $rate = (float)$r['reseller_price'] > 0 ? $r['reseller_price'] : $r['customer_price'];
            $out[] = [
                'service'  => (int)$r['id'],
                'name'     => $r['name'],
                'category' => $r['category'] ?? 'General',
                'rate'     => number_format((float)$rate, 4, '.', ''),
                'min'      => (string)(int)$r['min_quantity'],
                'max'      => (string)(int)$r['max_quantity'],
                'type'     => $r['type'],
                'refill'   => (bool)$r['refill'],
                'cancel'   => (bool)$r['cancel'],
                'dripfeed' => (bool)$r['dripfeed'],
            ];
        }
        return $out;
    }

    /** API-visible service by ID (returns null if API-invisible). */
    public static function apiVisible(int $id): ?array
    {
        $s = \Models\Service::find($id);
        if (!$s || $s['status'] !== 'active' || (int)$s['visible_api'] !== 1) return null;
        return $s;
    }
}